const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

// Multi-cryptocurrency support configuration
const SUPPORTED_TOKENS = {
  ETH: {
    address: "0x0000000000000000000000000000000000000000",
    symbol: "ETH",
    name: "Ethereum",
    decimals: 18
  },
  USDC: {
    address: "0xA0b86a33E6441D6e4C0f4A0cEb4d87A9e9E1b4E3",
    symbol: "USDC",
    name: "USD Coin",
    decimals: 6
  },
  USDT: {
    address: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    symbol: "USDT",
    name: "Tether USD",
    decimals: 6
  },
  DAI: {
    address: "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    symbol: "DAI",
    name: "Dai Stablecoin",
    decimals: 18
  },
  WBTC: {
    address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    symbol: "WBTC",
    name: "Wrapped Bitcoin",
    decimals: 8
  },
  LINK: {
    address: "0x514910771AF9Ca656af840dff83E8264EcF986CA",
    symbol: "LINK",
    name: "Chainlink",
    decimals: 18
  }
};

async function main() {
  console.log("🚀 Starting deployment of Blockchain Resource Marketplace...\n");

  // Get deployer account
  const [deployer] = await ethers.getSigners();
  console.log("📝 Deploying contracts with account:", deployer.address);
  console.log("💰 Account balance:", ethers.utils.formatEther(await deployer.getBalance()), "ETH\n");

  try {
    // Deploy ResourceToken
    console.log("1️⃣ Deploying ResourceToken...");
    const ResourceToken = await ethers.getContractFactory("ResourceToken");
    const resourceToken = await ResourceToken.deploy();
    await resourceToken.deployed();
    console.log("✅ ResourceToken deployed to:", resourceToken.address);

    // Deploy Escrow
    console.log("2️⃣ Deploying Escrow...");
    const Escrow = await ethers.getContractFactory("Escrow");
    const escrow = await Escrow.deploy();
    await escrow.deployed();
    console.log("✅ Escrow deployed to:", escrow.address);

    // Deploy Reputation
    console.log("3️⃣ Deploying Reputation...");
    const Reputation = await ethers.getContractFactory("Reputation");
    const reputation = await Reputation.deploy();
    await reputation.deployed();
    console.log("✅ Reputation deployed to:", reputation.address);

    // Deploy Verifier
    console.log("4️⃣ Deploying Verifier...");
    const Verifier = await ethers.getContractFactory("Verifier");
    const verifier = await Verifier.deploy();
    await verifier.deployed();
    console.log("✅ Verifier deployed to:", verifier.address);

    // Deploy ResourceMarketplace
    console.log("5️⃣ Deploying ResourceMarketplace...");
    const ResourceMarketplace = await ethers.getContractFactory("ResourceMarketplace");
    const resourceMarketplace = await ResourceMarketplace.deploy(
      resourceToken.address,
      escrow.address,
      reputation.address,
      verifier.address
    );
    await resourceMarketplace.deployed();
    console.log("✅ ResourceMarketplace deployed to:", resourceMarketplace.address);

    // Deploy MarketplaceFactory
    console.log("6️⃣ Deploying MarketplaceFactory...");
    const MarketplaceFactory = await ethers.getContractFactory("MarketplaceFactory");
    const marketplaceFactory = await MarketplaceFactory.deploy(
      resourceMarketplace.address,
      resourceToken.address,
      escrow.address,
      reputation.address,
      verifier.address
    );
    await marketplaceFactory.deployed();
    console.log("✅ MarketplaceFactory deployed to:", marketplaceFactory.address);

    // Authorize marketplace as minter in ResourceToken
    console.log("7️⃣ Authorizing marketplace contracts...");
    const MINTER_ROLE = ethers.utils.keccak256(ethers.utils.toUtf8Bytes("MINTER_ROLE"));
    await resourceToken.addAuthorizedMinter(resourceMarketplace.address);
    await resourceToken.addAuthorizedMinter(marketplaceFactory.address);
    console.log("✅ Authorizations completed");

    // Set up supported tokens in escrow
    console.log("8️⃣ Setting up multi-cryptocurrency support...");
    await setupMultiCurrencySupport(escrow, SUPPORTED_TOKENS);
    console.log("✅ Multi-cryptocurrency support configured");

    // Grant authorization to deployer for additional operations
    console.log("9️⃣ Setting up authorization...");
    await reputation.addAuthorizedModerator(deployer.address);
    await reputation.addAuthorizedVerifier(deployer.address);
    await escrow.addAuthorizedArbitrator(deployer.address);
    await verifier.setVerifierAuthorization(deployer.address, true);
    console.log("✅ Authorization setup completed");

    // Create deployment information object
    const deploymentInfo = {
      network: network.name,
      chainId: network.config.chainId || 31337,
      blockNumber: await ethers.provider.getBlockNumber(),
      timestamp: new Date().toISOString(),
      deployer: deployer.address,
      contracts: {
        ResourceToken: {
          address: resourceToken.address,
          abi: JSON.parse(ResourceToken.interface.format('json'))
        },
        Escrow: {
          address: escrow.address,
          abi: JSON.parse(Escrow.interface.format('json'))
        },
        Reputation: {
          address: reputation.address,
          abi: JSON.parse(Reputation.interface.format('json'))
        },
        Verifier: {
          address: verifier.address,
          abi: JSON.parse(Verifier.interface.format('json'))
        },
        ResourceMarketplace: {
          address: resourceMarketplace.address,
          abi: JSON.parse(ResourceMarketplace.interface.format('json'))
        },
        MarketplaceFactory: {
          address: marketplaceFactory.address,
          abi: JSON.parse(MarketplaceFactory.interface.format('json'))
        }
      },
      supportedTokens: SUPPORTED_TOKENS,
      gasUsed: {
        ResourceToken: resourceToken.deployTransaction.gasLimit.toString(),
        Escrow: escrow.deployTransaction.gasLimit.toString(),
        Reputation: reputation.deployTransaction.gasLimit.toString(),
        Verifier: verifier.deployTransaction.gasLimit.toString(),
        ResourceMarketplace: resourceMarketplace.deployTransaction.gasLimit.toString(),
        MarketplaceFactory: marketplaceFactory.deployTransaction.gasLimit.toString()
      }
    };

    // Save deployment information
    const deploymentPath = path.join(__dirname, '../artifacts/deployment.json');
    fs.writeFileSync(deploymentPath, JSON.stringify(deploymentInfo, null, 2));
    console.log("💾 Deployment information saved to:", deploymentPath);

    // Create configuration file for frontend
    const frontendConfig = {
      contracts: {
        ResourceToken: resourceToken.address,
        Escrow: escrow.address,
        Reputation: reputation.address,
        Verifier: verifier.address,
        ResourceMarketplace: resourceMarketplace.address,
        MarketplaceFactory: marketplaceFactory.address
      },
      supportedTokens: SUPPORTED_TOKENS,
      network: {
        name: network.name,
        chainId: network.config.chainId || 31337
      }
    };

    const frontendConfigPath = path.join(__dirname, '../frontend/js/config.js');
    const configContent = `// Auto-generated configuration file
export const CONTRACT_ADDRESSES = ${JSON.stringify(frontendConfig.contracts, null, 2)};
export const SUPPORTED_TOKENS = ${JSON.stringify(frontendConfig.supportedTokens, null, 2)};
export const NETWORK = ${JSON.stringify(frontendConfig.network, null, 2)};

// Web3.js configuration
export const WEB3_CONFIG = {
  networkId: ${network.config.chainId || 31337},
  gasPrice: '20000000000', // 20 Gwei
  gasLimit: 21000
};

// Marketplace configuration
export const MARKETPLACE_CONFIG = {
  platformFee: 25, // 2.5%
  minResourcePrice: 1000000000000000, // 0.001 tokens
  maxResourcePrice: 1000000000000000000000, // 1000 tokens
  disputePeriod: 7 * 24 * 60 * 60, // 7 days in seconds
  ratingCooldownPeriod: 24 * 60 * 60 // 24 hours in seconds
};
`;

    // Create frontend config directory if it doesn't exist
    const frontendDir = path.dirname(frontendConfigPath);
    if (!fs.existsSync(frontendDir)) {
      fs.mkdirSync(frontendDir, { recursive: true });
    }
    fs.writeFileSync(frontendConfigPath, configContent);
    console.log("💾 Frontend configuration saved to:", frontendConfigPath);

    // Create API configuration
    const apiConfig = {
      baseUrl: "http://localhost:3000/api",
      contracts: {
        ResourceMarketplace: resourceMarketplace.address,
        ResourceToken: resourceToken.address,
        Escrow: escrow.address,
        Reputation: reputation.address,
        Verifier: verifier.address
      },
      features: {
        multiCurrency: true,
        escrowSystem: true,
        reputationSystem: true,
        resourceVerification: true,
        automatedEscrow: true
      },
      limits: {
        maxResourcesPerUser: 100,
        maxRequestsPerUser: 50,
        maxTransactionsPerDay: 1000,
        maxFileUploadSize: 10485760 // 10MB
      }
    };

    const apiConfigPath = path.join(__dirname, '../backend/config/contracts.js');
    const backendDir = path.dirname(apiConfigPath);
    if (!fs.existsSync(backendDir)) {
      fs.mkdirSync(backendDir, { recursive: true });
    }
    fs.writeFileSync(apiConfigPath, `module.exports = ${JSON.stringify(apiConfig, null, 2)};`);
    console.log("💾 API configuration saved to:", apiConfigPath);

    console.log("\n🎉 Deployment completed successfully!");
    console.log("📋 Summary:");
    console.log(`   • ResourceMarketplace: ${resourceMarketplace.address}`);
    console.log(`   • ResourceToken: ${resourceToken.address}`);
    console.log(`   • Escrow: ${escrow.address}`);
    console.log(`   • Reputation: ${reputation.address}`);
    console.log(`   • Verifier: ${verifier.address}`);
    console.log(`   • MarketplaceFactory: ${marketplaceFactory.address}`);
    console.log(`\n💡 Network: ${network.name} (Chain ID: ${network.config.chainId || 31337})`);
    console.log(`🔧 Supported Tokens: ${Object.keys(SUPPORTED_TOKENS).join(', ')}`);

    return {
      resourceMarketplace,
      resourceToken,
      escrow,
      reputation,
      verifier,
      marketplaceFactory,
      deploymentInfo
    };

  } catch (error) {
    console.error("❌ Deployment failed:", error);
    process.exit(1);
  }
}

// Setup multi-cryptocurrency support
async function setupMultiCurrencySupport(escrowContract, supportedTokens) {
  // Add supported tokens to escrow contract
  for (const [symbol, tokenInfo] of Object.entries(supportedTokens)) {
    if (tokenInfo.address !== "0x0000000000000000000000000000000000000000") {
      // For ERC20 tokens, we would need to add them to a registry
      // For ETH, it's already supported by default
      console.log(`   • Added ${symbol} support`);
    }
  }
}

// Function to verify contracts on Etherscan
async function verifyContracts() {
  console.log("🔍 Verifying contracts on Etherscan...");
  
  try {
    await hre.run("verify:verify", {
      address: process.env.RESOURCE_TOKEN_ADDRESS,
      constructorArguments: []
    });
    console.log("✅ ResourceToken verified");
  } catch (error) {
    console.log("⚠️ ResourceToken verification failed:", error.message);
  }

  try {
    await hre.run("verify:verify", {
      address: process.env.ESCROW_ADDRESS,
      constructorArguments: []
    });
    console.log("✅ Escrow verified");
  } catch (error) {
    console.log("⚠️ Escrow verification failed:", error.message);
  }
  
  // Add more verifications for other contracts...
}

// Run the deployment
if (require.main === module) {
  main()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error(error);
      process.exit(1);
    });
}

module.exports = main;