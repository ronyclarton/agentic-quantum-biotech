// Web3.js Configuration and Connection Handling
class Web3Manager {
    constructor() {
        this.web3 = null;
        this.account = null;
        this.networkId = null;
        this.contracts = {};
        this.isConnected = false;
    }

    async initialize() {
        try {
            // Initialize Web3
            if (typeof window.ethereum !== 'undefined') {
                this.web3 = new Web3(window.ethereum);
                await this.setupEventListeners();
                console.log('✅ Web3 initialized successfully');
            } else {
                throw new Error('MetaMask not detected');
            }
        } catch (error) {
            console.error('❌ Web3 initialization failed:', error);
            throw error;
        }
    }

    async connectWallet() {
        try {
            if (!this.web3) {
                await this.initialize();
            }

            // Request account access
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });

            if (accounts.length === 0) {
                throw new Error('No accounts found');
            }

            this.account = accounts[0];
            this.networkId = await this.web3.eth.getChainId();
            
            // Load contract addresses and ABIs
            await this.loadContracts();
            
            this.isConnected = true;
            this.updateWalletUI();
            
            console.log('✅ Wallet connected:', this.account);
            return true;
        } catch (error) {
            console.error('❌ Wallet connection failed:', error);
            throw error;
        }
    }

    async disconnectWallet() {
        this.account = null;
        this.networkId = null;
        this.contracts = {};
        this.isConnected = false;
        this.updateWalletUI();
        
        console.log('🔌 Wallet disconnected');
    }

    async loadContracts() {
        try {
            const contractsConfig = {
                ResourceMarketplace: {
                    address: CONTRACT_ADDRESSES.ResourceMarketplace,
                    abi: await this.loadABI('ResourceMarketplace')
                },
                ResourceToken: {
                    address: CONTRACT_ADDRESSES.ResourceToken,
                    abi: await this.loadABI('ResourceToken')
                },
                Escrow: {
                    address: CONTRACT_ADDRESSES.Escrow,
                    abi: await this.loadABI('Escrow')
                },
                Reputation: {
                    address: CONTRACT_ADDRESSES.Reputation,
                    abi: await this.loadABI('Reputation')
                },
                Verifier: {
                    address: CONTRACT_ADDRESSES.Verifier,
                    abi: await this.loadABI('Verifier')
                }
            };

            // Initialize contract instances
            for (const [name, config] of Object.entries(contractsConfig)) {
                if (config.address && config.abi) {
                    this.contracts[name] = new this.web3.eth.Contract(config.abi, config.address);
                    console.log(`📄 Loaded ${name} contract`);
                }
            }
        } catch (error) {
            console.error('❌ Failed to load contracts:', error);
            throw error;
        }
    }

    async loadABI(contractName) {
        try {
            // In a real implementation, you would load ABIs from a JSON file or API
            // For now, we'll use the contract ABIs from the deployment
            const abiResponse = await fetch(`/js/abis/${contractName}.json`);
            if (!abiResponse.ok) {
                throw new Error(`Failed to load ${contractName} ABI`);
            }
            return await abiResponse.json();
        } catch (error) {
            console.warn(`⚠️ Could not load ${contractName} ABI:`, error.message);
            return [];
        }
    }

    setupEventListeners() {
        if (!window.ethereum) return;

        // Account change listener
        window.ethereum.on('accountsChanged', (accounts) => {
            if (accounts.length === 0) {
                this.disconnectWallet();
            } else if (accounts[0] !== this.account) {
                this.account = accounts[0];
                this.updateWalletUI();
            }
        });

        // Chain change listener
        window.ethereum.on('chainChanged', (chainId) => {
            console.log('🔗 Network changed to:', chainId);
            window.location.reload(); // Reload to ensure proper contract interaction
        });

        // Disconnect listener
        window.ethereum.on('disconnect', () => {
            this.disconnectWallet();
        });
    }

    updateWalletUI() {
        const connectBtn = document.getElementById('connect-wallet');
        const walletInfo = document.getElementById('wallet-info');
        const walletAddress = document.getElementById('wallet-address');
        const tokenBalance = document.getElementById('token-balance');
        const connectionStatus = document.getElementById('connection-status');
        const dashboard = document.getElementById('dashboard');

        if (this.isConnected && this.account) {
            // Show wallet info
            if (connectBtn) connectBtn.style.display = 'none';
            if (walletInfo) walletInfo.classList.remove('d-none');
            
            // Update address display
            if (walletAddress) {
                walletAddress.textContent = this.formatAddress(this.account);
            }
            
            // Load token balance
            this.loadTokenBalance();
            
            // Hide connection status and show dashboard
            if (connectionStatus) connectionStatus.classList.add('d-none');
            if (dashboard) dashboard.classList.remove('d-none');
            
            // Show main sections
            document.querySelectorAll('#marketplace, #my-resources, #requests, #reputation').forEach(section => {
                section.classList.remove('d-none');
            });
            
            // Setup real-time updates
            this.setupEventSubscriptions();
            
        } else {
            // Show connect button
            if (connectBtn) connectBtn.style.display = 'inline-block';
            if (walletInfo) walletInfo.classList.add('d-none');
            
            // Show connection status
            if (connectionStatus) connectionStatus.classList.remove('d-none');
            if (dashboard) dashboard.classList.add('d-none');
            
            // Hide main sections
            document.querySelectorAll('#marketplace, #my-resources, #requests, #reputation').forEach(section => {
                section.classList.add('d-none');
            });
        }
    }

    async loadTokenBalance() {
        try {
            if (!this.contracts.ResourceToken || !this.account) return;
            
            const balance = await this.contracts.ResourceToken.methods.balanceOf(this.account).call();
            const formattedBalance = this.web3.utils.fromWei(balance, 'ether');
            
            const tokenBalanceElement = document.getElementById('token-balance');
            if (tokenBalanceElement) {
                tokenBalanceElement.textContent = Number(formattedBalance).toFixed(2);
            }
        } catch (error) {
            console.error('❌ Failed to load token balance:', error);
        }
    }

    setupEventSubscriptions() {
        // Subscribe to contract events for real-time updates
        try {
            if (this.contracts.ResourceMarketplace) {
                // Subscribe to resource events
                this.contracts.ResourceMarketplace.events.ResourceAdded({
                    filter: { provider: this.account }
                }).on('data', (event) => {
                    console.log('📝 New resource added:', event.returnValues);
                    this.refreshResourcesList();
                });

                this.contracts.ResourceMarketplace.events.ResourcePurchased({
                    filter: { buyer: this.account }
                }).on('data', (event) => {
                    console.log('🛒 Resource purchased:', event.returnValues);
                    this.refreshDashboard();
                    this.showNotification('success', 'Resource purchased successfully!');
                });
            }

            if (this.contracts.Escrow) {
                // Subscribe to escrow events
                this.contracts.Escrow.events.PaymentReleased({
                    filter: { seller: this.account }
                }).on('data', (event) => {
                    console.log('💰 Payment released:', event.returnValues);
                    this.refreshDashboard();
                    this.showNotification('success', 'Payment received!');
                });
            }
        } catch (error) {
            console.error('❌ Failed to setup event subscriptions:', error);
        }
    }

    async registerUser(name, email) {
        try {
            if (!this.contracts.ResourceMarketplace) {
                throw new Error('ResourceMarketplace contract not loaded');
            }

            const method = this.contracts.ResourceMarketplace.methods.registerUser(name, email);
            const gas = await method.estimateGas({ from: this.account });
            
            return await method.send({
                from: this.account,
                gas: gas
            });
        } catch (error) {
            console.error('❌ Failed to register user:', error);
            throw error;
        }
    }

    async addResource(name, description, resourceType, price) {
        try {
            if (!this.contracts.ResourceMarketplace) {
                throw new Error('ResourceMarketplace contract not loaded');
            }

            const method = this.contracts.ResourceMarketplace.methods.addResource(
                name, description, resourceType, price
            );
            const gas = await method.estimateGas({ from: this.account });
            
            return await method.send({
                from: this.account,
                gas: gas
            });
        } catch (error) {
            console.error('❌ Failed to add resource:', error);
            throw error;
        }
    }

    async requestResource(resourceId) {
        try {
            if (!this.contracts.ResourceMarketplace) {
                throw new Error('ResourceMarketplace contract not loaded');
            }

            const method = this.contracts.ResourceMarketplace.methods.requestResource(resourceId);
            const gas = await method.estimateGas({ from: this.account });
            
            return await method.send({
                from: this.account,
                gas: gas
            });
        } catch (error) {
            console.error('❌ Failed to request resource:', error);
            throw error;
        }
    }

    async purchaseResource(resourceId) {
        try {
            if (!this.contracts.ResourceMarketplace) {
                throw new Error('ResourceMarketplace contract not loaded');
            }

            const method = this.contracts.ResourceMarketplace.methods.purchaseResource(resourceId);
            const gas = await method.estimateGas({ from: this.account });
            
            return await method.send({
                from: this.account,
                gas: gas
            });
        } catch (error) {
            console.error('❌ Failed to purchase resource:', error);
            throw error;
        }
    }

    async rateResource(resourceId, rating, comment) {
        try {
            if (!this.contracts.Reputation) {
                throw new Error('Reputation contract not loaded');
            }

            const method = this.contracts.Reputation.methods.rateResource(resourceId, rating, comment);
            const gas = await method.estimateGas({ from: this.account });
            
            return await method.send({
                from: this.account,
                gas: gas
            });
        } catch (error) {
            console.error('❌ Failed to rate resource:', error);
            throw error;
        }
    }

    async rateUser(userAddress, rating, comment) {
        try {
            if (!this.contracts.Reputation) {
                throw new Error('Reputation contract not loaded');
            }

            const method = this.contracts.Reputation.methods.rateUser(userAddress, rating, comment);
            const gas = await method.estimateGas({ from: this.account });
            
            return await method.send({
                from: this.account,
                gas: gas
            });
        } catch (error) {
            console.error('❌ Failed to rate user:', error);
            throw error;
        }
    }

    // Utility Methods
    formatAddress(address) {
        if (!address) return '';
        return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
    }

    formatWei(wei) {
        return this.web3.utils.fromWei(wei, 'ether');
    }

    toWei(amount) {
        return this.web3.utils.toWei(amount, 'ether');
    }

    showNotification(type, message) {
        const toastId = type === 'success' ? 'success-toast' : 'error-toast';
        const messageId = type === 'success' ? 'success-message' : 'error-message';
        
        const messageElement = document.getElementById(messageId);
        if (messageElement) {
            messageElement.textContent = message;
        }
        
        const toast = new bootstrap.Toast(document.getElementById(toastId));
        toast.show();
    }

    showLoading(message = 'Processing transaction...') {
        const overlay = document.getElementById('loading-overlay');
        const messageElement = document.getElementById('loading-message');
        
        if (overlay && messageElement) {
            messageElement.textContent = message;
            overlay.classList.remove('d-none');
        }
    }

    hideLoading() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.add('d-none');
        }
    }

    async refreshResourcesList() {
        // This will be implemented in the marketplace.js file
        if (window.marketplaceManager) {
            await window.marketplaceManager.loadResources();
        }
    }

    async refreshDashboard() {
        // This will be implemented in the marketplace.js file
        if (window.marketplaceManager) {
            await window.marketplaceManager.loadDashboard();
        }
    }

    // Network and Gas Management
    async getNetworkInfo() {
        try {
            const chainId = await this.web3.eth.getChainId();
            const networkNames = {
                1: 'Mainnet',
                3: 'Ropsten',
                4: 'Rinkeby',
                5: 'Goerli',
                42: 'Kovan',
                11155111: 'Sepolia',
                137: 'Polygon',
                80001: 'Mumbai',
                31337: 'Hardhat Local'
            };
            
            return {
                chainId,
                name: networkNames[chainId] || `Unknown Network (${chainId})`
            };
        } catch (error) {
            console.error('❌ Failed to get network info:', error);
            return { chainId: 0, name: 'Unknown' };
        }
    }

    async estimateGas(method) {
        try {
            return await method.estimateGas({ from: this.account });
        } catch (error) {
            console.warn('⚠️ Gas estimation failed, using default:', error.message);
            return 200000; // Default gas limit
        }
    }

    async waitForTransactionReceipt(txHash) {
        try {
            const receipt = await this.web3.eth.waitForTransactionReceipt(txHash);
            return receipt;
        } catch (error) {
            console.error('❌ Transaction failed:', error);
            throw error;
        }
    }
}

// Initialize global Web3 manager
window.web3Manager = new Web3Manager();