// Marketplace Management - Core Business Logic
class MarketplaceManager {
    constructor() {
        this.resources = [];
        this.myResources = [];
        this.requests = [];
        this.userProfile = null;
        this.currentFilter = {
            search: '',
            type: '',
            sortBy: 'newest'
        };
    }

    async initialize() {
        try {
            await this.loadResources();
            await this.loadUserProfile();
            await this.loadDashboard();
            this.setupEventListeners();
            console.log('✅ Marketplace manager initialized');
        } catch (error) {
            console.error('❌ Failed to initialize marketplace manager:', error);
            throw error;
        }
    }

    async loadResources() {
        try {
            if (!window.web3Manager.contracts.ResourceMarketplace) {
                console.warn('⚠️ ResourceMarketplace contract not loaded yet');
                return;
            }

            const contract = window.web3Manager.contracts.ResourceMarketplace;
            const account = window.web3Manager.account;

            // Get total resources count (this would need to be tracked in the contract)
            // For now, we'll simulate with a fixed range
            const totalResources = 100; // This should be dynamic in a real implementation

            this.resources = [];
            
            for (let i = 1; i <= Math.min(totalResources, 20); i++) { // Limit to 20 for demo
                try {
                    const resource = await this.getResourceDetails(i);
                    if (resource && resource.isActive) {
                        this.resources.push(resource);
                    }
                } catch (error) {
                    // Resource might not exist, continue
                    continue;
                }
            }

            this.renderResources();
            console.log(`📦 Loaded ${this.resources.length} resources`);
        } catch (error) {
            console.error('❌ Failed to load resources:', error);
        }
    }

    async getResourceDetails(resourceId) {
        try {
            const contract = window.web3Manager.contracts.ResourceMarketplace;
            const result = await contract.methods.getResource(resourceId).call();
            
            if (result[0] === '0' || result[0] === '0x0000000000000000000000000000000000000000000000000000000000000000') {
                return null; // Resource doesn't exist
            }

            return {
                id: parseInt(result[0]),
                name: result[1],
                description: result[2],
                resourceType: result[3],
                price: parseInt(result[4]),
                provider: result[5],
                isActive: result[6] === true,
                isVerified: result[7] === true,
                createdAt: parseInt(result[8]) * 1000, // Convert to milliseconds
                providerName: await this.getUserName(result[5]),
                averageRating: await this.getResourceRating(resourceId),
                ratingCount: await this.getResourceRatingCount(resourceId)
            };
        } catch (error) {
            console.warn(`⚠️ Could not load resource ${resourceId}:`, error.message);
            return null;
        }
    }

    async getUserName(userAddress) {
        try {
            if (!window.web3Manager.contracts.ResourceMarketplace) return 'Unknown User';
            
            const result = await window.web3Manager.contracts.ResourceMarketplace.methods.getUser(userAddress).call();
            return result[0] || 'Unknown User';
        } catch (error) {
            return 'Unknown User';
        }
    }

    async getResourceRating(resourceId) {
        try {
            if (!window.web3Manager.contracts.Reputation) return 0;
            
            const result = await window.web3Manager.contracts.Reputation.methods.getResourceAverageRating(resourceId).call();
            return parseInt(result) / 100; // Convert from scaled integer
        } catch (error) {
            return 0;
        }
    }

    async getResourceRatingCount(resourceId) {
        try {
            if (!window.web3Manager.contracts.Reputation) return 0;
            
            const result = await window.web3Manager.contracts.Reputation.methods.getResourceRatingCount(resourceId).call();
            return parseInt(result);
        } catch (error) {
            return 0;
        }
    }

    renderResources() {
        const container = document.getElementById('resources-grid');
        if (!container) return;

        // Filter resources
        let filteredResources = this.resources.filter(resource => {
            const matchesSearch = !this.currentFilter.search || 
                resource.name.toLowerCase().includes(this.currentFilter.search.toLowerCase()) ||
                resource.description.toLowerCase().includes(this.currentFilter.search.toLowerCase());
            
            const matchesType = !this.currentFilter.type || 
                resource.resourceType === this.currentFilter.type;
            
            return matchesSearch && matchesType;
        });

        // Sort resources
        filteredResources.sort((a, b) => {
            switch (this.currentFilter.sortBy) {
                case 'price-low':
                    return a.price - b.price;
                case 'price-high':
                    return b.price - a.price;
                case 'rating':
                    return b.averageRating - a.averageRating;
                case 'newest':
                default:
                    return b.createdAt - a.createdAt;
            }
        });

        if (filteredResources.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center">
                    <div class="alert alert-info">
                        <i class="fas fa-search me-2"></i>
                        No resources found matching your criteria.
                    </div>
                </div>
            `;
            return;
        }

        container.innerHTML = filteredResources.map(resource => this.createResourceCard(resource)).join('');
    }

    createResourceCard(resource) {
        const verificationBadge = resource.isVerified ? 
            '<div class="verification-badge"><i class="fas fa-check"></i></div>' : '';
        
        const typeBadge = this.getTypeBadge(resource.resourceType);
        const ratingStars = this.generateRatingStars(resource.averageRating);
        const priceFormatted = this.formatPrice(resource.price);
        
        return `
            <div class="col-md-4 mb-4">
                <div class="card resource-card h-100" data-resource-id="${resource.id}">
                    <div class="position-relative">
                        <div class="resource-avatar">
                            ${resource.providerName.charAt(0).toUpperCase()}
                        </div>
                        ${verificationBadge}
                    </div>
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0">${resource.name}</h5>
                            ${typeBadge}
                        </div>
                        <p class="card-text text-muted small mb-3">${this.truncateText(resource.description, 100)}</p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="resource-price">${priceFormatted} RST</span>
                                <div class="text-end">
                                    <div class="small text-muted">by ${this.formatAddress(resource.provider)}</div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="star-rating small">
                                    ${ratingStars}
                                    <span class="text-muted ms-1">(${resource.ratingCount})</span>
                                </div>
                                <small class="text-muted">${this.formatDate(resource.createdAt)}</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    getTypeBadge(type) {
        const badges = {
            digital: '<span class="badge bg-primary">Digital</span>',
            physical: '<span class="badge bg-success">Physical</span>',
            service: '<span class="badge bg-info">Service</span>',
            data: '<span class="badge bg-warning">Data</span>'
        };
        return badges[type] || `<span class="badge bg-secondary">${type}</span>`;
    }

    generateRatingStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star text-warning"></i>';
        }
        
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt text-warning"></i>';
        }
        
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star text-warning"></i>';
        }
        
        return stars;
    }

    formatPrice(price) {
        return (parseInt(price) / Math.pow(10, 18)).toFixed(2); // Assuming 18 decimals
    }

    formatAddress(address) {
        return window.web3Manager.formatAddress(address);
    }

    formatDate(timestamp) {
        return new Date(timestamp).toLocaleDateString();
    }

    truncateText(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    async loadUserProfile() {
        try {
            if (!window.web3Manager.account) return;
            
            const contract = window.web3Manager.contracts.ResourceMarketplace;
            if (!contract) return;

            const result = await contract.methods.getUser(window.web3Manager.account).call();
            this.userProfile = {
                name: result[0],
                email: result[1],
                totalResources: parseInt(result[2]),
                totalSales: parseInt(result[3]),
                isVerified: result[4],
                isActive: result[5]
            };
        } catch (error) {
            console.warn('⚠️ Could not load user profile:', error.message);
        }
    }

    async loadDashboard() {
        try {
            if (!this.userProfile) {
                await this.loadUserProfile();
            }

            if (!this.userProfile) return;

            // Update dashboard stats
            this.updateElement('total-resources', this.userProfile.totalResources);
            this.updateElement('total-sales', this.userProfile.totalSales);
            this.updateElement('reputation-score', await this.getUserReputationScore());
            this.updateElement('active-requests', await this.getActiveRequestsCount());

            // Load my resources
            await this.loadMyResources();
            
            // Load requests
            await this.loadRequests();
            
            // Load reputation details
            await this.loadReputationDetails();
        } catch (error) {
            console.error('❌ Failed to load dashboard:', error);
        }
    }

    async getUserReputationScore() {
        try {
            if (!window.web3Manager.contracts.Reputation) return 0;
            
            const result = await window.web3Manager.contracts.Reputation.methods
                .calculateTrustScore(window.web3Manager.account).call();
            return parseInt(result);
        } catch (error) {
            return 0;
        }
    }

    async getActiveRequestsCount() {
        // This would need to be implemented in the contract
        // For now, return a placeholder
        return 0;
    }

    async loadMyResources() {
        try {
            const contract = window.web3Manager.contracts.ResourceMarketplace;
            if (!contract) return;

            const count = await contract.methods.getUserResourceCount(window.web3Manager.account).call();
            const resourceCount = parseInt(count);

            const container = document.getElementById('my-resources-list');
            if (!container) return;

            if (resourceCount === 0) {
                container.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            You haven't added any resources yet.
                        </div>
                    </div>
                `;
                return;
            }

            this.myResources = [];
            for (let i = 0; i < Math.min(resourceCount, 10); i++) { // Limit to 10 for demo
                // In a real implementation, you'd get the actual resource IDs
                // For now, we'll create placeholder data
                this.myResources.push({
                    id: i + 1,
                    name: `My Resource ${i + 1}`,
                    description: 'This is a sample resource',
                    resourceType: 'digital',
                    price: 100,
                    isActive: true,
                    isVerified: Math.random() > 0.5,
                    createdAt: Date.now() - (i * 24 * 60 * 60 * 1000), // Days ago
                    averageRating: Math.random() * 5,
                    ratingCount: Math.floor(Math.random() * 10)
                });
            }

            this.renderMyResources();
        } catch (error) {
            console.error('❌ Failed to load my resources:', error);
        }
    }

    renderMyResources() {
        const container = document.getElementById('my-resources-list');
        if (!container) return;

        container.innerHTML = this.myResources.map(resource => this.createMyResourceCard(resource)).join('');
    }

    createMyResourceCard(resource) {
        const statusBadge = resource.isActive ? 
            '<span class="badge bg-success">Active</span>' : 
            '<span class="badge bg-secondary">Inactive</span>';
        
        const verificationBadge = resource.isVerified ? 
            '<i class="fas fa-check-circle text-success ms-2" title="Verified"></i>' : '';

        return `
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h6 class="card-title mb-0">${resource.name}</h6>
                            ${statusBadge}${verificationBadge}
                        </div>
                        <p class="card-text text-muted small">${this.truncateText(resource.description, 80)}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="font-weight-bold">${this.formatPrice(resource.price)} RST</span>
                            <div class="text-end">
                                <div class="small text-warning">
                                    ${this.generateRatingStars(resource.averageRating)}
                                </div>
                                <small class="text-muted">${resource.ratingCount} reviews</small>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button class="btn btn-sm btn-outline-primary me-2" onclick="editResource(${resource.id})">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-sm btn-outline-danger" onclick="deleteResource(${resource.id})">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async loadRequests() {
        // Load requests to approve and my requests
        this.renderRequests();
    }

    renderRequests() {
        const requestsToApprove = document.getElementById('requests-to-approve');
        const myRequests = document.getElementById('my-requests');

        // Placeholder data - in real implementation, load from contract
        const sampleRequests = [
            {
                id: 1,
                requester: '0x1234...5678',
                resourceName: 'Advanced Data Analytics Guide',
                amount: 50,
                status: 'pending',
                createdAt: Date.now() - 3600000 // 1 hour ago
            }
        ];

        if (requestsToApprove) {
            if (sampleRequests.length === 0) {
                requestsToApprove.innerHTML = '<div class="text-muted">No pending requests.</div>';
            } else {
                requestsToApprove.innerHTML = sampleRequests.map(request => this.createRequestCard(request, true)).join('');
            }
        }

        if (myRequests) {
            if (sampleRequests.length === 0) {
                myRequests.innerHTML = '<div class="text-muted">No requests made.</div>';
            } else {
                myRequests.innerHTML = sampleRequests.map(request => this.createRequestCard(request, false)).join('');
            }
        }
    }

    createRequestCard(request, isToApprove) {
        const statusClass = {
            pending: 'status-pending',
            approved: 'status-verified',
            completed: 'status-completed',
            disputed: 'status-disputed'
        }[request.status] || 'status-pending';

        return `
            <div class="card mb-2">
                <div class="card-body py-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">${request.resourceName}</h6>
                            <p class="card-text small text-muted mb-0">
                                From: ${this.formatAddress(request.requester)} • 
                                ${this.formatDate(request.createdAt)}
                            </p>
                        </div>
                        <div class="text-end">
                            <div class="font-weight-bold">${this.formatPrice(request.amount)} RST</div>
                            <span class="status-badge ${statusClass}">${request.status.charAt(0).toUpperCase() + request.status.slice(1)}</span>
                        </div>
                    </div>
                    ${isToApprove ? `
                        <div class="mt-2">
                            <button class="btn btn-sm btn-success me-2" onclick="approveRequest(${request.id})">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="rejectRequest(${request.id})">
                                <i class="fas fa-times"></i> Reject
                            </button>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }

    async loadReputationDetails() {
        try {
            // Load user's rating details
            const rating = await this.getUserReputationScore();
            const ratingCount = await this.getUserRatingCount();

            this.updateElement('my-rating', rating.toFixed(1));
            this.updateElement('my-rating-count', ratingCount);

            // Load recent activity
            this.loadRecentActivity();
        } catch (error) {
            console.error('❌ Failed to load reputation details:', error);
        }
    }

    async getUserRatingCount() {
        try {
            if (!window.web3Manager.contracts.Reputation) return 0;
            
            const result = await window.web3Manager.contracts.Reputation.methods
                .getUserRatingCount(window.web3Manager.account).call();
            return parseInt(result);
        } catch (error) {
            return 0;
        }
    }

    loadRecentActivity() {
        const container = document.getElementById('recent-activity');
        if (!container) return;

        // Placeholder activity data
        const activities = [
            {
                type: 'resource_sale',
                description: 'Sold "AI Development Guide" for 100 RST',
                timestamp: Date.now() - 3600000,
                status: 'completed'
            },
            {
                type: 'resource_rated',
                description: 'Received 5-star rating for "Blockchain Tutorial"',
                timestamp: Date.now() - 7200000,
                status: 'positive'
            }
        ];

        container.innerHTML = activities.map(activity => this.createActivityItem(activity)).join('');
    }

    createActivityItem(activity) {
        const icons = {
            resource_sale: 'fas fa-shopping-cart',
            resource_rated: 'fas fa-star',
            resource_purchased: 'fas fa-download',
            request_approved: 'fas fa-check-circle'
        };

        const icon = icons[activity.type] || 'fas fa-info-circle';
        const statusColors = {
            completed: 'text-success',
            positive: 'text-success',
            pending: 'text-warning',
            negative: 'text-danger'
        };

        return `
            <div class="activity-item mb-2 pb-2 border-bottom">
                <div class="d-flex align-items-center">
                    <i class="${icon} me-2 ${statusColors[activity.status] || 'text-muted'}"></i>
                    <div class="flex-grow-1">
                        <p class="mb-0 small">${activity.description}</p>
                        <small class="text-muted">${this.formatDate(activity.timestamp)}</small>
                    </div>
                </div>
            </div>
        `;
    }

    // Event Handling
    setupEventListeners() {
        // Search functionality
        const searchInput = document.getElementById('search-resources');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.currentFilter.search = e.target.value;
                this.renderResources();
            });
        }

        // Filter by type
        const filterType = document.getElementById('filter-type');
        if (filterType) {
            filterType.addEventListener('change', (e) => {
                this.currentFilter.type = e.target.value;
                this.renderResources();
            });
        }

        // Sort functionality
        const sortBy = document.getElementById('sort-by');
        if (sortBy) {
            sortBy.addEventListener('change', (e) => {
                this.currentFilter.sortBy = e.target.value;
                this.renderResources();
            });
        }

        // Add resource form
        const addResourceForm = document.getElementById('add-resource-form');
        if (addResourceForm) {
            addResourceForm.addEventListener('submit', (e) => {
                this.handleAddResource(e);
            });
        }

        // Resource card clicks
        const resourcesGrid = document.getElementById('resources-grid');
        if (resourcesGrid) {
            resourcesGrid.addEventListener('click', (e) => {
                const card = e.target.closest('.resource-card');
                if (card) {
                    const resourceId = card.dataset.resourceId;
                    this.showResourceDetail(resourceId);
                }
            });
        }
    }

    async handleAddResource(event) {
        event.preventDefault();
        
        try {
            window.web3Manager.showLoading('Adding your resource to the marketplace...');
            
            const formData = new FormData(event.target);
            const resourceData = {
                name: document.getElementById('resource-name').value,
                description: document.getElementById('resource-description').value,
                resourceType: document.getElementById('resource-type').value,
                price: window.web3Manager.toWei(document.getElementById('resource-price').value)
            };

            const result = await window.web3Manager.addResource(
                resourceData.name,
                resourceData.description,
                resourceData.resourceType,
                resourceData.price
            );

            // Close modal and refresh
            const modal = bootstrap.Modal.getInstance(document.getElementById('addResourceModal'));
            modal.hide();
            
            event.target.reset();
            await this.loadResources();
            await this.loadDashboard();
            
            window.web3Manager.showNotification('success', 'Resource added successfully!');
            
        } catch (error) {
            console.error('❌ Failed to add resource:', error);
            window.web3Manager.showNotification('error', 'Failed to add resource: ' + error.message);
        } finally {
            window.web3Manager.hideLoading();
        }
    }

    showResourceDetail(resourceId) {
        const resource = this.resources.find(r => r.id == resourceId);
        if (!resource) return;

        // Populate modal content
        document.getElementById('resource-detail-title').textContent = resource.name;
        
        const content = document.getElementById('resource-detail-content');
        content.innerHTML = `
            <div class="row">
                <div class="col-md-8">
                    <h4>${resource.name}</h4>
                    <p class="text-muted">${resource.description}</p>
                    <div class="mb-3">
                        <strong>Type:</strong> ${resource.resourceType.charAt(0).toUpperCase() + resource.resourceType.slice(1)}
                    </div>
                    <div class="mb-3">
                        <strong>Provider:</strong> ${resource.providerName} (${this.formatAddress(resource.provider)})
                        ${resource.isVerified ? '<i class="fas fa-check-circle text-success ms-1"></i>' : ''}
                    </div>
                    <div class="mb-3">
                        <strong>Rating:</strong> 
                        <div class="star-rating">${this.generateRatingStars(resource.averageRating)}</div>
                        <small class="text-muted">(${resource.ratingCount} reviews)</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h5 class="text-primary">${this.formatPrice(resource.price)} RST</h5>
                            <p class="text-muted small">Price in Resource Tokens</p>
                            <button class="btn btn-primary w-100" onclick="requestResource(${resource.id})">
                                <i class="fas fa-handshake me-1"></i>Request Access
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Store resource ID for purchase
        document.getElementById('purchase-resource').dataset.resourceId = resourceId;
        
        const modal = new bootstrap.Modal(document.getElementById('resourceDetailModal'));
        modal.show();
    }

    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }
}

// Global helper functions for HTML onclick handlers
window.requestResource = async function(resourceId) {
    try {
        window.web3Manager.showLoading('Requesting resource access...');
        
        await window.web3Manager.requestResource(resourceId);
        
        window.web3Manager.showNotification('success', 'Resource request submitted successfully!');
        
        // Refresh UI
        await window.marketplaceManager.loadRequests();
        
    } catch (error) {
        console.error('❌ Failed to request resource:', error);
        window.web3Manager.showNotification('error', 'Failed to request resource: ' + error.message);
    } finally {
        window.web3Manager.hideLoading();
    }
};

window.purchaseResource = async function(resourceId) {
    try {
        window.web3Manager.showLoading('Processing purchase...');
        
        await window.web3Manager.purchaseResource(resourceId);
        
        window.web3Manager.showNotification('success', 'Resource purchased successfully!');
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('resourceDetailModal'));
        modal.hide();
        
        // Refresh UI
        await window.marketplaceManager.loadDashboard();
        
    } catch (error) {
        console.error('❌ Failed to purchase resource:', error);
        window.web3Manager.showNotification('error', 'Failed to purchase resource: ' + error.message);
    } finally {
        window.web3Manager.hideLoading();
    }
};

window.approveRequest = async function(requestId) {
    try {
        window.web3Manager.showLoading('Approving request...');
        
        // This would need to be implemented in the contract
        // await window.web3Manager.approveRequest(requestId);
        
        window.web3Manager.showNotification('success', 'Request approved successfully!');
        
        // Refresh UI
        await window.marketplaceManager.loadRequests();
        
    } catch (error) {
        console.error('❌ Failed to approve request:', error);
        window.web3Manager.showNotification('error', 'Failed to approve request: ' + error.message);
    } finally {
        window.web3Manager.hideLoading();
    }
};

window.rejectRequest = async function(requestId) {
    try {
        window.web3Manager.showLoading('Rejecting request...');
        
        // This would need to be implemented in the contract
        // await window.web3Manager.rejectRequest(requestId);
        
        window.web3Manager.showNotification('success', 'Request rejected successfully!');
        
        // Refresh UI
        await window.marketplaceManager.loadRequests();
        
    } catch (error) {
        console.error('❌ Failed to reject request:', error);
        window.web3Manager.showNotification('error', 'Failed to reject request: ' + error.message);
    } finally {
        window.web3Manager.hideLoading();
    }
};

window.editResource = function(resourceId) {
    // Implement resource editing
    console.log('Edit resource:', resourceId);
};

window.deleteResource = async function(resourceId) {
    try {
        if (!confirm('Are you sure you want to delete this resource?')) return;
        
        window.web3Manager.showLoading('Deleting resource...');
        
        // This would need to be implemented in the contract
        // await window.web3Manager.deleteResource(resourceId);
        
        window.web3Manager.showNotification('success', 'Resource deleted successfully!');
        
        // Refresh UI
        await window.marketplaceManager.loadMyResources();
        
    } catch (error) {
        console.error('❌ Failed to delete resource:', error);
        window.web3Manager.showNotification('error', 'Failed to delete resource: ' + error.message);
    } finally {
        window.web3Manager.hideLoading();
    }
};

// Initialize global marketplace manager
window.marketplaceManager = new MarketplaceManager();