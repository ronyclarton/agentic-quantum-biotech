/**
 * Alert Management Service
 * Rule evaluation and notification dispatch system
 * Deno Edge Function
 */

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, data } = await req.json();
        let result = {};

        switch (action) {
            case 'evaluate_alerts':
                result = await evaluateAlertRules(data);
                break;
            case 'create_alert_rule':
                result = await createAlertRule(data);
                break;
            case 'send_notification':
                result = await sendNotification(data);
                break;
            case 'resolve_alert':
                result = await resolveAlert(data.alert_id);
                break;
            case 'get_active_alerts':
                result = await getActiveAlerts();
                break;
            case 'test_notification':
                result = await testNotification(data);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ success: true, data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Alert management error:', error);
        return new Response(JSON.stringify({
            error: {
                code: 'ALERT_MANAGEMENT_ERROR',
                message: error.message
            }
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function evaluateAlertRules(data) {
    const { metric_type, metric_data } = data;
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    // Get active alert rules for this metric type
    const rulesResponse = await fetch(
        `${supabaseUrl}/rest/v1/alert_rules?metric_type=eq.${metric_type}&is_active=eq.true`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!rulesResponse.ok) {
        throw new Error('Failed to fetch alert rules');
    }
    
    const rules = await rulesResponse.json();
    const triggeredAlerts = [];
    
    for (const rule of rules) {
        const isTriggered = await evaluateRule(rule, metric_data);
        
        if (isTriggered) {
            const alertId = await createAlertNotification(rule, metric_data);
            triggeredAlerts.push({
                rule_id: rule.id,
                rule_name: rule.rule_name,
                alert_id: alertId,
                metric_value: extractMetricValue(metric_data, rule.metric_type),
                threshold: rule.threshold_value
            });
            
            // Send notifications
            await sendAlertNotifications(rule, metric_data, alertId);
        }
    }
    
    return {
        metric_type,
        rules_evaluated: rules.length,
        alerts_triggered: triggeredAlerts.length,
        triggered_alerts: triggeredAlerts,
        evaluation_time: new Date().toISOString()
    };
}

async function evaluateRule(rule, metricData) {
    const metricValue = extractMetricValue(metricData, rule.metric_type);
    
    if (metricValue === null || metricValue === undefined) {
        return false;
    }
    
    switch (rule.condition_operator) {
        case '>':
            return metricValue > rule.threshold_value;
        case '<':
            return metricValue < rule.threshold_value;
        case '>=':
            return metricValue >= rule.threshold_value;
        case '<=':
            return metricValue <= rule.threshold_value;
        case '=':
            return metricValue === rule.threshold_value;
        case '!=':
            return metricValue !== rule.threshold_value;
        case 'between':
            return metricValue >= rule.threshold_value && metricValue <= rule.threshold_value_high;
        default:
            return false;
    }
}

function extractMetricValue(metricData, metricType) {
    // Map metric type to actual value in metric data
    const metricMapping = {
        'training_accuracy': metricData.accuracy,
        'training_loss': metricData.loss_value,
        'gpu_utilization': metricData.gpu_utilization,
        'cpu_utilization': metricData.cpu_utilization,
        'memory_usage': metricData.memory_usage,
        'temperature': metricData.temperature,
        'anomaly_score': metricData.anomaly_score,
        'cost_per_hour': metricData.cost_per_hour
    };
    
    return metricMapping[metricType] || null;
}

async function createAlertRule(ruleData) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const rule = {
        rule_name: ruleData.rule_name,
        metric_type: ruleData.metric_type,
        condition_operator: ruleData.condition_operator,
        threshold_value: ruleData.threshold_value,
        threshold_value_high: ruleData.threshold_value_high,
        time_window_minutes: ruleData.time_window_minutes || 5,
        severity: ruleData.severity || 'medium',
        notification_channels: ruleData.notification_channels || ['email'],
        is_active: ruleData.is_active !== undefined ? ruleData.is_active : true
    };
    
    const response = await fetch(`${supabaseUrl}/rest/v1/alert_rules`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(rule)
    });
    
    if (!response.ok) {
        throw new Error('Failed to create alert rule');
    }
    
    return {
        rule_id: ruleData.rule_name,
        message: 'Alert rule created successfully',
        rule_data: rule
    };
}

async function createAlertNotification(rule, metricData) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const notificationData = {
        alert_rule_id: rule.id,
        notification_channel: 'system', // Primary channel
        recipient: 'system',
        message: generateAlertMessage(rule, metricData),
        status: 'pending'
    };
    
    const response = await fetch(`${supabaseUrl}/rest/v1/alert_notifications`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(notificationData)
    });
    
    if (!response.ok) {
        throw new Error('Failed to create alert notification');
    }
    
    return notificationData.message; // Return message ID or similar
}

function generateAlertMessage(rule, metricData) {
    const metricValue = extractMetricValue(metricData, rule.metric_type);
    const timestamp = new Date().toISOString();
    
    return `ALERT: ${rule.rule_name}
Severity: ${rule.severity}
Metric: ${rule.metric_type}
Value: ${metricValue}
Threshold: ${rule.threshold_value} ${rule.condition_operator}
Time: ${timestamp}
Description: Metric ${rule.metric_type} ${rule.condition_operator} ${rule.threshold_value}`;
}

async function sendAlertNotifications(rule, metricData, alertId) {
    const channels = rule.notification_channels || ['email'];
    const notifications = [];
    
    for (const channel of channels) {
        try {
            const result = await sendNotification({
                channel: channel,
                rule: rule,
                metricData: metricData,
                alertId: alertId,
                recipients: getRecipientsForChannel(channel, rule)
            });
            notifications.push({
                channel: channel,
                status: 'success',
                result: result
            });
        } catch (error) {
            notifications.push({
                channel: channel,
                status: 'failed',
                error: error.message
            });
        }
    }
    
    return notifications;
}

function getRecipientsForChannel(channel, rule) {
    // This would typically fetch recipients from a configuration
    // For now, return default recipients based on severity
    const recipients = {
        'email': rule.severity === 'critical' ? ['admin@company.com'] : ['monitoring@company.com'],
        'slack': ['#alerts'],
        'webhook': ['https://hooks.company.com/alerts']
    };
    
    return recipients[channel] || ['admin@company.com'];
}

async function sendNotification(data) {
    const { channel, rule, metricData, alertId, recipients } = data;
    
    switch (channel) {
        case 'email':
            return await sendEmailNotification(recipients, rule, metricData, alertId);
        case 'slack':
            return await sendSlackNotification(recipients, rule, metricData, alertId);
        case 'webhook':
            return await sendWebhookNotification(recipients, rule, metricData, alertId);
        case 'sms':
            return await sendSMSNotification(recipients, rule, metricData, alertId);
        default:
            throw new Error(`Unknown notification channel: ${channel}`);
    }
}

async function sendEmailNotification(recipients, rule, metricData, alertId) {
    const metricValue = extractMetricValue(metricData, rule.metric_type);
    const subject = `ALERT: ${rule.rule_name} (${rule.severity.toUpperCase()})`;
    
    const body = `
        <h2>Infrastructure Alert</h2>
        <p><strong>Rule:</strong> ${rule.rule_name}</p>
        <p><strong>Severity:</strong> ${rule.severity}</p>
        <p><strong>Metric:</strong> ${rule.metric_type}</p>
        <p><strong>Current Value:</strong> ${metricValue}</p>
        <p><strong>Threshold:</strong> ${rule.threshold_value} ${rule.condition_operator}</p>
        <p><strong>Time:</strong> ${new Date().toISOString()}</p>
        <p><strong>Alert ID:</strong> ${alertId}</p>
        
        <h3>Context</h3>
        <pre>${JSON.stringify(metricData, null, 2)}</pre>
    `;
    
    // Simulate email sending - in real implementation, integrate with email service
    console.log('Email notification:', { recipients, subject, body });
    
    return {
        status: 'sent',
        recipients: recipients,
        subject: subject,
        timestamp: new Date().toISOString()
    };
}

async function sendSlackNotification(recipients, rule, metricData, alertId) {
    const metricValue = extractMetricValue(metricData, rule.metric_type);
    const color = rule.severity === 'critical' ? 'danger' : 
                 rule.severity === 'high' ? 'warning' : 'good';
    
    const slackMessage = {
        channel: recipients[0],
        username: 'Monitoring Bot',
        attachments: [{
            color: color,
            title: `Alert: ${rule.rule_name}`,
            fields: [
                {
                    title: 'Severity',
                    value: rule.severity.toUpperCase(),
                    short: true
                },
                {
                    title: 'Metric Value',
                    value: String(metricValue),
                    short: true
                },
                {
                    title: 'Threshold',
                    value: `${rule.threshold_value} ${rule.condition_operator}`,
                    short: true
                }
            ],
            footer: 'Monitoring System',
            ts: Math.floor(Date.now() / 1000)
        }]
    };
    
    // Simulate Slack API call
    console.log('Slack notification:', slackMessage);
    
    return {
        status: 'sent',
        channel: recipients[0],
        message: slackMessage,
        timestamp: new Date().toISOString()
    };
}

async function sendWebhookNotification(recipients, rule, metricData, alertId) {
    const webhookData = {
        alert_id: alertId,
        rule_name: rule.rule_name,
        severity: rule.severity,
        metric_type: rule.metric_type,
        metric_value: extractMetricValue(metricData, rule.metric_type),
        threshold_value: rule.threshold_value,
        condition_operator: rule.condition_operator,
        timestamp: new Date().toISOString(),
        full_data: metricData
    };
    
    const webhookUrl = recipients[0];
    
    try {
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(webhookData)
        });
        
        return {
            status: response.ok ? 'sent' : 'failed',
            status_code: response.status,
            response_text: await response.text(),
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        return {
            status: 'failed',
            error: error.message,
            timestamp: new Date().toISOString()
        };
    }
}

async function sendSMSNotification(recipients, rule, metricData, alertId) {
    const metricValue = extractMetricValue(metricData, rule.metric_type);
    const message = `ALERT ${rule.severity.toUpperCase()}: ${rule.rule_name} - ${rule.metric_type}: ${metricValue} (threshold: ${rule.threshold_value})`;
    
    // Simulate SMS sending
    console.log('SMS notification:', { recipients, message });
    
    return {
        status: 'sent',
        recipients: recipients,
        message: message,
        timestamp: new Date().toISOString()
    };
}

async function resolveAlert(alertId) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    // Update anomaly detection status
    const response = await fetch(`${supabaseUrl}/rest/v1/anomaly_detections?id=eq.${alertId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify({
            status: 'resolved',
            resolved_at: new Date().toISOString()
        })
    });
    
    if (!response.ok) {
        throw new Error('Failed to resolve alert');
    }
    
    return {
        alert_id: alertId,
        status: 'resolved',
        resolved_at: new Date().toISOString()
    };
}

async function getActiveAlerts() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/anomaly_detections?status=eq.active&order=detected_at.desc&limit=100`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error('Failed to fetch active alerts');
    }
    
    const alerts = await response.json();
    
    return {
        active_alerts: alerts,
        total_count: alerts.length,
        critical_alerts: alerts.filter(a => a.severity_level === 'critical').length,
        high_alerts: alerts.filter(a => a.severity_level === 'high').length,
        medium_alerts: alerts.filter(a => a.severity_level === 'medium').length,
        low_alerts: alerts.filter(a => a.severity_level === 'low').length,
        fetched_at: new Date().toISOString()
    };
}

async function testNotification(data) {
    const { channel, test_message } = data;
    
    const testRule = {
        rule_name: 'TEST_ALERT',
        severity: 'medium',
        metric_type: 'test',
        condition_operator: '>',
        threshold_value: 0,
        notification_channels: [channel]
    };
    
    const testMetricData = {
        test: 1,
        timestamp: new Date().toISOString()
    };
    
    const result = await sendNotification({
        channel: channel,
        rule: testRule,
        metricData: testMetricData,
        alertId: 'test-' + Date.now(),
        recipients: getRecipientsForChannel(channel, testRule)
    });
    
    return {
        channel: channel,
        test_status: result.status,
        test_message: test_message || 'This is a test notification from the monitoring system.',
        result: result,
        timestamp: new Date().toISOString()
    };
}