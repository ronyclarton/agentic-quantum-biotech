/**
 * Metrics Collection Service
 * Real-time collection of training and infrastructure metrics
 * Deno Edge Function
 */

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { metric_type, data } = await req.json();
        let result = {};

        switch (metric_type) {
            case 'training_metric':
                result = await collectTrainingMetric(data);
                break;
            case 'resource_metric':
                result = await collectResourceMetric(data);
                break;
            case 'cost_metric':
                result = await collectCostMetric(data);
                break;
            case 'custom_metric':
                result = await collectCustomMetric(data);
                break;
            default:
                throw new Error(`Unknown metric type: ${metric_type}`);
        }

        return new Response(JSON.stringify({ success: true, data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Metrics collection error:', error);
        return new Response(JSON.stringify({
            error: {
                code: 'METRICS_COLLECTION_ERROR',
                message: error.message
            }
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function collectTrainingMetric(data) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    const trainingData = {
        session_id: data.session_id,
        model_name: data.model_name,
        training_step: data.training_step,
        epoch: data.epoch || null,
        learning_rate: data.learning_rate,
        loss_value: data.loss_value,
        accuracy: data.accuracy,
        precision: data.precision,
        recall: data.recall,
        f1_score: data.f1_score,
        gpu_utilization: data.gpu_utilization,
        cpu_utilization: data.cpu_utilization,
        memory_usage: data.memory_usage,
        gpu_memory: data.gpu_memory,
        batch_size: data.batch_size,
        throughput_samples_per_sec: data.throughput_samples_per_sec,
        tags: data.tags || {}
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/training_metrics`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(trainingData)
    });

    if (!response.ok) {
        throw new Error(`Failed to insert training metric: ${response.statusText}`);
    }

    return { message: 'Training metric collected successfully', metric_id: data.training_step };
}

async function collectResourceMetric(data) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    const resourceData = {
        node_id: data.node_id,
        host_type: data.host_type,
        resource_type: data.resource_type,
        utilization_percentage: data.utilization_percentage,
        available_amount: data.available_amount,
        used_amount: data.used_amount,
        total_amount: data.total_amount,
        load_average: data.load_average,
        network_throughput: data.network_throughput,
        disk_io_ops: data.disk_io_ops,
        temperature: data.temperature,
        power_consumption: data.power_consumption,
        metadata: data.metadata || {}
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/resource_metrics`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(resourceData)
    });

    if (!response.ok) {
        throw new Error(`Failed to insert resource metric: ${response.statusText}`);
    }

    return { message: 'Resource metric collected successfully', node_id: data.node_id };
}

async function collectCostMetric(data) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    const costData = {
        resource_id: data.resource_id,
        service_type: data.service_type,
        provider: data.provider,
        cost_per_hour: data.cost_per_hour,
        cost_per_month: data.cost_per_month,
        usage_hours: data.usage_hours,
        total_cost: data.total_cost,
        efficiency_score: data.efficiency_score,
        billing_period: data.billing_period
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/cost_metrics`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(costData)
    });

    if (!response.ok) {
        throw new Error(`Failed to insert cost metric: ${response.statusText}`);
    }

    return { message: 'Cost metric collected successfully', resource_id: data.resource_id };
}

async function collectCustomMetric(data) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    const customMetricData = {
        metric_name: data.metric_name,
        value: data.value,
        tags: data.tags || {}
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/custom_metric_values`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(customMetricData)
    });

    if (!response.ok) {
        throw new Error(`Failed to insert custom metric: ${response.statusText}`);
    }

    return { message: 'Custom metric collected successfully', metric_name: data.metric_name };
}