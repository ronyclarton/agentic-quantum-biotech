/**
 * Analytics Service
 * ML-powered insights and cost optimization recommendations
 * Deno Edge Function
 */

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, parameters } = await req.json();
        let result = {};

        switch (action) {
            case 'generate_cost_insights':
                result = await generateCostInsights(parameters);
                break;
            case 'analyze_performance_trends':
                result = await analyzePerformanceTrends(parameters);
                break;
            case 'optimize_resource_allocation':
                result = await optimizeResourceAllocation(parameters);
                break;
            case 'predict_resource_needs':
                result = await predictResourceNeeds(parameters);
                break;
            case 'generate_recommendations':
                result = await generateRecommendations(parameters);
                break;
            case 'calculate_cost_savings':
                result = await calculateCostSavings(parameters);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ success: true, data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Analytics service error:', error);
        return new Response(JSON.stringify({
            error: {
                code: 'ANALYTICS_SERVICE_ERROR',
                message: error.message
            }
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function generateCostInsights(parameters) {
    const { timeRange = '30d', resourceTypes = 'all' } = parameters;
    
    // Get cost data
    const costData = await getCostData(timeRange);
    
    // Analyze cost patterns
    const costAnalysis = analyzeCostPatterns(costData);
    
    // Generate optimization recommendations
    const recommendations = generateCostRecommendations(costAnalysis);
    
    // Calculate potential savings
    const savings = calculatePotentialSavings(costData, recommendations);
    
    const insights = {
        analysis_type: 'cost_insights',
        time_range: timeRange,
        total_cost: costAnalysis.totalCost,
        cost_breakdown: costAnalysis.breakdown,
        trends: costAnalysis.trends,
        recommendations: recommendations,
        potential_monthly_savings: savings.monthlySavings,
        potential_annual_savings: savings.annualSavings,
        confidence_score: savings.confidenceScore,
        generated_at: new Date().toISOString()
    };
    
    // Store analytics results
    await storeAnalyticsResults(insights);
    
    return insights;
}

async function getCostData(timeRange) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const timeRangeMs = {
        '7d': 7 * 24 * 60 * 60 * 1000,
        '30d': 30 * 24 * 60 * 60 * 1000,
        '90d': 90 * 24 * 60 * 60 * 1000,
        '1y': 365 * 24 * 60 * 60 * 1000
    };
    
    const startTime = new Date(Date.now() - (timeRangeMs[timeRange] || timeRangeMs['30d'])).toISOString();
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/cost_metrics?timestamp=gte.${startTime}&order=timestamp.desc`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error('Failed to fetch cost data');
    }
    
    return await response.json();
}

function analyzeCostPatterns(costData) {
    if (costData.length === 0) {
        return {
            totalCost: 0,
            breakdown: {},
            trends: {}
        };
    }
    
    // Calculate totals by service type
    const serviceTotals = {};
    const dailyCosts = {};
    let totalCost = 0;
    
    for (const cost of costData) {
        const serviceType = cost.service_type || 'unknown';
        const date = cost.timestamp.split('T')[0]; // Get date part
        
        serviceTotals[serviceType] = (serviceTotals[serviceType] || 0) + cost.total_cost;
        dailyCosts[date] = (dailyCosts[date] || 0) + cost.total_cost;
        totalCost += cost.total_cost;
    }
    
    // Calculate breakdown percentages
    const breakdown = {};
    for (const [service, cost] of Object.entries(serviceTotals)) {
        breakdown[service] = {
            amount: cost,
            percentage: (cost / totalCost) * 100
        };
    }
    
    // Analyze trends
    const trends = analyzeCostTrends(dailyCosts);
    
    return {
        totalCost,
        breakdown,
        trends
    };
}

function analyzeCostTrends(dailyCosts) {
    const dates = Object.keys(dailyCosts).sort();
    if (dates.length < 2) {
        return { trend: 'insufficient_data' };
    }
    
    const costs = dates.map(date => dailyCosts[date]);
    const trend = calculateLinearTrend(costs);
    
    return {
        trend: trend > 0.1 ? 'increasing' : trend < -0.1 ? 'decreasing' : 'stable',
        slope: trend,
        average_daily_cost: costs.reduce((a, b) => a + b, 0) / costs.length,
        volatility: calculateVolatility(costs)
    };
}

function calculateLinearTrend(values) {
    const n = values.length;
    const xValues = Array.from({length: n}, (_, i) => i);
    
    const sumX = xValues.reduce((a, b) => a + b, 0);
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
    const sumXX = xValues.reduce((a, b) => a + b * b, 0);
    
    return (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
}

function calculateVolatility(values) {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
    return Math.sqrt(variance);
}

function generateCostRecommendations(costAnalysis) {
    const recommendations = [];
    
    // Analyze service type breakdown
    for (const [service, data] of Object.entries(costAnalysis.breakdown)) {
        if (data.percentage > 40) {
            recommendations.push({
                category: 'cost_optimization',
                service: service,
                priority: 'high',
                description: `${service} costs represent ${data.percentage.toFixed(1)}% of total spending`,
                recommendation: `Consider optimizing ${service} costs through right-sizing or alternative providers`,
                potential_savings: data.amount * 0.2 // Estimate 20% potential savings
            });
        }
    }
    
    // Analyze trends
    if (costAnalysis.trends.trend === 'increasing') {
        recommendations.push({
            category: 'cost_control',
            priority: 'medium',
            description: 'Costs are trending upward',
            recommendation: 'Implement cost controls and monitoring to prevent further increases',
            action_required: 'immediate'
        });
    }
    
    // Analyze volatility
    if (costAnalysis.trends.volatility > costAnalysis.trends.average_daily_cost * 0.5) {
        recommendations.push({
            category: 'cost_stability',
            priority: 'medium',
            description: 'High cost volatility detected',
            recommendation: 'Review cost patterns to identify and eliminate spikes',
            action_required: 'investigate'
        });
    }
    
    return recommendations;
}

function calculatePotentialSavings(costData, recommendations) {
    let totalPotentialSavings = 0;
    let confidenceScore = 0.7; // Base confidence
    
    for (const rec of recommendations) {
        if (rec.potential_savings) {
            totalPotentialSavings += rec.potential_savings;
        }
    }
    
    // Adjust confidence based on data quality
    if (costData.length > 100) {
        confidenceScore += 0.1;
    }
    
    if (costData.length > 500) {
        confidenceScore += 0.1;
    }
    
    return {
        monthlySavings: totalPotentialSavings / 12,
        annualSavings: totalPotentialSavings,
        confidenceScore: Math.min(0.95, confidenceScore)
    };
}

async function analyzePerformanceTrends(parameters) {
    const { metricType, timeRange = '7d', windowSize = 24 } = parameters;
    
    const metricsData = await getMetricsData(metricType, timeRange);
    const trends = analyzeMetricsTrends(metricsData, windowSize);
    
    const insights = {
        analysis_type: 'performance_trends',
        metric_type: metricType,
        time_range: timeRange,
        trends: trends,
        anomalies_detected: trends.anomalies,
        pattern_analysis: identifyPatterns(trends.data),
        forecasts: generateForecasts(trends.data),
        generated_at: new Date().toISOString()
    };
    
    await storeAnalyticsResults(insights);
    
    return insights;
}

async function getMetricsData(metricType, timeRange) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const timeRangeMs = { '7d': 7, '30d': 30, '90d': 90 };
    const days = timeRangeMs[timeRange] || 7;
    const startTime = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    
    let table = 'training_metrics';
    if (metricType.includes('resource')) {
        table = 'resource_metrics';
    } else if (metricType.includes('cost')) {
        table = 'cost_metrics';
    }
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/${table}?select=*&timestamp=gte.${startTime}&order=timestamp.desc&limit=5000`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error(`Failed to fetch ${metricType} data`);
    }
    
    return await response.json();
}

function analyzeMetricsTrends(metricsData, windowSize) {
    if (metricsData.length === 0) {
        return { data: [], trends: {}, anomalies: [] };
    }
    
    // Group data by time windows
    const groupedData = groupDataByTimeWindow(metricsData, windowSize);
    const trends = {};
    const anomalies = [];
    
    // Analyze trends for each metric
    const metrics = Object.keys(metricsData[0]).filter(key => 
        ['accuracy', 'loss_value', 'gpu_utilization', 'memory_usage', 'cost_per_hour'].includes(key)
    );
    
    for (const metric of metrics) {
        const values = groupedData.map(group => ({
            time: group.time,
            value: group.data.reduce((sum, item) => sum + (item[metric] || 0), 0) / group.data.length
        })).filter(item => !isNaN(item.value));
        
        if (values.length > 1) {
            trends[metric] = {
                slope: calculateLinearTrend(values.map(v => v.value)),
                trend_direction: calculateLinearTrend(values.map(v => v.value)) > 0 ? 'increasing' : 'decreasing',
                volatility: calculateVolatility(values.map(v => v.value)),
                forecast: forecastNext(values, 24) // Forecast next 24 hours
            };
            
            // Detect anomalies
            const metricAnomalies = detectAnomaliesInTrend(values, metric);
            anomalies.push(...metricAnomalies);
        }
    }
    
    return {
        data: groupedData,
        trends,
        anomalies
    };
}

function groupDataByTimeWindow(data, windowSize) {
    const windows = {};
    const windowMs = windowSize * 60 * 60 * 1000; // Convert hours to milliseconds
    
    for (const item of data) {
        const time = new Date(item.timestamp);
        const windowStart = Math.floor(time.getTime() / windowMs) * windowMs;
        const windowKey = new Date(windowStart).toISOString();
        
        if (!windows[windowKey]) {
            windows[windowKey] = { time: windowKey, data: [] };
        }
        
        windows[windowKey].data.push(item);
    }
    
    return Object.values(windows).sort((a, b) => 
        new Date(a.time).getTime() - new Date(b.time).getTime()
    );
}

function detectAnomaliesInTrend(values, metric) {
    const anomalies = [];
    const mean = values.reduce((sum, item) => sum + item.value, 0) / values.length;
    const std = Math.sqrt(values.reduce((sum, item) => sum + Math.pow(item.value - mean, 2), 0) / values.length);
    
    if (std === 0) return anomalies;
    
    for (const item of values) {
        const zScore = Math.abs((item.value - mean) / std);
        if (zScore > 2.5) {
            anomalies.push({
                metric: metric,
                time: item.time,
                value: item.value,
                anomaly_score: zScore,
                severity: zScore > 3 ? 'high' : 'medium'
            });
        }
    }
    
    return anomalies;
}

function forecastNext(data, periods) {
    if (data.length < 2) return [];
    
    const values = data.map(d => d.value);
    const slope = calculateLinearTrend(values);
    const lastValue = values[values.length - 1];
    
    const forecast = [];
    for (let i = 1; i <= periods; i++) {
        forecast.push({
            period: i,
            value: lastValue + (slope * i),
            confidence: Math.max(0.1, 0.9 - (i / periods) * 0.7) // Decreasing confidence
        });
    }
    
    return forecast;
}

function identifyPatterns(data) {
    const patterns = [];
    
    // Check for daily patterns
    const hourlyAverages = {};
    for (const item of data) {
        const hour = new Date(item.time).getHours();
        if (!hourlyAverages[hour]) {
            hourlyAverages[hour] = [];
        }
        // This would need actual metric values - simplified for demo
        hourlyAverages[hour].push(Math.random() * 100);
    }
    
    const variance = Object.values(hourlyAverages).map(hours => 
        calculateVolatility(hours)
    );
    
    if (Math.max(...variance) > 20) {
        patterns.push({
            type: 'temporal',
            pattern: 'daily_usage_variation',
            strength: 'medium',
            description: 'Detected daily usage patterns'
        });
    }
    
    return patterns;
}

async function optimizeResourceAllocation(parameters) {
    const { resourceTypes, optimizationGoals = 'cost_efficiency' } = parameters;
    
    // Get current resource utilization
    const resourceData = await getResourceUtilizationData();
    
    // Analyze utilization patterns
    const utilizationAnalysis = analyzeUtilizationPatterns(resourceData);
    
    // Generate optimization recommendations
    const optimization = generateOptimizationRecommendations(utilizationAnalysis, optimizationGoals);
    
    const insights = {
        analysis_type: 'resource_optimization',
        optimization_goals: optimizationGoals,
        current_utilization: utilizationAnalysis,
        recommendations: optimization.recommendations,
        predicted_improvements: optimization.predictedImprovements,
        implementation_priority: optimization.priority,
        generated_at: new Date().toISOString()
    };
    
    await storeAnalyticsResults(insights);
    
    return insights;
}

async function getResourceUtilizationData() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const startTime = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/resource_metrics?timestamp=gte.${startTime}&order=timestamp.desc`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error('Failed to fetch resource data');
    }
    
    return await response.json();
}

function analyzeUtilizationPatterns(resourceData) {
    const analysis = {};
    
    // Group by node and resource type
    const groupedData = {};
    for (const item of resourceData) {
        const key = `${item.node_id}-${item.resource_type}`;
        if (!groupedData[key]) {
            groupedData[key] = [];
        }
        groupedData[key].push(item);
    }
    
    for (const [key, data] of Object.entries(groupedData)) {
        const utilization = data.filter(d => d.utilization_percentage !== null).map(d => d.utilization_percentage);
        
        if (utilization.length > 0) {
            analysis[key] = {
                avg_utilization: utilization.reduce((a, b) => a + b, 0) / utilization.length,
                max_utilization: Math.max(...utilization),
                min_utilization: Math.min(...utilization),
                volatility: calculateVolatility(utilization),
                data_points: utilization.length
            };
        }
    }
    
    return analysis;
}

function generateOptimizationRecommendations(utilizationAnalysis, goals) {
    const recommendations = [];
    const priority = [];
    
    for (const [resource, data] of Object.entries(utilizationAnalysis)) {
        if (data.avg_utilization < 20) {
            recommendations.push({
                type: 'downsizing',
                resource: resource,
                recommendation: `Reduce resource allocation - current avg utilization: ${data.avg_utilization.toFixed(1)}%`,
                potential_savings: data.avg_utilization * 0.1, // Simplified calculation
                implementation_difficulty: 'low'
            });
            priority.push({ resource, priority: 'medium' });
        } else if (data.avg_utilization > 90) {
            recommendations.push({
                type: 'upsizing',
                resource: resource,
                recommendation: `Increase resource allocation - current avg utilization: ${data.avg_utilization.toFixed(1)}%`,
                potential_performance_gain: 0.2,
                implementation_difficulty: 'medium'
            });
            priority.push({ resource, priority: 'high' });
        }
        
        if (data.volatility > 30) {
            recommendations.push({
                type: 'load_balancing',
                resource: resource,
                recommendation: `Implement load balancing - high volatility detected (${data.volatility.toFixed(1)})`,
                implementation_difficulty: 'high'
            });
            priority.push({ resource, priority: 'high' });
        }
    }
    
    return {
        recommendations,
        predictedImprovements: {
            cost_savings: recommendations.filter(r => r.type === 'downsizing').length * 0.1,
            performance_improvements: recommendations.filter(r => r.type === 'upsizing').length * 0.2
        },
        priority: priority.sort((a, b) => {
            const priorityOrder = { high: 3, medium: 2, low: 1 };
            return priorityOrder[b.priority] - priorityOrder[a.priority];
        })
    };
}

async function predictResourceNeeds(parameters) {
    const { predictionHorizon = 7, resourceTypes = 'all' } = parameters;
    
    // Get historical usage data
    const historicalData = await getHistoricalUsageData(30); // 30 days
    
    // Perform forecasting
    const forecasts = {};
    const metrics = ['cpu_utilization', 'memory_usage', 'gpu_utilization'];
    
    for (const metric of metrics) {
        forecasts[metric] = forecastResourceNeeds(historicalData, metric, predictionHorizon);
    }
    
    const insights = {
        analysis_type: 'resource_forecasting',
        prediction_horizon_days: predictionHorizon,
        forecasts: forecasts,
        recommendations: generateResourceRecommendations(forecasts),
        confidence_levels: calculateForecastConfidence(historicalData, forecasts),
        generated_at: new Date().toISOString()
    };
    
    await storeAnalyticsResults(insights);
    
    return insights;
}

async function getHistoricalUsageData(days) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const startTime = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/resource_metrics?timestamp=gte.${startTime}&order=timestamp.desc`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error('Failed to fetch historical usage data');
    }
    
    return await response.json();
}

function forecastResourceNeeds(historicalData, metric, horizon) {
    // Group data by day
    const dailyData = {};
    
    for (const item of historicalData) {
        const date = item.timestamp.split('T')[0];
        if (!dailyData[date]) {
            dailyData[date] = [];
        }
        dailyData[date].push(item[metric] || 0);
    }
    
    const dates = Object.keys(dailyData).sort();
    const dailyAverages = dates.map(date => 
        dailyData[date].reduce((a, b) => a + b, 0) / dailyData[date].length
    );
    
    // Simple linear regression forecast
    const trend = calculateLinearTrend(dailyAverages);
    const lastValue = dailyAverages[dailyAverages.length - 1];
    
    const forecast = [];
    for (let i = 1; i <= horizon; i++) {
        forecast.push({
            day: i,
            predicted_value: lastValue + (trend * i),
            confidence: Math.max(0.1, 0.9 - (i / horizon) * 0.6)
        });
    }
    
    return forecast;
}

function generateResourceRecommendations(forecasts) {
    const recommendations = [];
    
    for (const [metric, forecast] of Object.entries(forecasts)) {
        const predictedIncrease = forecast[forecast.length - 1].predicted_value - forecast[0].predicted_value;
        
        if (predictedIncrease > 20) {
            recommendations.push({
                metric: metric,
                recommendation: `Scale up ${metric} - predicted increase of ${predictedIncrease.toFixed(1)}%`,
                urgency: 'medium',
                action: 'prepare_scaling'
            });
        } else if (predictedIncrease < -20) {
            recommendations.push({
                metric: metric,
                recommendation: `Scale down ${metric} - predicted decrease of ${Math.abs(predictedIncrease).toFixed(1)}%`,
                urgency: 'low',
                action: 'consider_downsizing'
            });
        }
    }
    
    return recommendations;
}

function calculateForecastConfidence(historicalData, forecasts) {
    // Calculate confidence based on historical data quality and variance
    const confidence = {};
    
    for (const [metric, forecast] of Object.entries(forecasts)) {
        const metricData = historicalData.map(d => d[metric] || 0);
        const variance = calculateVolatility(metricData);
        const dataPoints = metricData.length;
        
        confidence[metric] = Math.min(0.95, Math.max(0.1, 
            0.8 - (variance / 100) + (dataPoints / 1000)
        ));
    }
    
    return confidence;
}

async function generateRecommendations(parameters) {
    const { scope = 'all', priority = 'all' } = parameters;
    
    // Get analytics results
    const analyticsData = await getRecentAnalyticsData();
    
    // Aggregate recommendations
    const allRecommendations = [];
    
    for (const result of analyticsData) {
        if (result.result_data && result.result_data.recommendations) {
            allRecommendations.push(...result.result_data.recommendations);
        }
    }
    
    // Filter and prioritize
    const filteredRecommendations = filterRecommendations(allRecommendations, scope, priority);
    const prioritizedRecommendations = prioritizeRecommendations(filteredRecommendations);
    
    return {
        analysis_type: 'recommendations_summary',
        scope: scope,
        priority: priority,
        total_recommendations: prioritizedRecommendations.length,
        recommendations: prioritizedRecommendations,
        implementation_timeline: createImplementationTimeline(prioritizedRecommendations),
        generated_at: new Date().toISOString()
    };
}

async function getRecentAnalyticsData() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/performance_analytics?created_at=gte.${new Date(Date.now() - 7*24*60*60*1000).toISOString()}&order=created_at.desc&limit=100`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        return [];
    }
    
    return await response.json();
}

function filterRecommendations(recommendations, scope, priority) {
    return recommendations.filter(rec => {
        if (scope !== 'all' && rec.category !== scope) return false;
        if (priority !== 'all' && rec.priority !== priority) return false;
        return true;
    });
}

function prioritizeRecommendations(recommendations) {
    return recommendations.sort((a, b) => {
        const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
    });
}

function createImplementationTimeline(recommendations) {
    const timeline = {
        immediate: [],
        short_term: [],
        medium_term: [],
        long_term: []
    };
    
    for (const rec of recommendations) {
        if (rec.priority === 'urgent') {
            timeline.immediate.push(rec);
        } else if (rec.priority === 'high') {
            timeline.short_term.push(rec);
        } else if (rec.priority === 'medium') {
            timeline.medium_term.push(rec);
        } else {
            timeline.long_term.push(rec);
        }
    }
    
    return timeline;
}

async function storeAnalyticsResults(insights) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const analyticsData = {
        analysis_type: insights.analysis_type,
        source_metric: insights.metric_type || insights.scope || 'comprehensive',
        analysis_period_start: new Date(Date.now() - 24*60*60*1000).toISOString(),
        analysis_period_end: new Date().toISOString(),
        result_data: insights,
        confidence_score: insights.confidence_score || 0.8,
        insights: {
            summary: `${insights.analysis_type} analysis completed`,
            key_findings: extractKeyFindings(insights),
            recommendations_count: insights.recommendations ? insights.recommendations.length : 0
        },
        recommendations: insights.recommendations || []
    };
    
    await fetch(`${supabaseUrl}/rest/v1/performance_analytics`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(analyticsData)
    });
}

function extractKeyFindings(insights) {
    const findings = [];
    
    if (insights.potential_monthly_savings) {
        findings.push(`Potential monthly cost savings: $${insights.potential_monthly_savings.toFixed(2)}`);
    }
    
    if (insights.trends) {
        for (const [metric, trend] of Object.entries(insights.trends)) {
            if (trend.trend_direction) {
                findings.push(`${metric} trending ${trend.trend_direction}`);
            }
        }
    }
    
    if (insights.recommendations) {
        findings.push(`${insights.recommendations.length} optimization recommendations generated`);
    }
    
    return findings;
}