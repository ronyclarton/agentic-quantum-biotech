/**
 * Anomaly Detection Service
 * ML-powered detection of training and infrastructure anomalies
 * Deno Edge Function
 */

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { metric_type, metric_data, detection_config } = await req.json();
        
        const anomalyResult = await detectAnomalies(metric_type, metric_data, detection_config);
        
        if (anomalyResult.is_anomaly) {
            await logAnomalyDetection(anomalyResult);
            
            if (anomalyResult.severity_level === 'high' || anomalyResult.severity_level === 'critical') {
                await triggerAlert(anomalyResult);
            }
        }

        return new Response(JSON.stringify({ 
            success: true, 
            data: anomalyResult 
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Anomaly detection error:', error);
        return new Response(JSON.stringify({
            error: {
                code: 'ANOMALY_DETECTION_ERROR',
                message: error.message
            }
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function detectAnomalies(metricType, metricData, config = {}) {
    let anomalyScore = 0;
    let isAnomaly = false;
    let severityLevel = 'low';
    let description = '';
    let recommendation = '';

    // Get historical data for baseline comparison
    const historicalData = await getHistoricalData(metricType, metricData, config.timeWindow || '1h');
    
    // Statistical anomaly detection
    if (historicalData.length > 10) {
        const statsResult = statisticalAnomalyDetection(metricData, historicalData);
        anomalyScore = Math.max(anomalyScore, statsResult.score);
        
        if (statsResult.isAnomaly) {
            isAnomaly = true;
            description = statsResult.description;
        }
    }

    // ML-based anomaly detection for training metrics
    if (metricType === 'training_metric') {
        const mlResult = await mlTrainingAnomalyDetection(metricData, historicalData);
        anomalyScore = Math.max(anomalyScore, mlResult.score);
        
        if (mlResult.isAnomaly) {
            isAnomaly = true;
            description = mlResult.description;
        }
    }

    // Resource utilization anomaly detection
    if (metricType === 'resource_metric') {
        const resourceResult = resourceAnomalyDetection(metricData, historicalData);
        anomalyScore = Math.max(anomalyScore, resourceResult.score);
        
        if (resourceResult.isAnomaly) {
            isAnomaly = true;
            description = resourceResult.description;
            recommendation = resourceResult.recommendation;
        }
    }

    // Determine severity based on anomaly score
    if (anomalyScore > 0.8) {
        severityLevel = 'critical';
    } else if (anomalyScore > 0.6) {
        severityLevel = 'high';
    } else if (anomalyScore > 0.4) {
        severityLevel = 'medium';
    }

    return {
        is_anomaly: isAnomaly,
        anomaly_score: anomalyScore,
        severity_level: severityLevel,
        description: description || 'No anomalies detected',
        recommendation: recommendation,
        metric_data: metricData,
        timestamp: new Date().toISOString(),
        detection_method: 'hybrid_statistical_ml'
    };
}

async function getHistoricalData(metricType, currentData, timeWindow) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const timeRange = getTimeRangeQuery(timeWindow);
    let table = '';
    
    switch (metricType) {
        case 'training_metric':
            table = 'training_metrics';
            break;
        case 'resource_metric':
            table = 'resource_metrics';
            break;
        case 'cost_metric':
            table = 'cost_metrics';
            break;
        default:
            return [];
    }

    const response = await fetch(
        `${supabaseUrl}/rest/v1/${table}?select=*&timestamp=gte.${timeRange}&order=timestamp.desc&limit=1000`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );

    if (!response.ok) {
        return [];
    }

    return await response.json();
}

function getTimeRangeQuery(timeWindow) {
    const now = new Date();
    const ranges = {
        '15m': new Date(now.getTime() - 15 * 60 * 1000),
        '1h': new Date(now.getTime() - 60 * 60 * 1000),
        '6h': new Date(now.getTime() - 6 * 60 * 60 * 1000),
        '24h': new Date(now.getTime() - 24 * 60 * 60 * 1000),
        '7d': new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    };
    
    return ranges[timeWindow]?.toISOString() || ranges['1h'].toISOString();
}

function statisticalAnomalyDetection(currentData, historicalData) {
    const scores = [];
    let descriptions = [];
    
    // Calculate Z-score for key metrics
    const metrics = ['accuracy', 'loss_value', 'gpu_utilization', 'memory_usage'];
    
    for (const metric of metrics) {
        if (currentData[metric] !== undefined && historicalData.length > 0) {
            const historicalValues = historicalData.map(d => d[metric]).filter(v => v !== null && v !== undefined);
            
            if (historicalValues.length > 5) {
                const mean = historicalValues.reduce((a, b) => a + b, 0) / historicalValues.length;
                const variance = historicalValues.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / historicalValues.length;
                const std = Math.sqrt(variance);
                
                if (std > 0) {
                    const zScore = Math.abs((currentData[metric] - mean) / std);
                    scores.push(zScore / 3); // Normalize to 0-1 range
                    
                    if (zScore > 2.5) {
                        descriptions.push(`${metric} deviates ${zScore.toFixed(2)} standard deviations from baseline`);
                    }
                }
            }
        }
    }
    
    const anomalyScore = scores.length > 0 ? Math.max(...scores) : 0;
    const isAnomaly = anomalyScore > 0.7;
    
    return {
        isAnomaly,
        score: anomalyScore,
        description: descriptions.join('; ') || 'No significant statistical anomalies detected'
    };
}

async function mlTrainingAnomalyDetection(currentData, historicalData) {
    // Simplified ML anomaly detection for training metrics
    const scores = [];
    
    // Check for gradient explosion (loss jumps)
    if (currentData.loss_value && historicalData.length > 0) {
        const prevLoss = historicalData[0]?.loss_value;
        if (prevLoss) {
            const lossIncrease = (currentData.loss_value - prevLoss) / prevLoss;
            if (lossIncrease > 0.5) {
                scores.push(0.9);
            } else if (lossIncrease > 0.2) {
                scores.push(0.6);
            }
        }
    }
    
    // Check for accuracy plateau or degradation
    if (currentData.accuracy && historicalData.length > 3) {
        const recentAccuracies = historicalData.slice(0, 5).map(d => d.accuracy).filter(a => a);
        if (recentAccuracies.length >= 3) {
            const slope = calculateSlope(recentAccuracies);
            if (slope < -0.001) {
                scores.push(0.7); // Accuracy decreasing
            }
        }
    }
    
    // Check for learning rate issues
    if (currentData.learning_rate && historicalData.length > 0) {
        const prevLR = historicalData[0]?.learning_rate;
        if (prevLR) {
            const lrChange = Math.abs(currentData.learning_rate - prevLR) / prevLR;
            if (lrChange > 0.5) {
                scores.push(0.8);
            }
        }
    }
    
    const anomalyScore = scores.length > 0 ? Math.max(...scores) : 0;
    const isAnomaly = anomalyScore > 0.6;
    
    return {
        isAnomaly,
        score: anomalyScore,
        description: isAnomaly ? 'Training anomalies detected (gradient, accuracy, or learning rate)' : 'Training metrics normal'
    };
}

function resourceAnomalyDetection(currentData, historicalData) {
    const scores = [];
    let description = '';
    let recommendation = '';
    
    // Check CPU utilization
    if (currentData.utilization_percentage && currentData.resource_type === 'cpu') {
        if (currentData.utilization_percentage > 95) {
            scores.push(0.9);
            description += 'CPU utilization critically high; ';
            recommendation += 'Consider scaling resources or optimizing workloads; ';
        } else if (currentData.utilization_percentage > 90) {
            scores.push(0.7);
            description += 'CPU utilization high; ';
        }
    }
    
    // Check GPU utilization
    if (currentData.utilization_percentage && currentData.host_type === 'gpu') {
        if (currentData.utilization_percentage < 10) {
            scores.push(0.6);
            description += 'GPU underutilized; ';
            recommendation += 'Consider consolidating workloads; ';
        } else if (currentData.utilization_percentage > 95) {
            scores.push(0.8);
            description += 'GPU utilization high; ';
        }
    }
    
    // Check temperature
    if (currentData.temperature) {
        if (currentData.temperature > 85) {
            scores.push(0.9);
            description += 'Temperature critical; ';
            recommendation += 'Check cooling system; ';
        } else if (currentData.temperature > 75) {
            scores.push(0.6);
            description += 'Temperature elevated; ';
        }
    }
    
    const anomalyScore = scores.length > 0 ? Math.max(...scores) : 0;
    const isAnomaly = anomalyScore > 0.5;
    
    return {
        isAnomaly,
        score: anomalyScore,
        description: description || 'Resource metrics normal',
        recommendation: recommendation || 'Continue monitoring'
    };
}

function calculateSlope(values) {
    const n = values.length;
    const sumX = Array.from({length: n}, (_, i) => i).reduce((a, b) => a + b, 0);
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
    const sumXX = Array.from({length: n}, (_, i) => i * i).reduce((a, b) => a + b, 0);
    
    return (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
}

async function logAnomalyDetection(anomalyResult) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const anomalyData = {
        metric_type: anomalyResult.metric_type || 'unknown',
        metric_id: null, // Would be linked to specific metric ID
        anomaly_score: anomalyResult.anomaly_score,
        severity_level: anomalyResult.severity_level,
        description: anomalyResult.description,
        recommendation: anomalyResult.recommendation,
        metadata: anomalyResult.metric_data
    };
    
    await fetch(`${supabaseUrl}/rest/v1/anomaly_detections`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
            'apikey': supabaseKey
        },
        body: JSON.stringify(anomalyData)
    });
}

async function triggerAlert(anomalyResult) {
    // Trigger alert through notification service
    const notificationServiceUrl = Deno.env.get('NOTIFICATION_SERVICE_URL');
    
    if (notificationServiceUrl) {
        await fetch(notificationServiceUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                type: 'anomaly_alert',
                severity: anomalyResult.severity_level,
                message: anomalyResult.description,
                data: anomalyResult
            })
        });
    }
}