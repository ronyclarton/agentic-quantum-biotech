/**
 * Predictive Maintenance Service
 * ML-powered infrastructure health monitoring and failure prediction
 * Deno Edge Function
 */

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, node_id, analysis_type } = await req.json();
        let result = {};

        switch (action) {
            case 'analyze_node':
                result = await analyzeNodeHealth(node_id);
                break;
            case 'predict_failures':
                result = await predictNodeFailures(analysis_type);
                break;
            case 'update_predictions':
                result = await updatePredictions();
                break;
            case 'get_maintenance_schedule':
                result = await getMaintenanceSchedule();
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ success: true, data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Predictive maintenance error:', error);
        return new Response(JSON.stringify({
            error: {
                code: 'PREDICTIVE_MAINTENANCE_ERROR',
                message: error.message
            }
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function analyzeNodeHealth(nodeId) {
    // Get recent resource metrics for the node
    const resourceData = await getNodeResourceData(nodeId);
    const systemHealth = await getNodeSystemHealth(nodeId);
    
    // Perform health analysis
    const healthAnalysis = performHealthAnalysis(resourceData, systemHealth);
    
    // Update or create maintenance prediction
    await updateMaintenancePrediction(nodeId, healthAnalysis);
    
    return {
        node_id: nodeId,
        health_status: healthAnalysis.healthStatus,
        health_score: healthAnalysis.healthScore,
        issues_detected: healthAnalysis.issues,
        recommendations: healthAnalysis.recommendations,
        last_analysis: new Date().toISOString()
    };
}

async function getNodeResourceData(nodeId) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const timeRange = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(); // Last 7 days
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/resource_metrics?node_id=eq.${nodeId}&timestamp=gte.${timeRange}&order=timestamp.desc&limit=1000`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );

    if (!response.ok) {
        return [];
    }

    return await response.json();
}

async function getNodeSystemHealth(nodeId) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/system_health?component_name=eq.${nodeId}&order=last_check.desc&limit=1`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );

    if (!response.ok) {
        return null;
    }

    const data = await response.json();
    return data.length > 0 ? data[0] : null;
}

function performHealthAnalysis(resourceData, systemHealth) {
    const issues = [];
    const recommendations = [];
    let healthScore = 100;
    
    if (resourceData.length === 0) {
        return {
            healthStatus: 'unknown',
            healthScore: 0,
            issues: ['No recent data available'],
            recommendations: ['Check monitoring system connectivity']
        };
    }
    
    // Analyze temperature trends
    const tempData = resourceData.filter(d => d.temperature !== null).map(d => ({
        timestamp: d.timestamp,
        temperature: d.temperature,
        resource_type: d.resource_type
    }));
    
    if (tempData.length > 0) {
        const avgTemp = tempData.reduce((sum, d) => sum + d.temperature, 0) / tempData.length;
        const maxTemp = Math.max(...tempData.map(d => d.temperature));
        
        if (maxTemp > 85) {
            healthScore -= 30;
            issues.push(`Critical temperature detected (${maxTemp}°C)`);
            recommendations.push('Check cooling system and ventilation immediately');
        } else if (avgTemp > 75) {
            healthScore -= 15;
            issues.push(`Elevated average temperature (${avgTemp.toFixed(1)}°C)`);
            recommendations.push('Monitor temperature and consider maintenance');
        }
    }
    
    // Analyze utilization patterns
    const utilizationData = resourceData.filter(d => d.utilization_percentage !== null);
    
    if (utilizationData.length > 0) {
        const avgUtil = utilizationData.reduce((sum, d) => sum + d.utilization_percentage, 0) / utilizationData.length;
        const maxUtil = Math.max(...utilizationData.map(d => d.utilization_percentage));
        
        if (maxUtil > 95) {
            healthScore -= 20;
            issues.push('Consistently high resource utilization');
            recommendations.push('Consider scaling resources or optimizing workloads');
        }
        
        if (avgUtil < 10) {
            healthScore -= 10;
            issues.push('Underutilized resources');
            recommendations.push('Consider workload consolidation for cost optimization');
        }
    }
    
    // Analyze power consumption patterns
    const powerData = resourceData.filter(d => d.power_consumption !== null);
    
    if (powerData.length > 5) {
        const powerTrend = calculateTrend(powerData.map(d => d.power_consumption));
        
        if (powerTrend > 0.1) {
            healthScore -= 15;
            issues.push('Increasing power consumption trend');
            recommendations.push('Check for hardware degradation or efficiency issues');
        } else if (powerTrend < -0.1) {
            healthScore += 5; // Good for efficiency
        }
    }
    
    // Analyze system health data
    if (systemHealth) {
        if (systemHealth.health_status === 'critical') {
            healthScore -= 40;
            issues.push('System health status critical');
            recommendations.push('Immediate attention required - check system logs');
        } else if (systemHealth.health_status === 'warning') {
            healthScore -= 20;
            issues.push('System health status warning');
            recommendations.push('Investigate system warnings');
        }
        
        if (systemHealth.error_rate > 0.01) { // > 1% error rate
            healthScore -= 25;
            issues.push(`High error rate detected (${(systemHealth.error_rate * 100).toFixed(2)}%)`);
            recommendations.push('Review error logs and investigate root causes');
        }
    }
    
    // Determine health status
    let healthStatus;
    if (healthScore >= 80) {
        healthStatus = 'healthy';
    } else if (healthScore >= 60) {
        healthStatus = 'warning';
    } else {
        healthStatus = 'critical';
    }
    
    return {
        healthStatus,
        healthScore: Math.max(0, healthScore),
        issues,
        recommendations
    };
}

function calculateTrend(values) {
    if (values.length < 2) return 0;
    
    const n = values.length;
    const xValues = Array.from({length: n}, (_, i) => i);
    
    const sumX = xValues.reduce((a, b) => a + b, 0);
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
    const sumXX = xValues.reduce((a, b) => a + b * b, 0);
    
    return (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
}

async function updateMaintenancePrediction(nodeId, healthAnalysis) {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    // Predict failure probability and remaining lifetime
    const failureProb = calculateFailureProbability(healthAnalysis);
    const remainingLifetime = estimateRemainingLifetime(healthAnalysis);
    
    const predictionData = {
        node_id: nodeId,
        component_type: 'general', // Could be more specific based on data
        predicted_failure_date: new Date(Date.now() + remainingLifetime * 24 * 60 * 60 * 1000).toISOString(),
        failure_probability: failureProb,
        estimated_remaining_lifetime_days: remainingLifetime,
        recommended_action: getRecommendedAction(healthAnalysis),
        priority_level: getPriorityLevel(healthAnalysis.healthScore, failureProb)
    };
    
    // Check if prediction exists
    const existingResponse = await fetch(
        `${supabaseUrl}/rest/v1/maintenance_predictions?node_id=eq.${nodeId}`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    const existing = await existingResponse.json();
    
    if (existing.length > 0) {
        // Update existing prediction
        await fetch(`${supabaseUrl}/rest/v1/maintenance_predictions?id=eq.${existing[0].id}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'Content-Type': 'application/json',
                'apikey': supabaseKey
            },
            body: JSON.stringify({...predictionData, updated_at: new Date().toISOString()})
        });
    } else {
        // Create new prediction
        await fetch(`${supabaseUrl}/rest/v1/maintenance_predictions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'Content-Type': 'application/json',
                'apikey': supabaseKey
            },
            body: JSON.stringify(predictionData)
        });
    }
}

function calculateFailureProbability(healthAnalysis) {
    let prob = 0.01; // Base 1% failure probability
    
    // Adjust based on health score
    if (healthAnalysis.healthScore < 40) {
        prob += 0.3;
    } else if (healthAnalysis.healthScore < 60) {
        prob += 0.15;
    } else if (healthAnalysis.healthScore < 80) {
        prob += 0.05;
    }
    
    // Adjust based on critical issues
    const criticalIssues = healthAnalysis.issues.filter(issue => 
        issue.includes('critical') || issue.includes('Critical') || issue.includes('temperature')
    );
    
    prob += criticalIssues.length * 0.1;
    
    return Math.min(0.95, Math.max(0.01, prob));
}

function estimateRemainingLifetime(healthAnalysis) {
    let days = 365; // Base 1 year
    
    if (healthAnalysis.healthScore < 40) {
        days = 30; // Critical condition
    } else if (healthAnalysis.healthScore < 60) {
        days = 90; // Warning condition
    } else if (healthAnalysis.healthScore < 80) {
        days = 180; // Minor issues
    }
    
    return days;
}

function getRecommendedAction(healthAnalysis) {
    if (healthAnalysis.healthScore < 40) {
        return 'Immediate maintenance required';
    } else if (healthAnalysis.healthScore < 60) {
        return 'Schedule maintenance within 2 weeks';
    } else if (healthAnalysis.healthScore < 80) {
        return 'Preventive maintenance recommended';
    } else {
        return 'Continue normal operation';
    }
}

function getPriorityLevel(healthScore, failureProb) {
    if (healthScore < 40 || failureProb > 0.5) {
        return 'urgent';
    } else if (healthScore < 60 || failureProb > 0.3) {
        return 'high';
    } else if (healthScore < 80 || failureProb > 0.15) {
        return 'medium';
    } else {
        return 'low';
    }
}

async function predictNodeFailures(analysisType = 'all') {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    // Get all nodes with recent data
    const response = await fetch(
        `${supabaseUrl}/rest/v1/resource_metrics?select=node_id&timestamp=gte.${new Date(Date.now() - 24*60*60*1000).toISOString()}&order=node_id`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error('Failed to fetch node data');
    }
    
    const nodeIds = [...new Set((await response.json()).map(d => d.node_id))];
    const predictions = [];
    
    for (const nodeId of nodeIds) {
        const healthAnalysis = await analyzeNodeHealth(nodeId);
        predictions.push({
            node_id: nodeId,
            health_status: healthAnalysis.healthStatus,
            priority_level: getPriorityLevel(healthAnalysis.healthScore, calculateFailureProbability(healthAnalysis)),
            recommendations: healthAnalysis.recommendations
        });
    }
    
    return {
        analysis_type: analysisType,
        total_nodes: nodeIds.length,
        predictions: predictions.sort((a, b) => {
            const priorityOrder = {urgent: 4, high: 3, medium: 2, low: 1};
            return priorityOrder[b.priority_level] - priorityOrder[a.priority_level];
        }),
        generated_at: new Date().toISOString()
    };
}

async function updatePredictions() {
    // Update all maintenance predictions
    const predictionResults = await predictNodeFailures('bulk_update');
    
    return {
        updated_predictions: predictionResults.predictions.length,
        urgent_cases: predictionResults.predictions.filter(p => p.priority_level === 'urgent').length,
        high_priority_cases: predictionResults.predictions.filter(p => p.priority_level === 'high').length,
        updated_at: new Date().toISOString()
    };
}

async function getMaintenanceSchedule() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    const response = await fetch(
        `${supabaseUrl}/rest/v1/maintenance_predictions?order=predicted_failure_date.asc&limit=50`,
        {
            headers: {
                'Authorization': `Bearer ${supabaseKey}`,
                'apikey': supabaseKey
            }
        }
    );
    
    if (!response.ok) {
        throw new Error('Failed to fetch maintenance schedule');
    }
    
    const predictions = await response.json();
    
    return {
        schedule: predictions.map(p => ({
            node_id: p.node_id,
            predicted_failure_date: p.predicted_failure_date,
            failure_probability: p.failure_probability,
            priority_level: p.priority_level,
            recommended_action: p.recommended_action
        })),
        generated_at: new Date().toISOString()
    };
}