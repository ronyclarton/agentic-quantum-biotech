-- Comprehensive Monitoring and Analytics Database Schema
-- Created for Real-time Training Metrics and Infrastructure Analytics

-- Training metrics table
CREATE TABLE training_metrics (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    model_name VARCHAR(255) NOT NULL,
    training_step BIGINT NOT NULL,
    epoch BIGINT,
    learning_rate DECIMAL(15,10),
    loss_value DECIMAL(15,8),
    accuracy DECIMAL(8,6),
    precision DECIMAL(8,6),
    recall DECIMAL(8,6),
    f1_score DECIMAL(8,6),
    gpu_utilization DECIMAL(5,2),
    cpu_utilization DECIMAL(5,2),
    memory_usage DECIMAL(10,2), -- in MB
    gpu_memory DECIMAL(10,2), -- in MB
    batch_size BIGINT,
    throughput_samples_per_sec DECIMAL(10,2),
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    tags JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Resource utilization metrics table
CREATE TABLE resource_metrics (
    id BIGSERIAL PRIMARY KEY,
    node_id VARCHAR(255) NOT NULL,
    host_type VARCHAR(100), -- 'gpu', 'cpu', 'storage', 'network'
    resource_type VARCHAR(100), -- 'cpu', 'memory', 'disk', 'network', 'gpu'
    utilization_percentage DECIMAL(5,2),
    available_amount DECIMAL(15,2),
    used_amount DECIMAL(15,2),
    total_amount DECIMAL(15,2),
    load_average DECIMAL(10,2),
    network_throughput DECIMAL(15,2), -- MB/s
    disk_io_ops DECIMAL(10,2), -- ops/sec
    temperature DECIMAL(5,2), -- Celsius
    power_consumption DECIMAL(10,2), -- Watts
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Cost tracking table
CREATE TABLE cost_metrics (
    id BIGSERIAL PRIMARY KEY,
    resource_id VARCHAR(255) NOT NULL,
    service_type VARCHAR(100), -- 'compute', 'storage', 'network', 'gpu'
    provider VARCHAR(100), -- 'aws', 'gcp', 'azure', 'local'
    cost_per_hour DECIMAL(10,6),
    cost_per_month DECIMAL(10,2),
    usage_hours DECIMAL(10,2),
    total_cost DECIMAL(10,2),
    efficiency_score DECIMAL(5,2), -- 0-100, cost per performance
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    billing_period VARCHAR(50),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Anomaly detection results table
CREATE TABLE anomaly_detections (
    id BIGSERIAL PRIMARY KEY,
    metric_type VARCHAR(100) NOT NULL, -- 'training', 'resource', 'cost'
    metric_id BIGINT,
    anomaly_score DECIMAL(10,6), -- 0-1 probability
    severity_level VARCHAR(20), -- 'low', 'medium', 'high', 'critical'
    detected_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'investigating', 'resolved', 'false_positive'
    description TEXT,
    recommendation TEXT,
    metadata JSONB
);

-- Predictive maintenance alerts table
CREATE TABLE maintenance_predictions (
    id BIGSERIAL PRIMARY KEY,
    node_id VARCHAR(255) NOT NULL,
    component_type VARCHAR(100), -- 'gpu', 'cpu', 'memory', 'disk', 'network'
    predicted_failure_date TIMESTAMPTZ,
    failure_probability DECIMAL(5,4), -- 0-1
    estimated_remaining_lifetime_days BIGINT,
    recommended_action VARCHAR(255),
    priority_level VARCHAR(20), -- 'low', 'medium', 'high', 'urgent'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Alert rules and notifications table
CREATE TABLE alert_rules (
    id BIGSERIAL PRIMARY KEY,
    rule_name VARCHAR(255) NOT NULL UNIQUE,
    metric_type VARCHAR(100) NOT NULL,
    condition_operator VARCHAR(20), -- '>', '<', '>=', '<=', '=', '!=', 'between'
    threshold_value DECIMAL(15,6),
    threshold_value_high DECIMAL(15,6),
    time_window_minutes BIGINT DEFAULT 5,
    severity VARCHAR(20) DEFAULT 'medium',
    notification_channels JSONB, -- ['email', 'slack', 'webhook']
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Alert notifications log table
CREATE TABLE alert_notifications (
    id BIGSERIAL PRIMARY KEY,
    alert_rule_id BIGINT REFERENCES alert_rules(id),
    triggered_at TIMESTAMPTZ DEFAULT NOW(),
    notification_channel VARCHAR(50),
    recipient VARCHAR(255),
    message TEXT,
    status VARCHAR(20), -- 'sent', 'failed', 'pending'
    response_code VARCHAR(10),
    response_message TEXT,
    retry_count INTEGER DEFAULT 0
);

-- Performance analytics table for ML insights
CREATE TABLE performance_analytics (
    id BIGSERIAL PRIMARY KEY,
    analysis_type VARCHAR(100), -- 'trend', 'pattern', 'optimization', 'forecast'
    source_metric VARCHAR(100),
    analysis_period_start TIMESTAMPTZ,
    analysis_period_end TIMESTAMPTZ,
    result_data JSONB, -- ML model results
    confidence_score DECIMAL(5,4),
    insights JSONB,
    recommendations JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Custom metrics definitions table
CREATE TABLE custom_metrics (
    id BIGSERIAL PRIMARY KEY,
    metric_name VARCHAR(255) NOT NULL UNIQUE,
    metric_type VARCHAR(100), -- 'counter', 'gauge', 'histogram', 'summary'
    description TEXT,
    unit VARCHAR(50),
    tags_schema JSONB,
    collection_interval_seconds BIGINT DEFAULT 60,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Custom metric values table
CREATE TABLE custom_metric_values (
    id BIGSERIAL PRIMARY KEY,
    metric_name VARCHAR(255) NOT NULL,
    value DECIMAL(15,6) NOT NULL,
    tags JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- System health overview table
CREATE TABLE system_health (
    id BIGSERIAL PRIMARY KEY,
    component_name VARCHAR(255) NOT NULL,
    health_status VARCHAR(20), -- 'healthy', 'warning', 'critical', 'unknown'
    uptime_percentage DECIMAL(5,2),
    last_check TIMESTAMPTZ DEFAULT NOW(),
    response_time_ms DECIMAL(10,2),
    error_rate DECIMAL(5,4),
    metadata JSONB
);

-- Create indexes for better query performance
CREATE INDEX idx_training_metrics_session ON training_metrics(session_id);
CREATE INDEX idx_training_metrics_timestamp ON training_metrics(timestamp);
CREATE INDEX idx_training_metrics_model ON training_metrics(model_name);
CREATE INDEX idx_resource_metrics_node ON resource_metrics(node_id);
CREATE INDEX idx_resource_metrics_timestamp ON resource_metrics(timestamp);
CREATE INDEX idx_cost_metrics_resource ON cost_metrics(resource_id);
CREATE INDEX idx_cost_metrics_timestamp ON cost_metrics(timestamp);
CREATE INDEX idx_anomaly_detections_type ON anomaly_detections(metric_type);
CREATE INDEX idx_anomaly_detections_status ON anomaly_detections(status);
CREATE INDEX idx_maintenance_predictions_node ON maintenance_predictions(node_id);
CREATE INDEX idx_alert_rules_active ON alert_rules(is_active);
CREATE INDEX idx_alert_notifications_time ON alert_notifications(triggered_at);
CREATE INDEX idx_custom_metric_values_name ON custom_metric_values(metric_name);
CREATE INDEX idx_custom_metric_values_timestamp ON custom_metric_values(timestamp);
CREATE INDEX idx_system_health_component ON system_health(component_name);

-- Create time-series optimized tables
CREATE TABLE training_metrics_timeseries (
    LIKE training_metrics INCLUDING ALL
);

CREATE TABLE resource_metrics_timeseries (
    LIKE resource_metrics INCLUDING ALL
);

-- Create views for common queries
CREATE VIEW training_performance_summary AS
SELECT 
    model_name,
    session_id,
    COUNT(*) as total_steps,
    AVG(accuracy) as avg_accuracy,
    AVG(loss_value) as avg_loss,
    AVG(gpu_utilization) as avg_gpu_util,
    AVG(memory_usage) as avg_memory_usage,
    MIN(timestamp) as training_start,
    MAX(timestamp) as training_end,
    MAX(timestamp) - MIN(timestamp) as training_duration
FROM training_metrics
WHERE timestamp > NOW() - INTERVAL '7 days'
GROUP BY model_name, session_id;

CREATE VIEW resource_utilization_summary AS
SELECT 
    node_id,
    host_type,
    AVG(utilization_percentage) as avg_utilization,
    MAX(utilization_percentage) as peak_utilization,
    AVG(temperature) as avg_temperature,
    AVG(power_consumption) as avg_power,
    COUNT(*) as data_points
FROM resource_metrics
WHERE timestamp > NOW() - INTERVAL '24 hours'
GROUP BY node_id, host_type;

-- Create function for automated metric cleanup
CREATE OR REPLACE FUNCTION cleanup_old_metrics()
RETURNS void AS $$
BEGIN
    -- Delete metrics older than 1 year
    DELETE FROM training_metrics WHERE timestamp < NOW() - INTERVAL '1 year';
    DELETE FROM resource_metrics WHERE timestamp < NOW() - INTERVAL '1 year';
    DELETE FROM cost_metrics WHERE timestamp < NOW() - INTERVAL '2 years';
    DELETE FROM anomaly_detections WHERE detected_at < NOW() - INTERVAL '30 days';
    DELETE FROM custom_metric_values WHERE timestamp < NOW() - INTERVAL '6 months';
    DELETE FROM system_health WHERE last_check < NOW() - INTERVAL '1 month';
    
    -- Archive resolved anomalies older than 7 days
    UPDATE anomaly_detections 
    SET status = 'archived' 
    WHERE status = 'resolved' 
    AND resolved_at < NOW() - INTERVAL '7 days';
END;
$$ LANGUAGE plpgsql;