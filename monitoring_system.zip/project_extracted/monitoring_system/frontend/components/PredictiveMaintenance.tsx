/**
 * Predictive Maintenance Component
 * ML-powered infrastructure health monitoring and failure prediction
 */

import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface MaintenancePrediction {
  id: string;
  node_id: string;
  component_type: string;
  predicted_failure_date: string;
  failure_probability: number;
  estimated_remaining_lifetime_days: number;
  recommended_action: string;
  priority_level: 'low' | 'medium' | 'high' | 'urgent';
  created_at: string;
  updated_at: string;
}

interface HealthMetrics {
  node_id: string;
  health_status: 'healthy' | 'warning' | 'critical' | 'unknown';
  health_score: number;
  temperature: number;
  utilization: number;
  error_rate: number;
  last_check: string;
}

const PredictiveMaintenance: React.FC = () => {
  const [predictions, setPredictions] = useState<MaintenancePrediction[]>([]);
  const [healthMetrics, setHealthMetrics] = useState<HealthMetrics[]>([]);
  const [selectedTimeRange, setSelectedTimeRange] = useState('30d');
  const [selectedPriority, setSelectedPriority] = useState('all');
  const [viewMode, setViewMode] = useState<'overview' | 'predictions' | 'health' | 'schedule'>('overview');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchMaintenanceData();
  }, [selectedTimeRange]);

  const fetchMaintenanceData = async () => {
    setIsLoading(true);
    try {
      const [predictionsRes, healthRes] = await Promise.all([
        fetch(`/api/maintenance/predictions?range=${selectedTimeRange}`),
        fetch('/api/maintenance/health')
      ]);

      const predictionsData = await predictionsRes.json();
      const healthData = await healthRes.json();

      setPredictions(predictionsData.predictions || []);
      setHealthMetrics(healthData.metrics || []);
    } catch (error) {
      console.error('Failed to fetch maintenance data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Filter predictions
  const filteredPredictions = selectedPriority === 'all' 
    ? predictions 
    : predictions.filter(p => p.priority_level === selectedPriority);

  // Calculate statistics
  const stats = {
    total_predictions: predictions.length,
    urgent_cases: predictions.filter(p => p.priority_level === 'urgent').length,
    high_cases: predictions.filter(p => p.priority_level === 'high').length,
    avg_health_score: healthMetrics.length > 0 
      ? healthMetrics.reduce((sum, h) => sum + h.health_score, 0) / healthMetrics.length 
      : 0
  };

  // Generate health trend data (simulated)
  const generateHealthTrendData = () => {
    const days = 30;
    const data = [];
    
    for (let i = days; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      
      data.push({
        date: date.toLocaleDateString(),
        health_score: 70 + Math.random() * 30,
        temperature: 40 + Math.random() * 30,
        utilization: 30 + Math.random() * 60,
        predictions: Math.floor(Math.random() * 5)
      });
    }
    
    return data;
  };

  const healthTrendData = generateHealthTrendData();

  // Calculate maintenance schedule
  const getMaintenanceSchedule = () => {
    const schedule = predictions
      .filter(p => p.priority_level === 'urgent' || p.priority_level === 'high')
      .sort((a, b) => new Date(a.predicted_failure_date).getTime() - new Date(b.predicted_failure_date).getTime())
      .slice(0, 10);

    return schedule.map(prediction => ({
      ...prediction,
      days_until_failure: Math.ceil(
        (new Date(prediction.predicted_failure_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
      )
    }));
  };

  const maintenanceSchedule = getMaintenanceSchedule();

  // Generate health radar data
  const getHealthRadarData = () => {
    const avgMetrics = healthMetrics.length > 0 ? {
      health_score: healthMetrics.reduce((sum, h) => sum + h.health_score, 0) / healthMetrics.length,
      temperature: 100 - (healthMetrics.reduce((sum, h) => sum + h.temperature, 0) / healthMetrics.length / 100 * 100),
      utilization: healthMetrics.reduce((sum, h) => sum + h.utilization, 0) / healthMetrics.length,
      reliability: 85 + Math.random() * 15, // Simulated reliability score
      efficiency: 70 + Math.random() * 30, // Simulated efficiency score
      security: 90 + Math.random() * 10 // Simulated security score
    } : {
      health_score: 75,
      temperature: 80,
      utilization: 65,
      reliability: 85,
      efficiency: 70,
      security: 90
    };

    return [
      { metric: 'Health Score', value: avgMetrics.health_score, fullMark: 100 },
      { metric: 'Cooling', value: avgMetrics.temperature, fullMark: 100 },
      { metric: 'Utilization', value: avgMetrics.utilization, fullMark: 100 },
      { metric: 'Reliability', value: avgMetrics.reliability, fullMark: 100 },
      { metric: 'Efficiency', value: avgMetrics.efficiency, fullMark: 100 },
      { metric: 'Security', value: avgMetrics.security, fullMark: 100 }
    ];
  };

  const healthRadarData = getHealthRadarData();

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-red-700 bg-red-100 border-red-300';
      case 'high': return 'text-orange-700 bg-orange-100 border-orange-300';
      case 'medium': return 'text-yellow-700 bg-yellow-100 border-yellow-300';
      case 'low': return 'text-blue-700 bg-blue-100 border-blue-300';
      default: return 'text-gray-700 bg-gray-100 border-gray-300';
    }
  };

  const getHealthStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-700 bg-green-100';
      case 'warning': return 'text-yellow-700 bg-yellow-100';
      case 'critical': return 'text-red-700 bg-red-100';
      default: return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Predictive Maintenance</h2>
            <p className="text-sm text-gray-600">
              AI-powered infrastructure health monitoring and failure prediction
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <select
              value={selectedTimeRange}
              onChange={(e) => setSelectedTimeRange(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
            </select>

            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>

            <div className="flex border border-gray-300 rounded-md">
              {(['overview', 'predictions', 'health', 'schedule'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-3 py-1 text-sm capitalize ${
                    viewMode === mode 
                      ? 'bg-blue-500 text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  } ${mode !== 'overview' ? 'border-l border-gray-300' : ''}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.total_predictions}</div>
            <div className="text-xs text-gray-600">Total Predictions</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{stats.urgent_cases}</div>
            <div className="text-xs text-gray-600">Urgent Cases</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.high_cases}</div>
            <div className="text-xs text-gray-600">High Priority</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.avg_health_score.toFixed(1)}%</div>
            <div className="text-xs text-gray-600">Avg Health Score</div>
          </div>
        </div>
      </div>

      {/* Overview Mode */}
      {viewMode === 'overview' && (
        <div className="p-6 space-y-6">
          {/* Health Trend Chart */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Infrastructure Health Trends</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={healthTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="health_score" stroke="#10B981" strokeWidth={2} name="Health Score" />
                  <Line type="monotone" dataKey="temperature" stroke="#EF4444" strokeWidth={2} name="Temperature" />
                  <Area type="monotone" dataKey="utilization" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.3} name="Utilization %" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Health Radar Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Infrastructure Health Radar</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={healthRadarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="metric" />
                    <PolarRadiusAxis angle={60} domain={[0, 100]} />
                    <Radar
                      name="Health Metrics"
                      dataKey="value"
                      stroke="#3B82F6"
                      fill="#3B82F6"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Priority Breakdown */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Maintenance Priority Breakdown</h3>
              <div className="space-y-3">
                {['urgent', 'high', 'medium', 'low'].map(priority => {
                  const count = predictions.filter(p => p.priority_level === priority).length;
                  const percentage = predictions.length > 0 ? (count / predictions.length) * 100 : 0;
                  
                  return (
                    <div key={priority} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className={`w-3 h-3 rounded-full mr-3 ${
                          priority === 'urgent' ? 'bg-red-500' :
                          priority === 'high' ? 'bg-orange-500' :
                          priority === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                        }`}></div>
                        <span className="text-sm font-medium capitalize">{priority}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm text-gray-600 mr-3">{count} items</span>
                        <span className="text-sm font-bold text-gray-900">{percentage.toFixed(1)}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Recent Predictions */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Recent Predictions</h3>
            <div className="space-y-3">
              {filteredPredictions.slice(0, 5).map((prediction) => (
                <div
                  key={prediction.id}
                  className={`border-l-4 p-4 rounded-r-lg ${getPriorityColor(prediction.priority_level)}`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center mb-1">
                        <span className="text-sm font-medium">
                          {prediction.node_id.substring(0, 8)}...
                        </span>
                        <span className="ml-2 text-xs text-gray-600">
                          {prediction.component_type}
                        </span>
                      </div>
                      <p className="text-sm">{prediction.recommended_action}</p>
                      <p className="text-xs text-gray-600 mt-1">
                        Failure probability: {(prediction.failure_probability * 100).toFixed(1)}%
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {Math.ceil((new Date(prediction.predicted_failure_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days
                      </div>
                      <div className="text-xs text-gray-600">until failure</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Predictions Mode */}
      {viewMode === 'predictions' && (
        <div className="p-6">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-sm font-medium text-gray-700">Maintenance Predictions</h3>
            <button className="px-3 py-1 bg-blue-600 text-white hover:bg-blue-700 rounded-md text-sm">
              Refresh Predictions
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Node</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Component</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Failure Probability</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Days Until Failure</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action Required</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredPredictions.map((prediction) => {
                  const daysUntilFailure = Math.ceil(
                    (new Date(prediction.predicted_failure_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                  );
                  
                  return (
                    <tr key={prediction.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {prediction.node_id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.component_type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className={`h-2 rounded-full ${
                                prediction.failure_probability > 0.7 ? 'bg-red-600' :
                                prediction.failure_probability > 0.4 ? 'bg-yellow-600' : 'bg-green-600'
                              }`}
                              style={{ width: `${prediction.failure_probability * 100}%` }}
                            ></div>
                          </div>
                          {(prediction.failure_probability * 100).toFixed(1)}%
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {daysUntilFailure > 0 ? `${daysUntilFailure} days` : 'Overdue'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPriorityColor(prediction.priority_level)}`}>
                          {prediction.priority_level}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.recommended_action}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Health Mode */}
      {viewMode === 'health' && (
        <div className="p-6 space-y-6">
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Current Health Status</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {healthMetrics.map((metric, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-700">{metric.node_id}</span>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getHealthStatusColor(metric.health_status)}`}>
                      {metric.health_status}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs text-gray-600 mb-1">
                        <span>Health Score</span>
                        <span>{metric.health_score.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            metric.health_score >= 80 ? 'bg-green-600' :
                            metric.health_score >= 60 ? 'bg-yellow-600' : 'bg-red-600'
                          }`}
                          style={{ width: `${metric.health_score}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-gray-600">Temperature:</span>
                        <span className="ml-1 font-medium">{metric.temperature.toFixed(1)}°C</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Utilization:</span>
                        <span className="ml-1 font-medium">{metric.utilization.toFixed(1)}%</span>
                      </div>
                    </div>
                    
                    <div className="text-xs text-gray-600">
                      Last check: {new Date(metric.last_check).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Schedule Mode */}
      {viewMode === 'schedule' && (
        <div className="p-6">
          <h3 className="text-sm font-medium text-gray-700 mb-4">Maintenance Schedule</h3>
          
          {maintenanceSchedule.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <svg className="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <p>No urgent maintenance scheduled</p>
            </div>
          ) : (
            <div className="space-y-4">
              {maintenanceSchedule.map((item) => (
                <div key={item.id} className={`border-l-4 p-4 rounded-r-lg ${getPriorityColor(item.priority_level)}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center mb-1">
                        <span className="text-sm font-medium">{item.node_id}</span>
                        <span className="ml-2 text-xs text-gray-600">{item.component_type}</span>
                      </div>
                      <p className="text-sm">{item.recommended_action}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {item.days_until_failure > 0 ? `${item.days_until_failure} days` : 'Overdue'}
                      </div>
                      <div className="text-xs text-gray-600">
                        {new Date(item.predicted_failure_date).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PredictiveMaintenance;