/**
 * Resource Utilization Component
 * Real-time infrastructure resource monitoring with advanced analytics
 */

import React, { useState, useEffect } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadialBarChart, RadialBar } from 'recharts';
import * as d3 from 'd3';

interface ResourceMetric {
  node_id: string;
  host_type: string;
  resource_type: string;
  utilization_percentage: number;
  available_amount: number;
  used_amount: number;
  total_amount: number;
  load_average: number;
  network_throughput: number;
  disk_io_ops: number;
  temperature: number;
  power_consumption: number;
  timestamp: string;
}

interface Props {
  metrics: ResourceMetric[];
  timeRange: string;
}

const ResourceUtilization: React.FC<Props> = ({ metrics, timeRange }) => {
  const [selectedNode, setSelectedNode] = useState<string>('all');
  const [selectedResourceType, setSelectedResourceType] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'overview' | 'detailed' | 'heatmap'>('overview');

  // Get unique nodes and resource types
  const nodes = [...new Set(metrics.map(m => m.node_id))];
  const resourceTypes = [...new Set(metrics.map(m => m.resource_type))];
  const hostTypes = [...new Set(metrics.map(m => m.host_type))];

  // Filter metrics
  const filteredMetrics = metrics.filter(metric => {
    const nodeMatch = selectedNode === 'all' || metric.node_id === selectedNode;
    const resourceMatch = selectedResourceType === 'all' || metric.resource_type === selectedResourceType;
    return nodeMatch && resourceMatch;
  });

  // Get latest metrics for each node
  const latestMetrics = getLatestMetricsByNode(filteredMetrics);

  // Calculate aggregated data for different visualizations
  const utilizationData = calculateUtilizationData(latestMetrics);
  const temperatureData = calculateTemperatureData(filteredMetrics);
  const resourceDistribution = calculateResourceDistribution(filteredMetrics);
  const performanceData = calculatePerformanceData(filteredMetrics);

  function getLatestMetricsByNode(metrics: ResourceMetric[]): Record<string, ResourceMetric[]> {
    const grouped: Record<string, ResourceMetric[]> = {};
    
    metrics.forEach(metric => {
      if (!grouped[metric.node_id]) {
        grouped[metric.node_id] = [];
      }
      grouped[metric.node_id].push(metric);
    });

    // Get latest 10 metrics for each node
    Object.keys(grouped).forEach(nodeId => {
      grouped[nodeId] = grouped[nodeId]
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);
    });

    return grouped;
  }

  function calculateUtilizationData(latestMetrics: Record<string, ResourceMetric[]>) {
    return Object.entries(latestMetrics).map(([nodeId, nodeMetrics]) => {
      const cpuMetrics = nodeMetrics.filter(m => m.resource_type === 'cpu');
      const gpuMetrics = nodeMetrics.filter(m => m.resource_type === 'gpu');
      const memoryMetrics = nodeMetrics.filter(m => m.resource_type === 'memory');

      return {
        node: nodeId.substring(0, 8) + '...',
        full_node: nodeId,
        cpu_util: cpuMetrics.length > 0 ? cpuMetrics[0].utilization_percentage : 0,
        gpu_util: gpuMetrics.length > 0 ? gpuMetrics[0].utilization_percentage : 0,
        memory_util: memoryMetrics.length > 0 ? memoryMetrics[0].utilization_percentage : 0,
        temperature: nodeMetrics.length > 0 ? nodeMetrics[0].temperature : 0,
        power: nodeMetrics.length > 0 ? nodeMetrics[0].power_consumption : 0,
        host_type: nodeMetrics.length > 0 ? nodeMetrics[0].host_type : 'unknown'
      };
    });
  }

  function calculateTemperatureData(metrics: ResourceMetric[]) {
    const hourlyData: Record<string, { temps: number[], times: string[] }> = {};
    
    metrics.forEach(metric => {
      if (metric.temperature !== null && metric.temperature !== undefined) {
        const hour = new Date(metric.timestamp).getHours();
        const hourKey = `${hour}:00`;
        
        if (!hourlyData[hourKey]) {
          hourlyData[hourKey] = { temps: [], times: [] };
        }
        
        hourlyData[hourKey].temps.push(metric.temperature);
        hourlyData[hourKey].times.push(hourKey);
      }
    });

    return Object.entries(hourlyData).map(([time, data]) => ({
      time,
      avg_temperature: data.temps.reduce((a, b) => a + b, 0) / data.temps.length,
      max_temperature: Math.max(...data.temps),
      min_temperature: Math.min(...data.temps)
    }));
  }

  function calculateResourceDistribution(metrics: ResourceMetric[]) {
    const distribution: Record<string, number> = {};
    
    metrics.forEach(metric => {
      const key = `${metric.host_type}_${metric.resource_type}`;
      distribution[key] = (distribution[key] || 0) + 1;
    });

    return Object.entries(distribution).map(([key, count]) => {
      const [hostType, resourceType] = key.split('_');
      return {
        name: `${hostType} ${resourceType}`,
        value: count,
        host_type: hostType,
        resource_type: resourceType
      };
    });
  }

  function calculatePerformanceData(metrics: ResourceMetric[]) {
    // Group by hour and calculate averages
    const hourlyPerf: Record<string, any> = {};
    
    metrics.forEach(metric => {
      const hour = new Date(metric.timestamp).toISOString().substring(0, 13) + ':00:00';
      
      if (!hourlyPerf[hour]) {
        hourlyPerf[hour] = {
          time: hour,
          throughput_samples: 0,
          io_ops: 0,
          count: 0
        };
      }
      
      hourlyPerf[hour].throughput_samples += metric.network_throughput || 0;
      hourlyPerf[hour].io_ops += metric.disk_io_ops || 0;
      hourlyPerf[hour].count += 1;
    });

    return Object.values(hourlyPerf).map((perf: any) => ({
      time: new Date(perf.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      throughput: perf.throughput_samples / perf.count,
      io_ops: perf.io_ops / perf.count
    }));
  }

  // Color schemes
  const utilizationColors = {
    cpu: '#3B82F6',
    gpu: '#F59E0B',
    memory: '#10B981',
    disk: '#EF4444',
    network: '#8B5CF6'
  };

  const pieColors = ['#3B82F6', '#F59E0B', '#10B981', '#EF4444', '#8B5CF6', '#06B6D4', '#84CC16'];

  // Health status calculation
  const getNodeHealth = (utilizationData: any[]) => {
    return utilizationData.map(node => {
      const avgUtil = (node.cpu_util + node.gpu_util + node.memory_util) / 3;
      let health = 'healthy';
      
      if (avgUtil > 90 || node.temperature > 85) {
        health = 'critical';
      } else if (avgUtil > 80 || node.temperature > 75) {
        health = 'warning';
      }
      
      return { ...node, health };
    });
  };

  const healthyNodes = getNodeHealth(utilizationData);

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Resource Utilization</h2>
            <p className="text-sm text-gray-600">
              Real-time infrastructure monitoring and performance analytics
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <select
              value={selectedNode}
              onChange={(e) => setSelectedNode(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Nodes</option>
              {nodes.map(node => (
                <option key={node} value={node}>{node.substring(0, 8)}...</option>
              ))}
            </select>

            <select
              value={selectedResourceType}
              onChange={(e) => setSelectedResourceType(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Resources</option>
              {resourceTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>

            <div className="flex border border-gray-300 rounded-md">
              {(['overview', 'detailed', 'heatmap'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-3 py-1 text-sm capitalize ${
                    viewMode === mode 
                      ? 'bg-blue-500 text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  } ${mode !== 'overview' ? 'border-l border-gray-300' : ''}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Overview Mode */}
      {viewMode === 'overview' && (
        <div className="p-6 space-y-6">
          {/* Node Health Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {['healthy', 'warning', 'critical'].map(status => {
              const count = healthyNodes.filter(node => node.health === status).length;
              const colors = {
                healthy: 'text-green-600 bg-green-100',
                warning: 'text-yellow-600 bg-yellow-100',
                critical: 'text-red-600 bg-red-100'
              };
              
              return (
                <div key={status} className={`px-4 py-3 rounded-lg ${colors[status]}`}>
                  <div className="text-2xl font-bold">{count}</div>
                  <div className="text-sm capitalize">{status} Nodes</div>
                </div>
              );
            })}
          </div>

          {/* Resource Utilization Chart */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Current Utilization by Node</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={healthyNodes}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="node" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => [`${value}%`, name.replace('_', ' ').toUpperCase()]}
                  />
                  <Legend />
                  <Bar dataKey="cpu_util" fill={utilizationColors.cpu} name="CPU" />
                  <Bar dataKey="gpu_util" fill={utilizationColors.gpu} name="GPU" />
                  <Bar dataKey="memory_util" fill={utilizationColors.memory} name="Memory" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Resource Distribution Pie Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Resource Distribution</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={resourceDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {resourceDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Temperature Monitoring */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Temperature Trends</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={temperatureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip formatter={(value) => [`${value}°C`, 'Temperature']} />
                    <Line 
                      type="monotone" 
                      dataKey="avg_temperature" 
                      stroke="#EF4444" 
                      strokeWidth={2}
                      dot={false}
                      name="Avg Temperature"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="max_temperature" 
                      stroke="#DC2626" 
                      strokeWidth={1}
                      strokeDasharray="5 5"
                      dot={false}
                      name="Max Temperature"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Mode */}
      {viewMode === 'detailed' && (
        <div className="p-6">
          {/* Performance Metrics */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-700 mb-4">Performance Metrics</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="throughput" 
                    stroke="#06B6D4" 
                    strokeWidth={2}
                    name="Throughput (MB/s)"
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="io_ops" 
                    stroke="#8B5CF6" 
                    strokeWidth={2}
                    name="IO Operations/sec"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Node Details Table */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Detailed Node Information</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Node</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CPU %</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GPU %</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Memory %</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Temperature</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Power</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {healthyNodes.map((node, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {node.full_node}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {node.host_type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${Math.min(100, node.cpu_util)}%` }}
                            ></div>
                          </div>
                          {node.cpu_util.toFixed(1)}%
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-yellow-600 h-2 rounded-full" 
                              style={{ width: `${Math.min(100, node.gpu_util)}%` }}
                            ></div>
                          </div>
                          {node.gpu_util.toFixed(1)}%
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ width: `${Math.min(100, node.memory_util)}%` }}
                            ></div>
                          </div>
                          {node.memory_util.toFixed(1)}%
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <span className={`${node.temperature > 80 ? 'text-red-600' : 'text-gray-900'}`}>
                          {node.temperature.toFixed(1)}°C
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {node.power.toFixed(1)}W
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          node.health === 'healthy' 
                            ? 'bg-green-100 text-green-800'
                            : node.health === 'warning'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {node.health}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Heatmap Mode */}
      {viewMode === 'heatmap' && (
        <div className="p-6">
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-700">Resource Utilization Heatmap</h3>
            <p className="text-xs text-gray-600">Color intensity represents utilization percentage</p>
          </div>
          
          {/* Simplified Heatmap Visualization */}
          <div className="grid grid-cols-1 gap-4">
            {healthyNodes.map((node, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">{node.full_node}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    node.health === 'healthy' ? 'bg-green-100 text-green-800' :
                    node.health === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {node.health}
                  </span>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: 'CPU', value: node.cpu_util, color: utilizationColors.cpu },
                    { label: 'GPU', value: node.gpu_util, color: utilizationColors.gpu },
                    { label: 'Memory', value: node.memory_util, color: utilizationColors.memory }
                  ].map(resource => (
                    <div key={resource.label} className="text-center">
                      <div className="text-xs text-gray-600 mb-1">{resource.label}</div>
                      <div 
                        className="h-8 rounded flex items-center justify-center text-white text-sm font-medium"
                        style={{ 
                          backgroundColor: resource.color,
                          opacity: Math.max(0.3, resource.value / 100)
                        }}
                      >
                        {resource.value.toFixed(1)}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ResourceUtilization;