/**
 * Training Metrics Component
 * Real-time visualization of training progress and performance
 */

import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import * as d3 from 'd3';

interface TrainingMetric {
  session_id: string;
  model_name: string;
  training_step: number;
  epoch?: number;
  learning_rate?: number;
  loss_value?: number;
  accuracy?: number;
  precision?: number;
  recall?: number;
  f1_score?: number;
  gpu_utilization?: number;
  cpu_utilization?: number;
  memory_usage?: number;
  gpu_memory?: number;
  batch_size?: number;
  throughput_samples_per_sec?: number;
  timestamp: string;
}

interface Props {
  metrics: TrainingMetric[];
  timeRange: string;
}

const TrainingMetrics: React.FC<Props> = ({ metrics, timeRange }) => {
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['accuracy', 'loss_value']);
  const [selectedSession, setSelectedSession] = useState<string>('all');
  const [chartType, setChartType] = useState<'line' | 'area'>('line');
  const svgRef = useRef<SVGSVGElement>(null);

  // Get unique sessions and models
  const sessions = [...new Set(metrics.map(m => m.session_id))];
  const models = [...new Set(metrics.map(m => m.model_name))];

  // Filter metrics based on selected session
  const filteredMetrics = selectedSession === 'all' 
    ? metrics 
    : metrics.filter(m => m.session_id === selectedSession);

  // Sort metrics by training step
  const sortedMetrics = filteredMetrics.sort((a, b) => a.training_step - b.training_step);

  // Process data for charts
  const chartData = sortedMetrics.map((metric, index) => ({
    step: metric.training_step,
    epoch: metric.epoch || Math.floor(index / 100),
    accuracy: metric.accuracy * 100 || null,
    loss: metric.loss_value || null,
    learning_rate: metric.learning_rate || null,
    gpu_utilization: metric.gpu_utilization || null,
    memory_usage: metric.memory_usage / 1024 || null, // Convert to GB
    throughput: metric.throughput_samples_per_sec || null,
    timestamp: new Date(metric.timestamp).toLocaleTimeString(),
    session_id: metric.session_id
  }));

  // Available metrics for selection
  const availableMetrics = [
    { key: 'accuracy', label: 'Accuracy (%)', color: '#10B981' },
    { key: 'loss', label: 'Loss', color: '#EF4444' },
    { key: 'learning_rate', label: 'Learning Rate', color: '#3B82F6' },
    { key: 'gpu_utilization', label: 'GPU Utilization (%)', color: '#F59E0B' },
    { key: 'memory_usage', label: 'Memory Usage (GB)', color: '#8B5CF6' },
    { key: 'throughput', label: 'Throughput (samples/sec)', color: '#06B6D4' }
  ];

  const toggleMetric = (metricKey: string) => {
    setSelectedMetrics(prev => 
      prev.includes(metricKey) 
        ? prev.filter(m => m !== metricKey)
        : [...prev, metricKey]
    );
  };

  // Custom D3.js chart for advanced visualization
  useEffect(() => {
    if (chartData.length === 0 || !svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const margin = { top: 20, right: 80, bottom: 30, left: 50 };
    const width = svg.node()?.getBoundingClientRect().width || 800;
    const height = 300;

    const g = svg
      .attr("width", width)
      .attr("height", height)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Scales
    const xScale = d3.scaleLinear()
      .domain(d3.extent(chartData, d => d.step) as [number, number])
      .range([0, width - margin.left - margin.right]);

    const yScale = d3.scaleLinear()
      .domain([0, 100])
      .range([height - margin.top - margin.bottom, 0]);

    // Line generator
    const line = d3.line<any>()
      .x(d => xScale(d.step))
      .y(d => yScale(d.value))
      .curve(d3.curveMonotoneX);

    // Create data for selected metrics
    const seriesData = selectedMetrics.map(metric => ({
      metric,
      data: chartData
        .filter(d => d[metric as keyof typeof d] !== null)
        .map(d => ({ step: d.step, value: d[metric as keyof typeof d] as number }))
    })).filter(s => s.data.length > 0);

    // Add axes
    g.append("g")
      .attr("transform", `translate(0,${height - margin.top - margin.bottom})`)
      .call(d3.axisBottom(xScale).tickFormat(d => `Step ${d}`));

    g.append("g")
      .call(d3.axisLeft(yScale));

    // Add lines
    seriesData.forEach((series, i) => {
      const metricInfo = availableMetrics.find(m => m.key === series.metric);
      if (!metricInfo) return;

      g.append("path")
        .datum(series.data)
        .attr("fill", "none")
        .attr("stroke", metricInfo.color)
        .attr("stroke-width", 2)
        .attr("d", line);

      // Add dots for data points
      g.selectAll(`.dot-${i}`)
        .data(series.data)
        .enter().append("circle")
        .attr("class", `dot-${i}`)
        .attr("cx", d => xScale(d.step))
        .attr("cy", d => yScale(d.value))
        .attr("r", 3)
        .attr("fill", metricInfo.color)
        .on("mouseover", function(event, d) {
          // Tooltip
          const tooltip = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0)
            .style("position", "absolute")
            .style("background", "rgba(0, 0, 0, 0.8)")
            .style("color", "white")
            .style("padding", "8px")
            .style("border-radius", "4px")
            .style("font-size", "12px");

          tooltip.transition()
            .duration(200)
            .style("opacity", .9);
          
          tooltip.html(`${metricInfo.label}: ${d.value.toFixed(4)}<br/>Step: ${d.step}`)
            .style("left", (event.pageX + 10) + "px")
            .style("top", (event.pageY - 28) + "px");
        })
        .on("mouseout", function() {
          d3.selectAll(".tooltip").remove();
        });
    });

  }, [chartData, selectedMetrics]);

  // Calculate statistics
  const getStatistics = () => {
    if (sortedMetrics.length === 0) return {};

    const recent = sortedMetrics.slice(-100); // Last 100 steps
    const bestAccuracy = Math.max(...recent.filter(m => m.accuracy).map(m => m.accuracy || 0)) * 100;
    const bestLoss = Math.min(...recent.filter(m => m.loss_value).map(m => m.loss_value || Infinity));
    const avgGPUUtil = recent.reduce((sum, m) => sum + (m.gpu_utilization || 0), 0) / recent.length;
    const avgThroughput = recent.reduce((sum, m) => sum + (m.throughput_samples_per_sec || 0), 0) / recent.length;

    return {
      total_steps: sortedMetrics.length,
      best_accuracy: bestAccuracy.toFixed(2),
      best_loss: bestLoss.toFixed(4),
      avg_gpu_util: avgGPUUtil.toFixed(1),
      avg_throughput: avgThroughput.toFixed(1)
    };
  };

  const stats = getStatistics();

  if (metrics.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-center h-64 text-gray-500">
          <div className="text-center">
            <svg className="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <p>No training metrics available</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Training Metrics</h2>
            <p className="text-sm text-gray-600">
              Real-time training progress and performance monitoring
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Session Filter */}
            <select
              value={selectedSession}
              onChange={(e) => setSelectedSession(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Sessions</option>
              {sessions.map(session => (
                <option key={session} value={session}>{session.substring(0, 8)}...</option>
              ))}
            </select>

            {/* Chart Type */}
            <select
              value={chartType}
              onChange={(e) => setChartType(e.target.value as 'line' | 'area')}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="line">Line Chart</option>
              <option value="area">Area Chart</option>
            </select>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.total_steps}</div>
            <div className="text-xs text-gray-600">Total Steps</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.best_accuracy}%</div>
            <div className="text-xs text-gray-600">Best Accuracy</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{stats.best_loss}</div>
            <div className="text-xs text-gray-600">Best Loss</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.avg_gpu_util}%</div>
            <div className="text-xs text-gray-600">Avg GPU Util</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.avg_throughput}</div>
            <div className="text-xs text-gray-600">Avg Throughput</div>
          </div>
        </div>
      </div>

      {/* Metric Selection */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex flex-wrap gap-2">
          {availableMetrics.map(metric => (
            <button
              key={metric.key}
              onClick={() => toggleMetric(metric.key)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                selectedMetrics.includes(metric.key)
                  ? 'text-white'
                  : 'text-gray-600 bg-gray-200 hover:bg-gray-300'
              }`}
              style={{
                backgroundColor: selectedMetrics.includes(metric.key) ? metric.color : undefined
              }}
            >
              {metric.label}
            </button>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="p-6">
        {/* Recharts Visualization */}
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'line' ? (
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="step" />
                <YAxis />
                <Tooltip 
                  labelFormatter={(value) => `Step: ${value}`}
                  formatter={(value, name) => [value, name]}
                />
                <Legend />
                {selectedMetrics.includes('accuracy') && (
                  <Line 
                    type="monotone" 
                    dataKey="accuracy" 
                    stroke="#10B981" 
                    strokeWidth={2}
                    dot={false}
                    name="Accuracy (%)"
                  />
                )}
                {selectedMetrics.includes('loss') && (
                  <Line 
                    type="monotone" 
                    dataKey="loss" 
                    stroke="#EF4444" 
                    strokeWidth={2}
                    dot={false}
                    name="Loss"
                  />
                )}
                {selectedMetrics.includes('gpu_utilization') && (
                  <Line 
                    type="monotone" 
                    dataKey="gpu_utilization" 
                    stroke="#F59E0B" 
                    strokeWidth={2}
                    dot={false}
                    name="GPU Utilization (%)"
                  />
                )}
              </LineChart>
            ) : (
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="step" />
                <YAxis />
                <Tooltip />
                <Legend />
                {selectedMetrics.includes('accuracy') && (
                  <Area 
                    type="monotone" 
                    dataKey="accuracy" 
                    stackId="1"
                    stroke="#10B981" 
                    fill="#10B981" 
                    fillOpacity={0.6}
                    name="Accuracy (%)"
                  />
                )}
                {selectedMetrics.includes('loss') && (
                  <Area 
                    type="monotone" 
                    dataKey="loss" 
                    stackId="2"
                    stroke="#EF4444" 
                    fill="#EF4444" 
                    fillOpacity={0.6}
                    name="Loss"
                  />
                )}
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* D3.js Advanced Visualization */}
        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-sm font-medium text-gray-700 mb-4">Advanced Visualization</h3>
          <svg ref={svgRef} className="w-full border border-gray-200 rounded"></svg>
        </div>
      </div>

      {/* Training Session Information */}
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <span className="font-medium text-gray-700">Current Model:</span>
            <span className="ml-2 text-gray-600">
              {models.length > 0 ? models[0] : 'N/A'}
            </span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Active Sessions:</span>
            <span className="ml-2 text-gray-600">{sessions.length}</span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Data Points:</span>
            <span className="ml-2 text-gray-600">{chartData.length}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrainingMetrics;