/**
 * Cost Analytics Component
 * ML-powered cost optimization insights and recommendations
 */

import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from 'recharts';
import * as d3 from 'd3';

interface CostMetric {
  resource_id: string;
  service_type: string;
  provider: string;
  cost_per_hour: number;
  cost_per_month: number;
  usage_hours: number;
  total_cost: number;
  efficiency_score: number;
  timestamp: string;
  billing_period: string;
}

interface CostInsight {
  category: string;
  service: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  recommendation: string;
  potential_savings: number;
}

interface Props {
  metrics: CostMetric[];
  timeRange: string;
}

const CostAnalytics: React.FC<Props> = ({ metrics, timeRange }) => {
  const [selectedProvider, setSelectedProvider] = useState<string>('all');
  const [selectedService, setSelectedService] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'overview' | 'trends' | 'optimization' | 'predictions'>('overview');
  const [costInsights, setCostInsights] = useState<CostInsight[]>([]);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);

  // Get unique providers and services
  const providers = [...new Set(metrics.map(m => m.provider))];
  const services = [...new Set(metrics.map(m => m.service_type))];

  // Filter metrics
  const filteredMetrics = metrics.filter(metric => {
    const providerMatch = selectedProvider === 'all' || metric.provider === selectedProvider;
    const serviceMatch = selectedService === 'all' || metric.service_type === selectedService;
    return providerMatch && serviceMatch;
  });

  // Calculate cost breakdowns
  const costBreakdown = calculateCostBreakdown(filteredMetrics);
  const trendData = calculateCostTrends(filteredMetrics);
  const efficiencyData = calculateEfficiencyMetrics(filteredMetrics);
  const providerComparison = calculateProviderComparison(filteredMetrics);

  useEffect(() => {
    if (filteredMetrics.length > 0) {
      generateCostInsights();
    }
  }, [filteredMetrics]);

  function calculateCostBreakdown(metrics: CostMetric[]) {
    const breakdown = {
      total_cost: 0,
      by_service: {} as Record<string, number>,
      by_provider: {} as Record<string, number>,
      by_hour: {} as Record<string, number>
    };

    metrics.forEach(metric => {
      breakdown.total_cost += metric.total_cost;
      
      // By service type
      breakdown.by_service[metric.service_type] = 
        (breakdown.by_service[metric.service_type] || 0) + metric.total_cost;
      
      // By provider
      breakdown.by_provider[metric.provider] = 
        (breakdown.by_provider[metric.provider] || 0) + metric.total_cost;
      
      // By hour (for trend analysis)
      const hour = new Date(metric.timestamp).getHours();
      const hourKey = `${hour}:00`;
      breakdown.by_hour[hourKey] = (breakdown.by_hour[hourKey] || 0) + metric.cost_per_hour;
    });

    // Convert to arrays for charts
    return {
      total_cost: breakdown.total_cost,
      service_data: Object.entries(breakdown.by_service).map(([name, value]) => ({ name, value })),
      provider_data: Object.entries(breakdown.by_provider).map(([name, value]) => ({ name, value })),
      hourly_data: Object.entries(breakdown.by_hour)
        .map(([time, value]) => ({ time, cost: value }))
        .sort((a, b) => a.time.localeCompare(b.time))
    };
  }

  function calculateCostTrends(metrics: CostMetric[]) {
    // Group by day and calculate daily costs
    const dailyCosts: Record<string, { cost: number; efficiency: number[] }> = {};
    
    metrics.forEach(metric => {
      const day = metric.timestamp.split('T')[0];
      if (!dailyCosts[day]) {
        dailyCosts[day] = { cost: 0, efficiency: [] };
      }
      
      dailyCosts[day].cost += metric.total_cost;
      dailyCosts[day].efficiency.push(metric.efficiency_score);
    });

    return Object.entries(dailyCosts)
      .map(([date, data]) => ({
        date: new Date(date).toLocaleDateString(),
        cost: data.cost,
        avg_efficiency: data.efficiency.reduce((a, b) => a + b, 0) / data.efficiency.length,
        potential_savings: data.cost * 0.15 // Estimate 15% potential savings
      }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  function calculateEfficiencyMetrics(metrics: CostMetric[]) {
    return metrics.map(metric => ({
      resource_id: metric.resource_id.substring(0, 8) + '...',
      service_type: metric.service_type,
      provider: metric.provider,
      efficiency_score: metric.efficiency_score,
      cost_per_hour: metric.cost_per_hour,
      cost_per_month: metric.cost_per_month,
      savings_opportunity: (100 - metric.efficiency_score) * metric.cost_per_month / 100
    })).sort((a, b) => a.efficiency_score - b.efficiency_score);
  }

  function calculateProviderComparison(metrics: CostMetric[]) {
    const comparison: Record<string, { 
      total_cost: number; 
      avg_efficiency: number; 
      services: Set<string>;
      count: number;
    }> = {};

    metrics.forEach(metric => {
      if (!comparison[metric.provider]) {
        comparison[metric.provider] = {
          total_cost: 0,
          avg_efficiency: 0,
          services: new Set(),
          count: 0
        };
      }
      
      comparison[metric.provider].total_cost += metric.total_cost;
      comparison[metric.provider].avg_efficiency += metric.efficiency_score;
      comparison[metric.provider].services.add(metric.service_type);
      comparison[metric.provider].count++;
    });

    return Object.entries(comparison).map(([provider, data]) => ({
      provider,
      total_cost: data.total_cost,
      avg_efficiency: data.avg_efficiency / data.count,
      service_count: data.services.size,
      monthly_cost: data.total_cost * 24 * 30 // Estimate monthly from hourly
    }));
  }

  async function generateCostInsights() {
    setIsGeneratingInsights(true);
    
    try {
      // Simulate ML-powered cost analysis
      const insights: CostInsight[] = [];
      
      // Analyze cost patterns
      const highCostServices = Object.entries(costBreakdown.by_service)
        .filter(([_, cost]) => cost > costBreakdown.total_cost * 0.3)
        .map(([service, cost]) => ({ service, cost }));

      highCostServices.forEach(({ service, cost }) => {
        insights.push({
          category: 'cost_optimization',
          service: service,
          priority: 'high',
          description: `${service} represents ${((cost / costBreakdown.total_cost) * 100).toFixed(1)}% of total costs`,
          recommendation: `Consider optimizing ${service} usage patterns or negotiating better rates`,
          potential_savings: cost * 0.2
        });
      });

      // Analyze efficiency patterns
      const lowEfficiencyResources = efficiencyData.filter(r => r.efficiency_score < 60);
      if (lowEfficiencyResources.length > 0) {
        insights.push({
          category: 'efficiency_improvement',
          service: 'general',
          priority: 'medium',
          description: `${lowEfficiencyResources.length} resources have low efficiency scores`,
          recommendation: 'Focus on right-sizing resources and optimizing workload distribution',
          potential_savings: lowEfficiencyResources.reduce((sum, r) => sum + r.savings_opportunity, 0)
        });
      }

      // Provider comparison insights
      const bestProvider = providerComparison.reduce((best, current) => 
        current.avg_efficiency > best.avg_efficiency ? current : best
      );
      
      insights.push({
        category: 'provider_optimization',
        service: 'all',
        priority: 'medium',
        description: `${bestProvider.provider} shows best efficiency (${bestProvider.avg_efficiency.toFixed(1)}%)`,
        recommendation: 'Consider migrating more workloads to higher-efficiency providers',
        potential_savings: costBreakdown.total_cost * 0.1
      });

      setCostInsights(insights);
    } catch (error) {
      console.error('Failed to generate cost insights:', error);
    } finally {
      setIsGeneratingInsights(false);
    }
  }

  const pieColors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#84CC16'];

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Cost Analytics</h2>
            <p className="text-sm text-gray-600">
              ML-powered cost optimization and spending insights
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <select
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Providers</option>
              {providers.map(provider => (
                <option key={provider} value={provider}>{provider}</option>
              ))}
            </select>

            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Services</option>
              {services.map(service => (
                <option key={service} value={service}>{service}</option>
              ))}
            </select>

            <div className="flex border border-gray-300 rounded-md">
              {(['overview', 'trends', 'optimization', 'predictions'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-3 py-1 text-sm capitalize ${
                    viewMode === mode 
                      ? 'bg-blue-500 text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  } ${mode !== 'overview' ? 'border-l border-gray-300' : ''}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Overview Mode */}
      {viewMode === 'overview' && (
        <div className="p-6 space-y-6">
          {/* Cost Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-blue-600">
                ${costBreakdown.total_cost.toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Total Cost</div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-green-600">
                ${(costBreakdown.total_cost * 0.15).toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Potential Savings</div>
            </div>
            <div className="bg-yellow-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-yellow-600">
                {providerComparison.length}
              </div>
              <div className="text-sm text-gray-600">Active Providers</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-600">
                {(efficiencyData.reduce((sum, r) => sum + r.efficiency_score, 0) / efficiencyData.length).toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600">Avg Efficiency</div>
            </div>
          </div>

          {/* Cost Breakdown Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Cost by Service Type</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={costBreakdown.service_data}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {costBreakdown.service_data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`$${Number(value).toFixed(2)}`, 'Cost']} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Cost by Provider</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={costBreakdown.provider_data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${Number(value).toFixed(2)}`, 'Cost']} />
                    <Bar dataKey="value" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Provider Comparison */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Provider Comparison</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Provider</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Cost</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Monthly Est.</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Efficiency</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Services</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Performance</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {providerComparison.map((provider, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {provider.provider}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${provider.total_cost.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${provider.monthly_cost.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ width: `${provider.avg_efficiency}%` }}
                            ></div>
                          </div>
                          {provider.avg_efficiency.toFixed(1)}%
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {provider.service_count}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          provider.avg_efficiency >= 80 
                            ? 'bg-green-100 text-green-800'
                            : provider.avg_efficiency >= 60
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {provider.avg_efficiency >= 80 ? 'Excellent' : 
                           provider.avg_efficiency >= 60 ? 'Good' : 'Needs Improvement'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Trends Mode */}
      {viewMode === 'trends' && (
        <div className="p-6 space-y-6">
          <div className="h-80">
            <h3 className="text-sm font-medium text-gray-700 mb-4">Cost Trends Over Time</h3>
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="cost" fill="#3B82F6" name="Daily Cost" />
                <Line yAxisId="right" type="monotone" dataKey="avg_efficiency" stroke="#10B981" strokeWidth={2} name="Avg Efficiency %" />
                <Line yAxisId="right" type="monotone" dataKey="potential_savings" stroke="#F59E0B" strokeWidth={2} strokeDasharray="5 5" name="Potential Savings" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Efficiency Analysis */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Efficiency Analysis</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {efficiencyData.slice(0, 6).map((resource, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">{resource.resource_id}</span>
                    <span className="text-xs text-gray-500">{resource.provider}</span>
                  </div>
                  <div className="mb-2">
                    <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
                      <span>Efficiency Score</span>
                      <span>{resource.efficiency_score.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          resource.efficiency_score >= 80 ? 'bg-green-600' :
                          resource.efficiency_score >= 60 ? 'bg-yellow-600' : 'bg-red-600'
                        }`}
                        style={{ width: `${resource.efficiency_score}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-600">
                    <div>Monthly Cost: ${resource.cost_per_month.toFixed(2)}</div>
                    <div className="text-green-600">Potential Savings: ${resource.savings_opportunity.toFixed(2)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Optimization Mode */}
      {viewMode === 'optimization' && (
        <div className="p-6 space-y-6">
          {/* ML-Powered Insights */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-700">AI-Powered Cost Optimization Insights</h3>
              {isGeneratingInsights && (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              )}
            </div>
            
            <div className="space-y-4">
              {costInsights.map((insight, index) => (
                <div key={index} className={`border-l-4 p-4 rounded-r-lg ${
                  insight.priority === 'critical' ? 'border-red-500 bg-red-50' :
                  insight.priority === 'high' ? 'border-orange-500 bg-orange-50' :
                  insight.priority === 'medium' ? 'border-yellow-500 bg-yellow-50' :
                  'border-blue-500 bg-blue-50'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full mr-3 ${
                        insight.priority === 'critical' ? 'bg-red-100 text-red-800' :
                        insight.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                        insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {insight.priority.toUpperCase()}
                      </span>
                      <span className="text-sm font-medium text-gray-900">{insight.category.replace('_', ' ').toUpperCase()}</span>
                    </div>
                    <div className="text-sm font-bold text-green-600">
                      ${insight.potential_savings.toFixed(2)}
                    </div>
                  </div>
                  <p className="text-sm text-gray-700 mb-2">{insight.description}</p>
                  <p className="text-sm text-gray-600 italic">{insight.recommendation}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Cost Optimization Recommendations */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-4">Optimization Recommendations</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="text-sm font-medium text-green-800 mb-2">Right-Sizing Opportunity</h4>
                <p className="text-sm text-green-700 mb-3">
                  {efficiencyData.filter(r => r.efficiency_score < 60).length} resources are over-provisioned
                </p>
                <div className="text-xs text-green-600">
                  Potential monthly savings: ${efficiencyData
                    .filter(r => r.efficiency_score < 60)
                    .reduce((sum, r) => sum + r.savings_opportunity, 0)
                    .toFixed(2)}
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="text-sm font-medium text-blue-800 mb-2">Provider Migration</h4>
                <p className="text-sm text-blue-700 mb-3">
                  Consider consolidating with high-efficiency providers
                </p>
                <div className="text-xs text-blue-600">
                  Estimated savings: ${(costBreakdown.total_cost * 0.1).toFixed(2)}/month
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Predictions Mode */}
      {viewMode === 'predictions' && (
        <div className="p-6 space-y-6">
          <div className="text-center text-gray-500">
            <svg className="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <p>Advanced cost predictions and forecasting coming soon</p>
            <p className="text-sm">ML models will predict future costs based on usage patterns</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default CostAnalytics;