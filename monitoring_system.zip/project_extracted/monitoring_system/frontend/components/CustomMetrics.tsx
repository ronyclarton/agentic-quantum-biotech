/**
 * Custom Metrics Component
 * User-defined metrics collection and visualization
 */

import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import * as d3 from 'd3';

interface CustomMetricDefinition {
  id: string;
  metric_name: string;
  metric_type: 'counter' | 'gauge' | 'histogram' | 'summary';
  description: string;
  unit: string;
  tags_schema: Record<string, string>;
  collection_interval_seconds: number;
  is_active: boolean;
  created_at: string;
}

interface CustomMetricValue {
  id: string;
  metric_name: string;
  value: number;
  tags: Record<string, string>;
  timestamp: string;
  created_at: string;
}

const CustomMetrics: React.FC = () => {
  const [metricDefinitions, setMetricDefinitions] = useState<CustomMetricDefinition[]>([]);
  const [metricValues, setMetricValues] = useState<CustomMetricValue[]>([]);
  const [selectedMetric, setSelectedMetric] = useState<string>('');
  const [selectedTimeRange, setSelectedTimeRange] = useState('1h');
  const [viewMode, setViewMode] = useState<'overview' | 'definitions' | 'values' | 'create'>('overview');
  const [isCreatingMetric, setIsCreatingMetric] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchCustomMetrics();
  }, [selectedTimeRange, selectedMetric]);

  const fetchCustomMetrics = async () => {
    setIsLoading(true);
    try {
      const [definitionsRes, valuesRes] = await Promise.all([
        fetch('/api/custom-metrics/definitions'),
        fetch(`/api/custom-metrics/values?range=${selectedTimeRange}${selectedMetric ? `&metric=${selectedMetric}` : ''}`)
      ]);

      const definitionsData = await definitionsRes.json();
      const valuesData = await valuesRes.json();

      setMetricDefinitions(definitionsData.definitions || []);
      setMetricValues(valuesData.values || []);
    } catch (error) {
      console.error('Failed to fetch custom metrics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createCustomMetric = async (metricData: Omit<CustomMetricDefinition, 'id' | 'created_at'>) => {
    try {
      await fetch('/api/custom-metrics/definitions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(metricData)
      });
      
      fetchCustomMetrics();
      setIsCreatingMetric(false);
      setViewMode('overview');
    } catch (error) {
      console.error('Failed to create custom metric:', error);
    }
  };

  const collectMetricValue = async (metricName: string, value: number, tags: Record<string, string> = {}) => {
    try {
      await fetch('/api/custom-metrics/values', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ metric_name: metricName, value, tags })
      });
      
      fetchCustomMetrics();
    } catch (error) {
      console.error('Failed to collect metric value:', error);
    }
  };

  // Process metric values for visualization
  const processMetricData = () => {
    const groupedData: Record<string, CustomMetricValue[]> = {};
    
    metricValues.forEach(value => {
      if (!groupedData[value.metric_name]) {
        groupedData[value.metric_name] = [];
      }
      groupedData[value.metric_name].push(value);
    });

    // Process each metric type
    const processedData: Record<string, any[]> = {};
    
    Object.entries(groupedData).forEach(([metricName, values]) => {
      const sortedValues = values.sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
      
      processedData[metricName] = sortedValues.map(value => ({
        time: new Date(value.timestamp).toLocaleTimeString([], { 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        timestamp: value.timestamp,
        value: value.value,
        tags: value.tags
      }));
    });

    return processedData;
  };

  const metricData = processMetricData();
  const selectedMetricData = selectedMetric ? metricData[selectedMetric] || [] : [];

  // Calculate statistics
  const getMetricStatistics = (values: CustomMetricValue[]) => {
    if (values.length === 0) return { count: 0, avg: 0, min: 0, max: 0 };
    
    const numericValues = values.map(v => v.value);
    return {
      count: values.length,
      avg: numericValues.reduce((a, b) => a + b, 0) / numericValues.length,
      min: Math.min(...numericValues),
      max: Math.max(...numericValues)
    };
  };

  // Get active metric names
  const activeMetrics = metricDefinitions.filter(m => m.is_active);

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Custom Metrics</h2>
            <p className="text-sm text-gray-600">
              User-defined metrics collection and visualization
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <select
              value={selectedMetric}
              onChange={(e) => setSelectedMetric(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="">All Metrics</option>
              {activeMetrics.map(metric => (
                <option key={metric.id} value={metric.metric_name}>
                  {metric.metric_name}
                </option>
              ))}
            </select>

            <select
              value={selectedTimeRange}
              onChange={(e) => setSelectedTimeRange(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="15m">Last 15 minutes</option>
              <option value="1h">Last hour</option>
              <option value="6h">Last 6 hours</option>
              <option value="24h">Last 24 hours</option>
            </select>

            <div className="flex border border-gray-300 rounded-md">
              {(['overview', 'definitions', 'values', 'create'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => {
                    setViewMode(mode);
                    if (mode === 'create') setIsCreatingMetric(true);
                  }}
                  className={`px-3 py-1 text-sm capitalize ${
                    viewMode === mode 
                      ? 'bg-blue-500 text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  } ${mode !== 'overview' ? 'border-l border-gray-300' : ''}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Overview Mode */}
      {viewMode === 'overview' && (
        <div className="p-6 space-y-6">
          {/* Metric Definitions Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-blue-600">
                {metricDefinitions.length}
              </div>
              <div className="text-sm text-gray-600">Total Metrics</div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-green-600">
                {activeMetrics.length}
              </div>
              <div className="text-sm text-gray-600">Active Metrics</div>
            </div>
            <div className="bg-yellow-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-yellow-600">
                {metricValues.length}
              </div>
              <div className="text-sm text-gray-600">Data Points</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-600">
                {metricValues.filter(v => {
                  const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
                  return new Date(v.timestamp) > hourAgo;
                }).length}
              </div>
              <div className="text-sm text-gray-600">Last Hour</div>
            </div>
          </div>

          {/* Metric Selection and Visualization */}
          {activeMetrics.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-gray-700">Metric Visualization</h3>
                <select
                  value={selectedMetric}
                  onChange={(e) => setSelectedMetric(e.target.value)}
                  className="px-3 py-1 border border-gray-300 rounded-md text-sm"
                >
                  <option value="">Select a metric to visualize</option>
                  {activeMetrics.map(metric => (
                    <option key={metric.id} value={metric.metric_name}>
                      {metric.metric_name}
                    </option>
                  ))}
                </select>
              </div>

              {selectedMetric && selectedMetricData.length > 0 ? (
                <div className="space-y-4">
                  {/* Metric Statistics */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">{selectedMetric} Statistics</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {(() => {
                        const stats = getMetricStatistics(metricValues.filter(v => v.metric_name === selectedMetric));
                        return (
                          <>
                            <div className="text-center">
                              <div className="text-lg font-bold text-gray-900">{stats.count}</div>
                              <div className="text-xs text-gray-600">Data Points</div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-blue-600">{stats.avg.toFixed(2)}</div>
                              <div className="text-xs text-gray-600">Average</div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-green-600">{stats.min.toFixed(2)}</div>
                              <div className="text-xs text-gray-600">Minimum</div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-red-600">{stats.max.toFixed(2)}</div>
                              <div className="text-xs text-gray-600">Maximum</div>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  </div>

                  {/* Time Series Chart */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-3">Time Series</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={selectedMetricData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip 
                            labelFormatter={(label) => `Time: ${label}`}
                            formatter={(value, name) => [value, selectedMetric]}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke="#3B82F6" 
                            strokeWidth={2}
                            dot={false}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              ) : selectedMetric ? (
                <div className="text-center py-8 text-gray-500">
                  <svg className="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  <p>No data available for {selectedMetric}</p>
                  <p className="text-sm">Collect some data to see the visualization</p>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>Select a metric to visualize its data</p>
                </div>
              )}
            </div>
          )}

          {/* Recent Metric Values */}
          {metricValues.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Recent Values</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Metric</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tags</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {metricValues.slice(0, 10).map((value) => (
                      <tr key={value.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {value.metric_name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {value.value}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(value.timestamp).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {Object.keys(value.tags).length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {Object.entries(value.tags).map(([key, tagValue]) => (
                                <span key={key} className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                  {key}:{tagValue}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-gray-400">No tags</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Definitions Mode */}
      {viewMode === 'definitions' && (
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-sm font-medium text-gray-700">Metric Definitions</h3>
            <button
              onClick={() => setIsCreatingMetric(true)}
              className="px-3 py-1 bg-blue-600 text-white hover:bg-blue-700 rounded-md text-sm"
            >
              Create Definition
            </button>
          </div>

          <div className="space-y-4">
            {metricDefinitions.map((definition) => (
              <div key={definition.id} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <h4 className="text-sm font-medium text-gray-900">{definition.metric_name}</h4>
                    <span className={`ml-3 inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      definition.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {definition.is_active ? 'Active' : 'Inactive'}
                    </span>
                    <span className="ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                      {definition.metric_type}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">
                    Every {definition.collection_interval_seconds}s
                  </div>
                </div>
                
                <p className="text-sm text-gray-600 mb-2">{definition.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    Unit: {definition.unit}
                  </div>
                  <div className="text-xs text-gray-500">
                    Created: {new Date(definition.created_at).toLocaleDateString()}
                  </div>
                </div>

                {Object.keys(definition.tags_schema).length > 0 && (
                  <div className="mt-2">
                    <div className="text-xs text-gray-600 mb-1">Tags:</div>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(definition.tags_schema).map(([key, type]) => (
                        <span key={key} className="inline-flex px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded">
                          {key}:{type}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Create Definition Form */}
      {isCreatingMetric && (
        <CustomMetricForm
          onSubmit={createCustomMetric}
          onCancel={() => {
            setIsCreatingMetric(false);
            setViewMode('overview');
          }}
        />
      )}

      {/* Values Mode */}
      {viewMode === 'values' && (
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-700">Metric Values</h3>
            <button
              onClick={fetchCustomMetrics}
              className="px-3 py-1 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-md text-sm"
            >
              Refresh
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Metric Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tags</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {metricValues.map((value) => (
                  <tr key={value.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {value.metric_name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {value.value}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {metricDefinitions.find(d => d.metric_name === value.metric_name)?.unit || 'unknown'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(value.timestamp).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {Object.keys(value.tags).length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(value.tags).map(([key, tagValue]) => (
                            <span key={key} className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                              {key}:{tagValue}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400">No tags</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

// Custom Metric Form Component
interface CustomMetricFormProps {
  onSubmit: (metric: Omit<CustomMetricDefinition, 'id' | 'created_at'>) => void;
  onCancel: () => void;
}

const CustomMetricForm: React.FC<CustomMetricFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    metric_name: '',
    metric_type: 'gauge' as 'counter' | 'gauge' | 'histogram' | 'summary',
    description: '',
    unit: '',
    tags_schema: {} as Record<string, string>,
    collection_interval_seconds: 60,
    is_active: true
  });

  const [newTag, setNewTag] = useState({ key: '', type: 'string' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addTag = () => {
    if (newTag.key) {
      setFormData({
        ...formData,
        tags_schema: {
          ...formData.tags_schema,
          [newTag.key]: newTag.type
        }
      });
      setNewTag({ key: '', type: 'string' });
    }
  };

  const removeTag = (key: string) => {
    const { [key]: removed, ...rest } = formData.tags_schema;
    setFormData({
      ...formData,
      tags_schema: rest
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Create Custom Metric</h3>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Metric Name</label>
            <input
              type="text"
              required
              value={formData.metric_name}
              onChange={(e) => setFormData({ ...formData, metric_name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              placeholder="e.g., request_rate, cpu_temperature"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Metric Type</label>
            <select
              value={formData.metric_type}
              onChange={(e) => setFormData({ ...formData, metric_type: e.target.value as any })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="gauge">Gauge (single value)</option>
              <option value="counter">Counter (monotonically increasing)</option>
              <option value="histogram">Histogram (distribution)</option>
              <option value="summary">Summary (aggregated values)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              rows={3}
              placeholder="Describe what this metric measures"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
            <input
              type="text"
              value={formData.unit}
              onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              placeholder="e.g., requests/sec, degrees, MB"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Collection Interval (seconds)</label>
            <input
              type="number"
              min="1"
              value={formData.collection_interval_seconds}
              onChange={(e) => setFormData({ ...formData, collection_interval_seconds: parseInt(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            />
          </div>
          
          {/* Tags Section */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tags</label>
            <div className="space-y-2">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={newTag.key}
                  onChange={(e) => setNewTag({ ...newTag, key: e.target.value })}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm"
                  placeholder="Tag key"
                />
                <select
                  value={newTag.type}
                  onChange={(e) => setNewTag({ ...newTag, type: e.target.value })}
                  className="px-3 py-2 border border-gray-300 rounded-md text-sm"
                >
                  <option value="string">String</option>
                  <option value="number">Number</option>
                  <option value="boolean">Boolean</option>
                </select>
                <button
                  type="button"
                  onClick={addTag}
                  className="px-3 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
                >
                  Add
                </button>
              </div>
              
              {Object.entries(formData.tags_schema).map(([key, type]) => (
                <div key={key} className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded-md">
                  <span className="text-sm text-gray-700">{key}:{type}</span>
                  <button
                    type="button"
                    onClick={() => removeTag(key)}
                    className="text-red-600 hover:text-red-800 text-sm"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md text-sm hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
            >
              Create Metric
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CustomMetrics;