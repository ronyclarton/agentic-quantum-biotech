/**
 * Alert Panel Component
 * Real-time alerting and notification management
 */

import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Alert {
  id: string;
  rule_id?: string;
  rule_name?: string;
  metric_type: string;
  severity_level: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  recommendation?: string;
  detected_at: string;
  status: 'active' | 'investigating' | 'resolved' | 'false_positive';
  anomaly_score: number;
  metadata?: any;
}

interface AlertRule {
  id: string;
  rule_name: string;
  metric_type: string;
  condition_operator: string;
  threshold_value: number;
  threshold_value_high?: number;
  time_window_minutes: number;
  severity: string;
  notification_channels: string[];
  is_active: boolean;
  created_at: string;
}

interface Props {
  alerts: Alert[];
  onRefresh: () => void;
}

const AlertPanel: React.FC<Props> = ({ alerts, onRefresh }) => {
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'active' | 'history' | 'rules'>('active');
  const [alertRules, setAlertRules] = useState<AlertRule[]>([]);
  const [isCreatingRule, setIsCreatingRule] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    const severityMatch = selectedSeverity === 'all' || alert.severity_level === selectedSeverity;
    const statusMatch = selectedStatus === 'all' || alert.status === selectedStatus;
    return severityMatch && statusMatch;
  });

  // Calculate alert statistics
  const alertStats = {
    total: alerts.length,
    active: alerts.filter(a => a.status === 'active').length,
    critical: alerts.filter(a => a.severity_level === 'critical').length,
    high: alerts.filter(a => a.severity_level === 'high').length,
    medium: alerts.filter(a => a.severity_level === 'medium').length,
    low: alerts.filter(a => a.severity_level === 'low').length
  };

  // Load alert rules
  useEffect(() => {
    fetchAlertRules();
    
    // WebSocket for real-time alert updates
    const wsUrl = process.env.REACT_APP_WS_URL || 'ws://localhost:8080/alerts';
    wsRef.current = new WebSocket(wsUrl);
    
    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'new_alert') {
        onRefresh(); // Refresh alerts when new alert received
      }
    };

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [onRefresh]);

  const fetchAlertRules = async () => {
    try {
      const response = await fetch('/api/alerts/rules');
      const data = await response.json();
      setAlertRules(data.rules || []);
    } catch (error) {
      console.error('Failed to fetch alert rules:', error);
    }
  };

  const resolveAlert = async (alertId: string, action: 'resolve' | 'false_positive') => {
    try {
      await fetch(`/api/alerts/${alertId}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      onRefresh();
    } catch (error) {
      console.error('Failed to resolve alert:', error);
    }
  };

  const createAlertRule = async (ruleData: Partial<AlertRule>) => {
    try {
      await fetch('/api/alerts/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ruleData)
      });
      fetchAlertRules();
      setShowCreateForm(false);
    } catch (error) {
      console.error('Failed to create alert rule:', error);
    }
  };

  const testNotification = async (channel: string) => {
    try {
      await fetch('/api/alerts/test-notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channel })
      });
    } catch (error) {
      console.error('Failed to test notification:', error);
    }
  };

  // Calculate alert trend data for the last 24 hours
  const getAlertTrendData = () => {
    const hourlyCounts: Record<string, { critical: number; high: number; medium: number; low: number }> = {};
    
    alerts.forEach(alert => {
      const hour = new Date(alert.detected_at).toISOString().substring(0, 13) + ':00:00';
      if (!hourlyCounts[hour]) {
        hourlyCounts[hour] = { critical: 0, high: 0, medium: 0, low: 0 };
      }
      hourlyCounts[hour][alert.severity_level]++;
    });

    return Object.entries(hourlyCounts)
      .map(([time, counts]) => ({
        time: new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        critical: counts.critical,
        high: counts.high,
        medium: counts.medium,
        low: counts.low
      }))
      .sort((a, b) => a.time.localeCompare(b.time));
  };

  const alertTrendData = getAlertTrendData();

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-700 bg-red-100 border-red-300';
      case 'high': return 'text-orange-700 bg-orange-100 border-orange-300';
      case 'medium': return 'text-yellow-700 bg-yellow-100 border-yellow-300';
      case 'low': return 'text-blue-700 bg-blue-100 border-blue-300';
      default: return 'text-gray-700 bg-gray-100 border-gray-300';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-red-700 bg-red-100';
      case 'investigating': return 'text-yellow-700 bg-yellow-100';
      case 'resolved': return 'text-green-700 bg-green-100';
      case 'false_positive': return 'text-gray-700 bg-gray-100';
      default: return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Alert Management</h2>
            <p className="text-sm text-gray-600">
              Real-time alerting and notification system
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="investigating">Investigating</option>
              <option value="resolved">Resolved</option>
            </select>

            <div className="flex border border-gray-300 rounded-md">
              {(['active', 'history', 'rules'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-3 py-1 text-sm capitalize ${
                    viewMode === mode 
                      ? 'bg-blue-500 text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  } ${mode !== 'active' ? 'border-l border-gray-300' : ''}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Alert Statistics */}
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{alertStats.total}</div>
            <div className="text-xs text-gray-600">Total Alerts</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{alertStats.critical}</div>
            <div className="text-xs text-gray-600">Critical</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{alertStats.high}</div>
            <div className="text-xs text-gray-600">High</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{alertStats.medium}</div>
            <div className="text-xs text-gray-600">Medium</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{alertStats.low}</div>
            <div className="text-xs text-gray-600">Low</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{alertStats.active}</div>
            <div className="text-xs text-gray-600">Active</div>
          </div>
        </div>
      </div>

      {/* Active Alerts View */}
      {viewMode === 'active' && (
        <div className="p-6 space-y-6">
          {/* Alert Trend Chart */}
          {alertTrendData.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Alert Trends (Last 24h)</h3>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={alertTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="critical" stroke="#DC2626" strokeWidth={2} name="Critical" />
                    <Line type="monotone" dataKey="high" stroke="#EA580C" strokeWidth={2} name="High" />
                    <Line type="monotone" dataKey="medium" stroke="#D97706" strokeWidth={2} name="Medium" />
                    <Line type="monotone" dataKey="low" stroke="#2563EB" strokeWidth={2} name="Low" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Active Alerts List */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-700">Active Alerts</h3>
              <button
                onClick={onRefresh}
                className="px-3 py-1 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-md text-sm"
              >
                Refresh
              </button>
            </div>
            
            {filteredAlerts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <svg className="w-8 h-8 mx-auto mb-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p>No active alerts</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`border-l-4 p-4 rounded-r-lg ${getSeverityColor(alert.severity_level)}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full mr-3 ${getStatusColor(alert.status)}`}>
                            {alert.status.toUpperCase()}
                          </span>
                          <span className="text-sm font-medium">
                            {alert.rule_name || `${alert.metric_type} Alert`}
                          </span>
                        </div>
                        
                        <p className="text-sm mb-2">{alert.description}</p>
                        
                        <div className="flex items-center text-xs text-gray-600 space-x-4">
                          <span>Detected: {new Date(alert.detected_at).toLocaleString()}</span>
                          <span>Anomaly Score: {(alert.anomaly_score * 100).toFixed(1)}%</span>
                        </div>
                        
                        {alert.recommendation && (
                          <p className="text-sm italic mt-2">💡 {alert.recommendation}</p>
                        )}
                      </div>
                      
                      <div className="flex space-x-2 ml-4">
                        <button
                          onClick={() => resolveAlert(alert.id, 'resolve')}
                          className="px-3 py-1 bg-green-100 text-green-700 hover:bg-green-200 rounded text-sm"
                        >
                          Resolve
                        </button>
                        <button
                          onClick={() => resolveAlert(alert.id, 'false_positive')}
                          className="px-3 py-1 bg-gray-100 text-gray-700 hover:bg-gray-200 rounded text-sm"
                        >
                          False Positive
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Alert Rules Management */}
      {viewMode === 'rules' && (
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-gray-700">Alert Rules</h3>
            <button
              onClick={() => setShowCreateForm(true)}
              className="px-3 py-1 bg-blue-600 text-white hover:bg-blue-700 rounded-md text-sm"
            >
              Create Rule
            </button>
          </div>

          {/* Create Rule Form */}
          {showCreateForm && (
            <AlertRuleForm
              onSubmit={createAlertRule}
              onCancel={() => setShowCreateForm(false)}
            />
          )}

          {/* Rules List */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rule Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Metric Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Condition</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Severity</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Channels</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {alertRules.map((rule) => (
                  <tr key={rule.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {rule.rule_name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {rule.metric_type}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {rule.condition_operator} {rule.threshold_value}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        rule.severity === 'critical' ? 'bg-red-100 text-red-800' :
                        rule.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                        rule.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {rule.severity}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {rule.notification_channels.join(', ')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        rule.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {rule.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => testNotification(rule.notification_channels[0])}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Test
                        </button>
                        <button className="text-gray-600 hover:text-gray-800">
                          Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* History View Placeholder */}
      {viewMode === 'history' && (
        <div className="p-6">
          <div className="text-center py-8 text-gray-500">
            <svg className="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p>Alert history and analytics coming soon</p>
            <p className="text-sm">Detailed history of all resolved alerts</p>
          </div>
        </div>
      )}
    </div>
  );
};

// Alert Rule Creation Form Component
interface AlertRuleFormProps {
  onSubmit: (rule: Partial<AlertRule>) => void;
  onCancel: () => void;
}

const AlertRuleForm: React.FC<AlertRuleFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    rule_name: '',
    metric_type: '',
    condition_operator: '>',
    threshold_value: '',
    severity: 'medium',
    notification_channels: ['email'],
    time_window_minutes: 5
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      threshold_value: parseFloat(formData.threshold_value),
      is_active: true
    });
  };

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-6">
      <h4 className="text-sm font-medium text-gray-700 mb-4">Create New Alert Rule</h4>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Rule Name</label>
            <input
              type="text"
              required
              value={formData.rule_name}
              onChange={(e) => setFormData({ ...formData, rule_name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Metric Type</label>
            <select
              value={formData.metric_type}
              onChange={(e) => setFormData({ ...formData, metric_type: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="">Select metric</option>
              <option value="training_accuracy">Training Accuracy</option>
              <option value="training_loss">Training Loss</option>
              <option value="gpu_utilization">GPU Utilization</option>
              <option value="cpu_utilization">CPU Utilization</option>
              <option value="memory_usage">Memory Usage</option>
              <option value="temperature">Temperature</option>
            </select>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Condition</label>
            <select
              value={formData.condition_operator}
              onChange={(e) => setFormData({ ...formData, condition_operator: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value=">">Greater than</option>
              <option value="<">Less than</option>
              <option value=">=">Greater or equal</option>
              <option value="<=">Less or equal</option>
              <option value="=">Equal to</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Threshold</label>
            <input
              type="number"
              step="0.01"
              required
              value={formData.threshold_value}
              onChange={(e) => setFormData({ ...formData, threshold_value: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
            <select
              value={formData.severity}
              onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
            </select>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md text-sm hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
          >
            Create Rule
          </button>
        </div>
      </form>
    </div>
  );
};

export default AlertPanel;