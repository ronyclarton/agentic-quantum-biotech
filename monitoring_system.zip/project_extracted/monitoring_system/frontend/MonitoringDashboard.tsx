/**
 * Main Monitoring Dashboard Component
 * Real-time training metrics and infrastructure monitoring
 * React with TypeScript and D3.js
 */

import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import * as d3 from 'd3';
import TrainingMetrics from './components/TrainingMetrics';
import ResourceUtilization from './components/ResourceUtilization';
import CostAnalytics from './components/CostAnalytics';
import AlertPanel from './components/AlertPanel';
import PredictiveMaintenance from './components/PredictiveMaintenance';
import CustomMetrics from './components/CustomMetrics';

interface DashboardMetrics {
  trainingMetrics: any[];
  resourceMetrics: any[];
  costMetrics: any[];
  activeAlerts: any[];
  systemHealth: any;
}

const MonitoringDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    trainingMetrics: [],
    resourceMetrics: [],
    costMetrics: [],
    activeAlerts: [],
    systemHealth: null
  });
  
  const [selectedTimeRange, setSelectedTimeRange] = useState('1h');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const wsRef = useRef<WebSocket | null>(null);

  // WebSocket connection for real-time updates
  useEffect(() => {
    if (autoRefresh) {
      const wsUrl = process.env.REACT_APP_WS_URL || 'ws://localhost:8080/metrics';
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log('WebSocket connected');
      };

      wsRef.current.onmessage = (event) => {
        const data = JSON.parse(event.data);
        updateMetrics(data);
      };

      wsRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
      };

      return () => {
        if (wsRef.current) {
          wsRef.current.close();
        }
      };
    }
  }, [autoRefresh]);

  // Fallback polling for metrics
  useEffect(() => {
    if (!autoRefresh || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      fetchMetrics();
    }
  }, [autoRefresh, selectedTimeRange]);

  // Auto-refresh interval
  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(fetchMetrics, 5000); // 5 second refresh
      return () => clearInterval(interval);
    }
  }, [autoRefresh, selectedTimeRange]);

  const fetchMetrics = async () => {
    try {
      setIsLoading(true);
      
      const [trainingRes, resourceRes, costRes, alertsRes, healthRes] = await Promise.all([
        fetch(`/api/metrics/training?range=${selectedTimeRange}`),
        fetch(`/api/metrics/resource?range=${selectedTimeRange}`),
        fetch(`/api/metrics/cost?range=${selectedTimeRange}`),
        fetch('/api/alerts/active'),
        fetch('/api/health/system')
      ]);

      const [trainingData, resourceData, costData, alertsData, healthData] = await Promise.all([
        trainingRes.json(),
        resourceRes.json(),
        costRes.json(),
        alertsRes.json(),
        healthRes.json()
      ]);

      setMetrics({
        trainingMetrics: trainingData.data || [],
        resourceMetrics: resourceData.data || [],
        costMetrics: costData.data || [],
        activeAlerts: alertsData.active_alerts || [],
        systemHealth: healthData
      });
    } catch (error) {
      console.error('Failed to fetch metrics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateMetrics = (newData: any) => {
    setMetrics(prev => ({
      ...prev,
      trainingMetrics: newData.training_metrics || prev.trainingMetrics,
      resourceMetrics: newData.resource_metrics || prev.resourceMetrics,
      costMetrics: newData.cost_metrics || prev.costMetrics,
      activeAlerts: newData.active_alerts || prev.activeAlerts,
      systemHealth: newData.system_health || prev.systemHealth
    }));
  };

  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh);
  };

  const refreshNow = () => {
    fetchMetrics();
  };

  // Calculate dashboard summary statistics
  const getSummaryStats = () => {
    const activeTraining = metrics.trainingMetrics.length;
    const avgGPUUtil = metrics.resourceMetrics
      .filter(m => m.host_type === 'gpu')
      .reduce((sum, m) => sum + (m.utilization_percentage || 0), 0) / 
      metrics.resourceMetrics.filter(m => m.host_type === 'gpu').length || 0;
    
    const totalCost = metrics.costMetrics
      .reduce((sum, m) => sum + (m.total_cost || 0), 0);
    
    const criticalAlerts = metrics.activeAlerts
      .filter(a => a.severity_level === 'critical').length;

    return {
      activeTraining,
      avgGPUUtil: avgGPUUtil.toFixed(1),
      totalCost: totalCost.toFixed(2),
      criticalAlerts,
      healthyNodes: metrics.systemHealth?.healthy_nodes || 0
    };
  };

  const stats = getSummaryStats();

  if (isLoading && metrics.trainingMetrics.length === 0) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading monitoring dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">AI Training Monitoring Dashboard</h1>
              <div className="ml-4 flex items-center">
                <div className={`h-3 w-3 rounded-full ${autoRefresh ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className="ml-2 text-sm text-gray-600">
                  {autoRefresh ? 'Live' : 'Paused'}
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Time Range Selector */}
              <select
                value={selectedTimeRange}
                onChange={(e) => setSelectedTimeRange(e.target.value)}
                className="px-3 py-1 border border-gray-300 rounded-md text-sm"
              >
                <option value="15m">Last 15 minutes</option>
                <option value="1h">Last hour</option>
                <option value="6h">Last 6 hours</option>
                <option value="24h">Last 24 hours</option>
                <option value="7d">Last 7 days</option>
              </select>
              
              {/* Control Buttons */}
              <button
                onClick={toggleAutoRefresh}
                className={`px-3 py-1 rounded-md text-sm ${
                  autoRefresh 
                    ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {autoRefresh ? 'Pause' : 'Resume'}
              </button>
              
              <button
                onClick={refreshNow}
                className="px-3 py-1 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-md text-sm"
              >
                Refresh
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Summary Statistics */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Training</p>
                <p className="text-2xl font-bold text-gray-900">{stats.activeTraining}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">GPU Utilization</p>
                <p className="text-2xl font-bold text-gray-900">{stats.avgGPUUtil}%</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Cost</p>
                <p className="text-2xl font-bold text-gray-900">${stats.totalCost}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-red-100 rounded-lg">
                <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Critical Alerts</p>
                <p className="text-2xl font-bold text-gray-900">{stats.criticalAlerts}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="p-2 bg-indigo-100 rounded-lg">
                <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                </svg>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Healthy Nodes</p>
                <p className="text-2xl font-bold text-gray-900">{stats.healthyNodes}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Training Metrics and Alerts */}
          <div className="lg:col-span-2 space-y-6">
            <TrainingMetrics 
              metrics={metrics.trainingMetrics} 
              timeRange={selectedTimeRange}
            />
            
            <ResourceUtilization 
              metrics={metrics.resourceMetrics}
              timeRange={selectedTimeRange}
            />
            
            <CostAnalytics 
              metrics={metrics.costMetrics}
              timeRange={selectedTimeRange}
            />
          </div>

          {/* Right Column - Alerts and Maintenance */}
          <div className="space-y-6">
            <AlertPanel 
              alerts={metrics.activeAlerts}
              onRefresh={fetchMetrics}
            />
            
            <PredictiveMaintenance />
            
            <CustomMetrics />
          </div>
        </div>

        {/* Real-time Status Indicator */}
        {autoRefresh && (
          <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center">
            <div className="animate-pulse h-2 w-2 bg-white rounded-full mr-2"></div>
            <span className="text-sm">Live monitoring active</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default MonitoringDashboard;