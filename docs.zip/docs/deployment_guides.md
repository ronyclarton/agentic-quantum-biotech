# Agentic Utopic AI Platform — Comprehensive Deployment Guides

## Executive Summary and How to Use This Guide

This guide enables platform engineers, machine learning operations (MLOps) practitioners, site reliability engineers (SRE), DevOps teams, and quantum/HPC researchers to deploy the Agentic Utopic AI Platform across four environments: local Docker Compose, Amazon SageMaker, Amazon Elastic Kubernetes Service (EKS), and selected academic/research environments for cloud rotation. The narrative proceeds from local development to managed endpoints (SageMaker), to orchestrated infrastructure (Kubernetes/EKS), and finally to distributed research backends (Google Colab, Kaggle, IBM Quantum, and NSF ACCESS resources). Each section is designed to be independently actionable while maintaining consistent patterns for security, GPU enablement, monitoring, and environment configuration.

Outcomes you should expect:
- A working local development stack with GPU-capable containers, Ray workers, MongoDB/Redis, and monitoring via Prometheus and Grafana.
- A repeatable SageMaker deployment, from preparing Docker artifacts to invoking a real-time inference endpoint, following Amazon’s best practices.
- An EKS cluster configured for GPU workloads with the NVIDIA GPU Operator and practical autoscaling patterns, including optional scheduling optimizations with NVIDIA Run:ai.
- A safe and compliant multi-cloud rotation setup across Google Colab, Kaggle, IBM Quantum, and NSF ACCESS, including environment variables, authentication, and workload migration.
- A consolidated environment configuration strategy across all deployment contexts, including secrets handling and API key rotation.

Use this guide linearly if you are new to the platform, or jump to the environment of interest if you are already familiar with the stack. Cross-references appear at the end of each major section to reinforce patterns and reduce duplication.

Information gaps to acknowledge:
- Several deployment scripts referenced by the project (e.g., sagemaker_deployer.py, eks_config.py, cloud_rotation.py) are not included; this guide provides implementation plans and patterns that are immediately actionable using the project’s Docker image and Compose services.
- An EKS cluster template (Kubernetes manifests or Helm charts) is not provided; the guide includes representative Kubernetes objects for the Agentic Utopic AI Platform deployment based on community patterns and documentation.
- The vLLM inference server is referenced as an example; exact container image tags should be pinned to tested versions during implementation.
- ACCESS allocations vary by institution and time; consult your local support for precise queue policies and module ecosystems.
- The NVIDIA GPU Operator page could not be retrieved; alternate NVIDIA EKS references are provided.
- External verification of some environment variables’ semantics (e.g., NIM_*, EMBEDDING_*) is not available; treat names and usage as project-specific defaults.

### Prerequisites and Assumptions

This guide assumes familiarity with Docker, Python, AWS CLI, kubectl, and basic Kubernetes concepts (Deployments, Services, Pods). It also assumes the ability to provision cloud resources (SageMaker execution role, S3 buckets, EKS clusters) and HPC/quantum accounts where applicable. The platform’s GPU path requires NVIDIA runtime support in Docker or Kubernetes node pools.

To reduce friction, confirm the following:
- For local GPU runs, ensure NVIDIA Container Toolkit is installed and verified for Docker, and that your host machine has compatible CUDA drivers for the image used (e.g., CUDA 11.8 base) [^3][^4].
- For EKS GPU nodes, prefer EKS-optimized AMIs or Bottlerocket AMIs with NVIDIA drivers and the NVIDIA Container Toolkit already configured. Use node taints and labels to control GPU workload scheduling [^2][^22][^23].
- Ensure you have AWS credentials configured via standard profiles or environment variables, with permissions for SageMaker, EKS, and S3 operations [^20].

---

## Local Development Setup Guide (Docker Compose)

The local development environment is defined in the project’s Compose file and Dockerfile. It includes:
- Main platform service (FastAPI) with GPU reservation
- Redis and MongoDB for caching and persistence
- Ray head and worker for distributed/federated learning
- Jupyter Lab for interactive development
- Prometheus and Grafana for monitoring
- Optional local Weights & Biases (wandb/local)

You can start with a single-node GPU or run CPU-only if a GPU is unavailable. The Compose file mounts data, logs, and config directories and mounts your local AWS credentials into the platform container, enabling SageMaker and S3 interactions from the development environment.

To illustrate the service architecture and ports, the following table summarizes the composition.

### Table 1. Local services overview: ports, purpose, dependencies

| Service               | Ports                       | Purpose                                      | Dependencies         |
|-----------------------|-----------------------------|----------------------------------------------|----------------------|
| utopic-platform       | 8080 (API), 8081 (Web), 8082 (Monitoring) | FastAPI app, main platform                    | Redis, MongoDB       |
| redis                 | 6379                        | Caching and session storage                   | None                 |
| mongodb               | 27017                       | Data persistence                              | None                 |
| ray-head              | 8265 (Dashboard), 10001     | Ray cluster head node                         | utopic-platform      |
| ray-worker-1          | —                           | Ray worker node (GPU-capable via reservation) | ray-head             |
| jupyter               | 8888                        | Jupyter Lab                                   | None                 |
| prometheus            | 9090                        | Metrics collection                            | None                 |
| grafana               | 3000                        | Visualization and dashboards                  | None                 |
| wandb-local (optional)| 8083                        | Local experiment tracking                     | None                 |

The GPU-enabled services rely on the Compose device reservation for the NVIDIA runtime. If you encounter issues using GPUs inside containers, consult the community guidance on enabling GPU access for Docker and troubleshooting common symptoms (e.g., device not found errors, driver mismatch) [^3][^4].

### Step-by-Step: Local Setup

1. Create environment file
   - Copy the project’s environment template to `.env` and adjust values. In development, you can keep defaults for MongoDB, Redis, and Ray, but set `ENVIRONMENT=development` and `LOG_LEVEL=INFO`.

2. Build and start the stack
   - Build the main image: `docker compose build utopic-platform jupyter`
   - Start selected services: `docker compose up -d redis mongodb prometheus grafana`
   - Launch platform components: `docker compose up -d utopic-platform ray-head ray-worker-1 jupyter`

3. Access services
   - FastAPI: http://localhost:8080 (API)
   - Web UI: http://localhost:8081
   - Monitoring: http://localhost:8082 (platform-specific endpoint)
   - Prometheus: http://localhost:9090
   - Grafana: http://localhost:3000 (login with admin; change default password in production)
   - Jupyter Lab: http://localhost:8888 (token configured via environment)

4. Verify health
   - The main image includes a healthcheck targeting `/health`. Confirm containers report “healthy” in `docker compose ps`.
   - If using GPUs, ensure the GPU-capable services show a reserved device and that `nvidia-smi` is accessible inside the container.

To consolidate port mappings for quick reference, see Table 2.

### Table 2. Port mapping summary for local services

| Service          | Host Port | Container Port | Notes                             |
|------------------|-----------|----------------|-----------------------------------|
| utopic-platform  | 8080      | 8080           | API traffic                       |
| utopic-platform  | 8081      | 8081           | Web UI                            |
| utopic-platform  | 8082      | 8082           | Monitoring endpoint               |
| ray-head         | 8265      | 8265           | Ray dashboard                     |
| ray-head         | 10001     | 10001          | Ray head port                     |
| jupyter          | 8888      | 8888           | Jupyter Lab                       |
| redis            | 6379      | 6379           | Redis                             |
| mongodb          | 27017     | 27017          | MongoDB                           |
| prometheus       | 9090      | 9090           | Metrics                           |
| grafana          | 3000      | 3000           | Dashboards                        |
| wandb-local      | 8083      | 8080           | Local W&B server                  |

In development, mount your local AWS credentials to the platform container to allow access to AWS services (e.g., `~/.aws:/root/.aws`). For GPU acceleration, ensure Docker Desktop (or your runtime) is configured to access the NVIDIA driver and devices. Container startup times can be significant for large images and models; consider caching and pre-pulling images to improve iteration speed [^9].

### GPU Enablement for Local Docker

The Docker Compose file reserves one GPU for the platform service and for Ray workers. Validate device visibility inside the container by running `nvidia-smi` and checking that CUDA devices are exposed. If you see errors such as “nvidia: command not found” or “no CUDA-capable device is detected,” verify:
- NVIDIA Container Toolkit is installed and the Docker daemon is restarted [^3][^4].
- Host driver version matches the container’s CUDA expectations (e.g., CUDA 11.8 runtime base image).
- You have not overridden GPU reservation with `runtime: none` or disabled Compose resource reservations.

The platform image uses a multi-stage Dockerfile based on `nvidia/cuda:11.8` runtime to balance build efficiency and runtime footprint. This ensures consistency between build-time and run-time CUDA dependencies.

### Monitoring and Observability (Prometheus/Grafana)

Prometheus is configured via a mounted `prometheus.yml` and Grafana with provisioning files under `config/grafana`. Start Prometheus and Grafana after the platform and Ray services to ensure scrape targets are available. Then:
- Configure Grafana data sources pointing to Prometheus.
- Import or create dashboards for platform health (uptime, error rates), Ray workers (tasks, memory, object store), and GPU utilization.

If scraping does not begin, confirm file mounts and Prometheus command flags. In constrained environments, containers may take longer to start and report readiness; consider lengthening healthcheck intervals for large images [^9].

---

## AWS SageMaker Deployment Guide

This section describes how to prepare the project’s Docker image for SageMaker, create a model, and deploy a real-time inference endpoint. We align the steps with Amazon’s official guidance on real-time inference and best practices for security, availability, and cost [^5][^6].

SageMaker deployment overview:
1. Build and tag the platform Docker image for use as a SageMaker inference container.
2. Push the image to Amazon Elastic Container Registry (ECR).
3. Create a SageMaker model referencing the ECR image and define an endpoint configuration.
4. Deploy a real-time endpoint and validate inference requests.

### Prerequisites

- AWS CLI configured with an appropriate profile or environment variables [^20].
- An IAM execution role for SageMaker with permissions to access ECR and S3 (if data or model artifacts are in S3).
- An ECR repository for the platform image; the repository region should match your intended SageMaker endpoint region.

Ensure your Docker image includes the FastAPI server and the platform’s health endpoint, which SageMaker can use for liveness checks where applicable.

### Table 3. AWS resources checklist for SageMaker

| Resource                     | Purpose                                      | Notes                                   |
|-----------------------------|----------------------------------------------|-----------------------------------------|
| IAM Role (SageMakerExecutionRole) | SageMaker access to ECR and S3               | Least privilege; grant only required actions |
| ECR Repository              | Host the platform inference image             | Push image with proper tags             |
| S3 Bucket (optional)        | Store model artifacts and data               | Versioning recommended                  |
| Endpoint Configuration      | Defines instance type, scaling, variant name | Production variants for traffic control |
| Model Name / Endpoint Name  | Logical identifiers for model and endpoint    | Use environment-driven naming           |

### Build and Push the Inference Container

1. Build the Docker image using the project’s Dockerfile:
   - Example: `docker build -t utopic-platform:1.0.0 .`
   - Ensure the image exposes the intended port (e.g., 8080) for SageMaker to connect to the health and inference paths.

2. Tag for ECR:
   - Retrieve the ECR login command and tag the image:
     - `aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <account>.dkr.ecr.<region>.amazonaws.com`
     - `docker tag utopic-platform:1.0.0 <account>.dkr.ecr.<region>.amazonaws.com/utopic-platform:1.0.0`

3. Push the image:
   - `docker push <account>.dkr.ecr.<region>.amazonaws.com/utopic-platform:1.0.0`

This preparation enables SageMaker to pull the exact container image for deployment [^7][^8].

### Table 4. ECR push steps and common errors

| Step                                 | Purpose                         | Common Error                       | Remedy                                   |
|--------------------------------------|---------------------------------|------------------------------------|------------------------------------------|
| docker build                         | Build inference image           | CUDA driver mismatch               | Align host drivers with container CUDA   |
| docker tag                           | Tag for ECR                     | Repository not found               | Create ECR repository or check region    |
| docker login + docker push           | Authenticate and push           | Access denied                      | Verify IAM permissions and ECR policy    |

### Create Model and Endpoint

1. Create the SageMaker model:
   - Provide the ECR image URI and any optional model data S3 location in the `CreateModel` request.

2. Create endpoint configuration:
   - Select an appropriate instance type (e.g., GPU or CPU) based on your model’s performance needs.
   - Define production variants if you need gradual rollouts or A/B testing.

3. Deploy the endpoint:
   - Create an endpoint from the configuration and wait for it to reach “InService” state.

4. Validate:
   - Invoke the endpoint with a sample payload. Check CloudWatch metrics for latency and error rates [^6].

### Best Practices and Operational Guidance

- Security and endpoint hygiene: Use private VPC endpoints where appropriate, enforce TLS, and limit who can update endpoint configurations [^5].
- Cost optimization: Choose instance types based on real profiling; avoid overprovisioning GPU endpoints when batch inference can run on CPU or smaller GPUs [^5].
- Migrations and hardware considerations: Evaluate Graviton-based instances for cost/performance improvements where your container and model are compatible [^5].
- Driver upgrades: Minimize interruptions when updating inference containers that depend on NVIDIA runtimes; apply blue/green deployments and plan for driver upgrades outside peak traffic windows [^5].
- Continuous improvement: Incorporate monitoring and feedback loops (CloudWatch, logs, metrics) to iterate model performance and endpoint efficiency [^5].

---

## EKS (Kubernetes) Deployment Guide

This section covers GPU enablement, workload scheduling, and autoscaling patterns on Amazon EKS. We highlight three pillars:
1. GPU enablement using the NVIDIA GPU Operator with EKS-optimized AMIs [^1].
2. Efficient autoscaling and GPU failure handling via EKS Auto Mode and Karpenter [^2][^11][^12].
3. Optional GPU scheduling and pooling optimizations using NVIDIA Run:ai [^10].

Kubernetes introduces different failure modes than single-node Docker Compose. Expect container image downloads and model weight loads to dominate cold starts; pre-pull images and cache model artifacts when possible to reduce latency [^9].

### Prerequisites

- AWS CLI configured [^20].
- kubectl installed and configured for your cluster [^21].
- eksctl installed for cluster and nodegroup management [^26].
- Node groups configured for GPU instance families; prefer EKS-optimized AMIs or Bottlerocket AMIs that include NVIDIA drivers [^22][^23].
- Helm (for GPU Operator and optional Run:ai installation).

### Table 5. EKS resources checklist

| Resource                        | Purpose                               | Notes                                         |
|---------------------------------|---------------------------------------|-----------------------------------------------|
| EKS Cluster                     | Control plane                         | Ensure version supports Auto Mode             |
| Node Pool / NodeGroup (GPU)     | Compute with NVIDIA GPUs              | EKS-optimized AMIs or Bottlerocket with drivers |
| IAM OIDC Provider               | Enable IRSA for pods                  | Required for workload identity                |
| Karpenter NodePool (optional)   | Autoscaling GPU nodes                 | Specify GPU instance types and taints [^12]   |
| NVIDIA GPU Operator             | Manage drivers and runtime            | Deploy via Helm; aligns drivers with runtime  |
| DCGM-Exporter (optional)        | GPU telemetry                         | Integrates with EKS node monitoring [^14]     |
| ServiceMonitor / Prometheus     | Scrape GPU metrics                    | Optional for centralized monitoring           |
| Storage for model artifacts     | Fast local reads                      | Consider filesystem or S3 mounting            |

### GPU Enablement via NVIDIA GPU Operator

Install the NVIDIA GPU Operator via Helm on an EKS cluster with a GPU node pool. The Operator manages driver installation and upgrades, the NVIDIA Container Toolkit, and device plugin components. With EKS-optimized AMIs or Bottlerocket, you reduce driver mismatch risks and simplify node images [^1][^22][^23].

Representative installation:
1. Add the NVIDIA Helm repository and install the GPU Operator with configuration appropriate for your driver version.
2. Verify the device plugin DaemonSet is running and that nodes report GPU capacity.
3. Ensure workloads request `nvidia.com/gpu` and that node taints/labels are considered by your scheduler.

### Table 6. GPU Operator components and responsibilities

| Component          | Responsibility                                  | Notes                                   |
|--------------------|--------------------------------------------------|-----------------------------------------|
| Driver Management  | Install/upgrade NVIDIA drivers                   | Align with host AMI                     |
| Container Toolkit  | Docker runtime integration for GPUs              | Required for GPU visibility in containers |
| Device Plugin      | Advertise GPUs to kubelet                        | Reports capacity and allocation         |
| DCGM-Exporter      | GPU telemetry and metrics                        | Optional for observability              |
| Operator Controller| Manage lifecycle of GPU stack                    | Helm-managed deployment                 |

If the GPU Operator page is temporarily unavailable, rely on the EKS guidance and community patterns, and validate device visibility in pods before deploying production workloads [^1][^15].

### Autoscaling and Scheduling

EKS Auto Mode automates node provisioning, security patching, and GPU failure handling (Node Monitoring Agent and Node Auto Repair). Karpenter works under the hood to scale node pools based on pod requirements. Use taints to ensure GPU workloads only land on GPU nodes, and labels to guide scheduling [^2][^11][^12].

Representative Karpenter NodePool snippet (condensed for clarity):

```yaml
apiVersion: karpenter.sh/v1
kind: NodePool
metadata:
  name: gpu-nodepool
spec:
  template:
    spec:
      taints:
        - key: nvidia.com/gpu
          value: "true"
          effect: NoSchedule
      nodeClassRef:
        group: karpenter.k8s.aws
        kind: EC2NodeClass
        name: gpu-nodeclass
  limits:
    cpu: "100"
    memory: 100Gi
```

- Karpenter will select GPU instance types when workloads request GPUs, respecting taints and limits [^12].
- EKS Auto Mode provides built-in node monitoring and auto repair to handle GPU failures with minimal downtime, adhering to Pod Disruption Budgets [^2].

### Table 7. Karpenter NodePool and instance selection

| Field                 | Purpose                                | Example                              |
|-----------------------|----------------------------------------|--------------------------------------|
| taints                | Restrict GPU nodes to GPU workloads    | nvidia.com/gpu, NoSchedule           |
| limits                | Resource bounds for autoscaling        | CPU and memory caps                  |
| instance types        | GPU families (G5/G6e)                  | g6e.xlarge, g5.2xlarge               |
| capacity type         | On-demand vs spot                      | spot for cost optimization           |

### Observability and Performance

- DCGM-Exporter can expose GPU metrics for Prometheus, enabling GPU utilization dashboards and alerting [^14].
- Monitor node health and auto-repair events; inspect logs to differentiate between transient and systemic failures [^2].
- Cold start mitigation: Pre-pull large images (e.g., model servers) and cache model weights on fast storage to reduce pod startup time [^9].
- For additional blueprints and best practices, consult the AI on EKS reference patterns [^15].

---

## Multi-Cloud Rotation Setup (Google Colab, Kaggle, IBM Quantum, NSF ACCESS)

Cloud rotation broadens access to heterogeneous compute backends. The approach should prioritize authentication isolation, environment parity, and fair-use compliance. The following platform features facilitate rotation:
- Feature flags for enabling/disabling backends
- Environment variables for API keys and resource limits
- Rate limiting for API calls
- Backup and recovery configuration for artifacts

Each research environment is integrated for specific strengths:
- Google Colab for quick GPU-enabled notebook experimentation
- Kaggle for dataset-centric workflows and community-driven competitions
- IBM Quantum backends and Qiskit Serverless for quantum experiments and workflows
- NSF ACCESS resources for HPC/HTC batch scheduling and Pegasus workflows

### Table 8. Per-platform rotation matrix

| Platform         | Primary Use-case                    | Authentication                     | Supported Features/Notes                          |
|------------------|-------------------------------------|------------------------------------|---------------------------------------------------|
| Google Colab     | Notebook-based experiments           | Google account                     | Install Qiskit via `%pip`; GPU availability varies [^24] |
| Kaggle           | Datasets, competitions, kernels      | Kaggle API credentials             | Submit kernels; adhere to API limits              |
| IBM Quantum      | QPU access via Qiskit, serverless    | IBM Cloud account; Qiskit Runtime  | Instance management; serverless programs [^17][^18] |
| NSF ACCESS       | HPC/HTC batch, Pegasus workflows     | ACCESS allocation + institution    | Open OnDemand portal; queue policies vary [^19][^25] |

### Google Colab

Set up an account, create a notebook, and install dependencies inline. For quantum experiments, install Qiskit and Qiskit Runtime using the `%pip` magic. Persist notebooks to your cloud drive and store results in appropriate locations. Use feature flags to enable/disable Colab-backed workflows during rotation [^24][^17].

### Kaggle

Configure API credentials and confirm dataset access. Plan jobs within daily API limits to avoid throttling. Kaggle’s strengths include dataset curation and reproducible kernels; export intermediate artifacts to S3 or your storage backend for downstream processing.

### IBM Quantum

Create and manage instances and access control using the IBM Quantum Platform. Programs can be executed on real quantum processing units (QPUs) or via Qiskit Serverless. Use logging and cost management features as needed. Treat backend selection as part of your rotation strategy, with fallbacks to simulators when QPU queues are congested [^17][^18].

### NSF ACCESS

Request allocations via the ACCESS portal. For interactive work, use Open OnDemand, and for batch workloads, use the local schedulers and Pegasus for workflow management. Environment modules differ by resource; consult your allocation documentation and local support for available software and queue policies [^19][^25].

---

## Environment Configuration Guide

A consistent environment configuration strategy reduces drift across local, SageMaker, EKS, and research platforms. The project’s environment template provides defaults for:
- Core settings (environment, project name, version)
- API keys (NVIDIA NIM, OpenAI, Weights & Biases)
- AWS (credentials, region, SageMaker names, S3)
- Databases (MongoDB URI, Redis URL)
- Quantum APIs (IBM Quantum tokens and organization)
- FastAPI and CORS configuration
- Security (JWT, encryption, hashing salts)
- Monitoring and logging
- Model configuration (NIM, embeddings, quantum backends)
- Ray configuration
- Feature flags and rate limiting
- Backup and recovery

You should tailor names (e.g., endpoint, bucket, role) per environment and load secrets from secure stores (AWS Secrets Manager, environment-specific vaults) rather than committing secrets to source control.

### Table 9. Variable categories and typical sources

| Category          | Variables (examples)                                                                 | Typical Sources                         |
|-------------------|---------------------------------------------------------------------------------------|-----------------------------------------|
| Core              | ENVIRONMENT, LOG_LEVEL, PROJECT_NAME, VERSION                                         | `.env` for local; SSM/Secrets for cloud |
| API Keys          | NVIDIA_NIM_API_KEY, OPENAI_API_KEY, WANDB_API_KEY                                     | Secret stores; rotate regularly         |
| AWS               | AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_DEFAULT_REGION, SAGEMAKER_*             | AWS profiles; Secrets Manager           |
| S3                | S3_BUCKET_NAME, S3_BUCKET_REGION                                                      | AWS S3 console                          |
| Databases         | MONGODB_URI, MONGODB_DB_NAME, REDIS_URL                                               | `.env` (local), Kubernetes Secrets      |
| Quantum           | IBM_QUANTUM_API_TOKEN, IBM_QUANTUM_HUB/GROUP/PROJECT                                  | IBM Cloud; secrets manager              |
| FastAPI           | API_HOST, API_PORT, API_WORKERS, API_TIMEOUT, CORS settings                           | `.env` or Kubernetes ConfigMaps         |
| Security          | JWT_SECRET_KEY, ENCRYPTION_KEY, HASH_SALT                                             | Secrets manager                         |
| Monitoring        | PROMETHEUS_PORT, GRAFANA_PORT, GRAFANA_ADMIN_PASSWORD                                 | `.env` or Kubernetes Secrets            |
| Model             | NIM_MODEL_*, EMBEDDING_MODEL_*, QUANTUM_BACKEND                                       | Project defaults                        |
| Ray               | RAY_ADDRESS, RAY_NUM_CPUS/GPU, RAY_MEMORY                                             | `.env` for local; K8s EnvVars           |
| Feature Flags     | ENABLE_* (RAY, QUANTUM, FEDERATED, GPU, CLOUD ROTATION, etc.)                         | `.env` or config maps                   |
| Rotation Limits   | COLAB/KAGGLE/IBM_QUANTUM_* limits                                                     | `.env` for local; centralized config    |
| Backup            | BACKUP_ENABLED, BACKUP_INTERVAL_HOURS, BACKUP_S3_BUCKET                               | Environment-specific configuration      |

SageMaker and EKS deployments should load sensitive values via AWS SSM Parameter Store or Secrets Manager. On Kubernetes, use Secrets for credentials and ConfigMaps for non-sensitive tunables. Reserve `.env` for local development.

---

## Troubleshooting Common Deployment Issues

Complex stacks fail in predictable ways. Use the table below to diagnose quickly and apply fixes grounded in best-practice references.

### Table 10. Symptom → Cause → Resolution → Reference

| Symptom                                                   | Probable Cause                                   | Resolution                                                                                 | Reference |
|-----------------------------------------------------------|---------------------------------------------------|--------------------------------------------------------------------------------------------|-----------|
| Docker containers cannot see GPU devices                  | NVIDIA Container Toolkit not installed or misconfigured | Install NVIDIA runtime; verify `nvidia-smi` in container; check driver/CUDA alignment        | [^3][^4] |
| EKS pods stuck in Pending                                 | Node lacks GPU capacity or tainted incorrectly    | Verify GPU node pool; add taints/labels; ensure GPU Operator installed and device plugin running | [^1][^2] |
| Slow pod cold starts                                      | Large image sizes and model loading               | Pre-pull images; cache weights on fast storage; optimize readiness/liveness probes         | [^9]     |
| GPU utilization low or unstable                           | Poor scheduling or over-provisioning              | Consider Run:ai for pooling/fractional GPUs; adjust NodePool limits and instance selection | [^10][^12] |
| Endpoint deployment fails due to image pull errors        | ECR permissions or region mismatch                | Check IAM policies; ensure repository exists; verify image tag/URI                         | [^8][^7] |
| SageMaker endpoint health issues                          | Container liveness/inference mismatch             | Validate health endpoint; match SageMaker expectations; follow best practices              | [^6][^5] |
| Quantum jobs fail authentication                          | IBM Quantum credentials or instance misconfigured | Re-initialize Qiskit Runtime; verify access groups and instance allocations                 | [^17][^18] |
| ACCESS job submission rejected                            | Queue policies or module environment mismatch     | Consult local docs; validate allocation; load appropriate modules                          | [^19][^25] |
| GPU driver upgrade interrupts endpoints                   | In-place updates during traffic windows           | Use blue/green deployments; schedule upgrades off-peak                                     | [^5]     |
| DCGM metrics missing                                      | Exporter not deployed or scraping misconfigured   | Deploy DCGM-Exporter; configure Prometheus ServiceMonitor                                  | [^14]    |

### Local Docker: GPU Not Detected

If `nvidia-smi` is unavailable inside containers, reinstall the NVIDIA Container Toolkit and confirm that your Docker daemon is configured to use it. Check host driver versions and ensure they align with the container’s CUDA runtime. If problems persist, inspect system logs and re-validate device reservation in Compose [^3][^4].

### EKS: Pods Pending / GPU Not Available

Confirm that your node pools include GPU instances (e.g., G5/G6e) and are tainted appropriately. Validate that the NVIDIA GPU Operator is deployed and functioning, and that the device plugin advertises GPU capacity. If autoscaling is enabled via Karpenter or Auto Mode, ensure NodePool limits are not too restrictive [^1][^2].

### EKS: Slow Cold Starts

Large container images and model weights dominate startup times. Pre-pull images, store weights on faster storage, and use readiness probes tuned for your workloads. Expect several minutes for image download/unpacking and GPU memory load, especially for large models [^9].

### SageMaker: Endpoint Health and Image Pull Errors

Validate that your endpoint health checks match container behavior and that images are tagged and pushed correctly. Confirm ECR permissions and region alignment. Review best practices for endpoint updates, security, and cost optimization to avoid recurring failures [^6][^5].

### IBM Quantum: Access and Instance Management

Re-initialize your Qiskit Runtime account and verify instance allocation and access policies. If you are using serverless programs, confirm logging and resource management options. Treat queue congestion and QPU availability as design constraints and plan fallbacks to simulators [^17][^18].

### ACCESS: Allocations and Portal Usage

If your job is rejected, revisit queue policies and environment modules. Open OnDemand can simplify access to interactive sessions; Pegasus workflows provide orchestration for HTC workloads. Consult local ACCESS documentation for specific constraints [^19][^25].

---

## Appendices and Operational Runbooks

Operational checklists help sustain reliability across environments. Use them for routine validations, upgrades, and incident response.

### Table 11. Deployment checklists (Local, SageMaker, EKS, Rotation)

| Environment | Pre-deploy                                                                                               | Post-deploy                                                                                              | Ongoing Ops                                                                                                     |
|-------------|-----------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|
| Local       | GPU runtime validated; `.env` configured; volumes mounted; AWS credentials available                      | Healthchecks passing; Ray cluster connected; Prometheus/Grafana targets active                            | Image updates; logging rotation; cache cleanup; validate GPU visibility after host updates                      |
| SageMaker   | ECR image built/pushed; IAM role policies in place; endpoint naming finalized                             | Endpoint “InService”; smoke tests pass; CloudWatch metrics reasonable                                    | Blue/green updates; endpoint scaling; cost tuning; periodic driver upgrade planning                             |
| EKS         | GPU Operator installed; Karpenter NodePool defined; IAM/OIDC configured                                   | Device plugin reporting GPU capacity; DCGM metrics present; autoscaling responsive                       | Node monitoring/auto-repair; image pre-pulling; storage optimization for models; observability dashboards       |
| Rotation    | API keys provisioned; feature flags defined; rotation limits configured                                   | Jobs running in each platform; logs centralized; artifacts backed up                                      | Token rotation; usage monitoring; rate limit enforcement; failover paths; access control reviews                |

### Operational Playbooks

- Image pre-pulling and warm-up
  - Use node initialization scripts to pull container images before workloads land. For large model servers, store weights in fast storage or mount S3 via Mountpoint for S3 to reduce cold start latency [^16].

- Endpoint upgrades via blue/green deployments
  - Prepare a new SageMaker endpoint configuration, deploy the new variant, and shift traffic progressively to minimize downtime. Always maintain rollback pathways [^5].

- GPU failure handling
  - EKS Auto Mode detects GPU failures and can reboot or replace nodes while respecting Pod Disruption Budgets. Use DCGM metrics to detect anomalies and corroborate events [^2][^14].

- Observability alignment
  - Standardize metrics and logs across environments. Grafana dashboards should reflect local Compose, SageMaker CloudWatch signals, and EKS DCGM metrics.

- Backup and recovery
  - Regularly back up model artifacts and stateful data to S3. Validate restores in lower environments. Consider directory buckets via S3 Express One Zone for high-performance storage where appropriate [^8][^27].

---

## Conclusion

Deploying the Agentic Utopic AI Platform across local, SageMaker, EKS, and research environments requires consistent patterns for GPU enablement, security, observability, and environment management. By following the steps and best practices in this guide, teams can achieve repeatable, reliable deployments and scale from a single-node development setup to managed cloud endpoints and orchestrated GPU clusters.

Maintain disciplined operational runbooks and treat each environment’s unique constraints—driver alignment, instance types, queue policies—as design inputs. With these practices, the platform can rotate across heterogeneous compute backends while preserving performance and reliability.

---

## References

[^1]: NVIDIA GPU Operator with Amazon EKS. https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/amazon-eks.html  
[^2]: How to run AI model inference with GPUs on Amazon EKS Auto Mode. https://aws.amazon.com/blogs/containers/how-to-run-ai-model-inference-with-gpus-on-amazon-eks-auto-mode/  
[^3]: Using GPU from a docker container? (Stack Overflow). https://stackoverflow.com/questions/25185405/using-gpu-from-a-docker-container  
[^4]: Docker and NVIDIA Support for Building and Running AI/ML Apps. https://www.docker.com/blog/docker-nvidia-support-building-running-ai-ml-apps/  
[^5]: Best practices - Amazon SageMaker AI. https://docs.aws.amazon.com/sagemaker/latest/dg/best-practices.html  
[^6]: Deploy models for real-time inference - Amazon SageMaker AI. https://docs.aws.amazon.com/sagemaker/latest/dg/realtime-endpoints-deploy-models.html  
[^7]: What is Amazon ECR? https://docs.aws.amazon.com/AmazonECR/latest/userguide/what-is-ecr.html  
[^8]: Amazon S3 — User Guide. https://docs.aws.amazon.com/AmazonS3/latest/userguide/Welcome.html  
[^9]: AI on EKS: Container Startup Time Guidance. https://awslabs.github.io/ai-on-eks/docs/guidance/container-startup-time  
[^10]: Accelerate AI Model Orchestration with NVIDIA Run:ai on AWS (NVIDIA Developer Blog). https://developer.nvidia.com/blog/accelerate-ai-model-orchestration-with-nvidia-runai-on-aws/  
[^11]: Karpenter. https://karpenter.sh/  
[^12]: Karpenter NodePools. https://karpenter.sh/docs/concepts/nodepools/  
[^13]: AWS CLI. https://aws.amazon.com/cli/  
[^14]: NVIDIA DCGM Exporter. https://github.com/NVIDIA/dcgm-exporter  
[^15]: AI on EKS - AWS Labs. https://github.com/awslabs/ai-on-eks  
[^16]: Mountpoint for Amazon S3. https://github.com/awslabs/mountpoint-s3  
[^17]: Online lab environments | IBM Quantum Documentation. https://quantum.cloud.ibm.com/docs/guides/online-lab-environments  
[^18]: IBM Quantum Qiskit Serverless. https://quantum.cloud.ibm.com/docs/guides/serverless  
[^19]: ACCESS Support Knowledge Base Resources. https://support.access-ci.org/knowledge-base/resources  
[^20]: Kubectl Reference Documentation. https://kubernetes.io/docs/reference/kubectl/  
[^21]: eksctl. https://eksctl.io/  
[^22]: Amazon EC2. https://aws.amazon.com/ec2/  
[^23]: Bottlerocket OS. https://aws.amazon.com/bottlerocket/  
[^24]: Google Colab. https://colab.research.google.com/  
[^25]: Open OnDemand. https://openondemand.org  
[^26]: Hugging Face. https://huggingface.co/  
[^27]: Amazon S3: Directory buckets & S3 Express One Zone. https://docs.aws.amazon.com/AmazonS3/latest/userguide/directory-bucket-high-performance.html#s3-express-one-zone