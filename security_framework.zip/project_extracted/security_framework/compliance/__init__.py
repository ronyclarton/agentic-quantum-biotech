"""
Compliance Automation Module
Implements automated compliance for GDPR, HIPAA, and SOC2
"""

from .gdpr_compliance import GDPRCompliance
from .hipaa_compliance import HIPAACompliance  
from .soc2_compliance import SOC2Compliance
from .compliance_dashboard import ComplianceDashboard

__all__ = [
    'GDPRCompliance',
    'HIPAACompliance',
    'SOC2Compliance',
    'ComplianceDashboard'
]