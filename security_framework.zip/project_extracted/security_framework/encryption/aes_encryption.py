"""
AES-256 Enterprise Encryption Implementation
Provides end-to-end encryption with advanced security features
"""

import os
import hashlib
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.fernet import Fernet
from typing import Optional, Union, Dict, Any
import json
import logging
from datetime import datetime, timedelta
from enum import Enum
import uuid

class EncryptionMode(Enum):
    """Encryption modes supported"""
    CBC = "cbc"
    GCM = "gcm"
    XTS = "xts"

class SecurityLevel(Enum):
    """Security classification levels"""
    PUBLIC = 1
    INTERNAL = 2
    CONFIDENTIAL = 3
    SECRET = 4
    TOP_SECRET = 5

class AES256Encryptor:
    """
    Enterprise-grade AES-256 encryption with advanced security features
    """
    
    def __init__(self, master_key: Optional[bytes] = None, hsm_provider=None):
        """
        Initialize AES-256 encryptor
        
        Args:
            master_key: 32-byte master key for encryption
            hsm_provider: Hardware Security Module provider
        """
        self.backend = default_backend()
        self.hsm_provider = hsm_provider
        self.key_rotation_interval = timedelta(days=90)  # 90-day rotation
        self.last_rotation = datetime.utcnow()
        
        # Initialize master key
        if master_key:
            if len(master_key) != 32:
                raise ValueError("Master key must be exactly 32 bytes")
            self.master_key = master_key
        else:
            self.master_key = os.urandom(32)
            logging.warning("Generated new master key - secure storage required")
        
        # Initialize logging
        self.logger = logging.getLogger(__name__)
        
        # Key cache for performance
        self._key_cache: Dict[str, bytes] = {}
        self._cache_ttl = timedelta(hours=1)
    
    def derive_key(self, data: bytes, salt: bytes, usage_context: str = "general") -> bytes:
        """
        Derive encryption key from master key using HKDF
        
        Args:
            data: Data to derive key for
            salt: Salt for key derivation
            usage_context: Context identifier for key usage
            
        Returns:
            32-byte derived key
        """
        # Check cache first
        cache_key = hashlib.sha256(f"{data.hex()}:{salt.hex()}:{usage_context}".encode()).hexdigest()
        if cache_key in self._key_cache:
            return self._key_cache[cache_key]
        
        # Use HKDF for key derivation
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            info=f"security_framework:{usage_context}".encode(),
            backend=self.backend
        )
        
        derived_key = hkdf.derive(self.master_key)
        
        # Cache the key
        self._key_cache[cache_key] = derived_key
        
        return derived_key
    
    def encrypt_data(self, data: Union[str, bytes], 
                    security_level: SecurityLevel = SecurityLevel.CONFIDENTIAL,
                    metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Encrypt data with AES-256-GCM
        
        Args:
            data: Data to encrypt
            security_level: Security classification level
            metadata: Additional metadata to encrypt with data
            
        Returns:
            Dictionary containing encrypted data and metadata
        """
        try:
            # Convert string to bytes if needed
            if isinstance(data, str):
                data = data.encode('utf-8')
            
            # Generate salt and nonce
            salt = os.urandom(16)
            nonce = os.urandom(12)
            
            # Derive encryption key
            encryption_key = self.derive_key(data, salt, f"level_{security_level.value}")
            
            # Prepare additional authenticated data (AAD)
            aad_data = {
                'security_level': security_level.value,
                'timestamp': datetime.utcnow().isoformat(),
                'version': '1.0',
                'uuid': str(uuid.uuid4())
            }
            
            if metadata:
                aad_data.update(metadata)
            
            aad_json = json.dumps(aad_data, sort_keys=True).encode('utf-8')
            
            # Encrypt using AES-256-GCM
            cipher = Cipher(
                algorithms.AES(encryption_key),
                modes.GCM(nonce),
                backend=self.backend
            )
            
            encryptor = cipher.encryptor()
            encryptor.authenticate_additional_data(aad_json)
            
            ciphertext = encryptor.update(data) + encryptor.finalize()
            tag = encryptor.tag
            
            # Prepare encrypted package
            encrypted_package = {
                'ciphertext': base64.b64encode(ciphertext).decode('utf-8'),
                'tag': base64.b64encode(tag).decode('utf-8'),
                'nonce': base64.b64encode(nonce).decode('utf-8'),
                'salt': base64.b64encode(salt).decode('utf-8'),
                'aad': base64.b64encode(aad_json).decode('utf-8'),
                'security_level': security_level.value,
                'encryption_method': 'AES-256-GCM',
                'timestamp': aad_data['timestamp']
            }
            
            # Log encryption event
            self.logger.info(f"Data encrypted with security level {security_level.name}")
            
            return encrypted_package
            
        except Exception as e:
            self.logger.error(f"Encryption failed: {str(e)}")
            raise
    
    def decrypt_data(self, encrypted_package: Dict[str, Any]) -> bytes:
        """
        Decrypt data using AES-256-GCM
        
        Args:
            encrypted_package: Encrypted data package
            
        Returns:
            Decrypted data as bytes
        """
        try:
            # Extract components
            ciphertext = base64.b64decode(encrypted_package['ciphertext'])
            tag = base64.b64decode(encrypted_package['tag'])
            nonce = base64.b64decode(encrypted_package['nonce'])
            salt = base64.b64decode(encrypted_package['salt'])
            aad_json = base64.b64decode(encrypted_package['aad'])
            
            # Parse AAD
            aad_data = json.loads(aad_json.decode('utf-8'))
            security_level = SecurityLevel(aad_data['security_level'])
            
            # Derive decryption key
            decryption_key = self.derive_key(b"decryption", salt, f"level_{security_level.value}")
            
            # Decrypt using AES-256-GCM
            cipher = Cipher(
                algorithms.AES(decryption_key),
                modes.GCM(nonce, tag),
                backend=self.backend
            )
            
            decryptor = cipher.decryptor()
            decryptor.authenticate_additional_data(aad_json)
            
            plaintext = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Log decryption event
            self.logger.info(f"Data decrypted with security level {security_level.name}")
            
            return plaintext
            
        except Exception as e:
            self.logger.error(f"Decryption failed: {str(e)}")
            raise
    
    def encrypt_file(self, file_path: str, 
                    security_level: SecurityLevel = SecurityLevel.CONFIDENTIAL,
                    output_path: Optional[str] = None) -> str:
        """
        Encrypt a file with AES-256
        
        Args:
            file_path: Path to file to encrypt
            security_level: Security classification level
            output_path: Output file path (optional)
            
        Returns:
            Path to encrypted file
        """
        try:
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            encrypted_package = self.encrypt_data(file_data, security_level)
            
            # Determine output path
            if output_path is None:
                output_path = f"{file_path}.encrypted"
            
            # Save encrypted package
            with open(output_path, 'w') as f:
                json.dump(encrypted_package, f, indent=2)
            
            self.logger.info(f"File encrypted: {file_path} -> {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"File encryption failed: {str(e)}")
            raise
    
    def decrypt_file(self, encrypted_file_path: str, 
                    output_path: Optional[str] = None) -> str:
        """
        Decrypt a file encrypted with AES-256
        
        Args:
            encrypted_file_path: Path to encrypted file
            output_path: Output file path (optional)
            
        Returns:
            Path to decrypted file
        """
        try:
            # Load encrypted package
            with open(encrypted_file_path, 'r') as f:
                encrypted_package = json.load(f)
            
            # Decrypt data
            decrypted_data = self.decrypt_data(encrypted_package)
            
            # Determine output path
            if output_path is None:
                output_path = encrypted_file_path.replace('.encrypted', '')
            
            # Save decrypted file
            with open(output_path, 'wb') as f:
                f.write(decrypted_data)
            
            self.logger.info(f"File decrypted: {encrypted_file_path} -> {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"File decryption failed: {str(e)}")
            raise
    
    def rotate_keys(self) -> Dict[str, Any]:
        """
        Rotate encryption keys
        
        Returns:
            Rotation status and new key information
        """
        try:
            # Generate new master key
            new_master_key = os.urandom(32)
            old_master_key = self.master_key
            
            # Store old key for transition period
            self.logger.info("Key rotation initiated")
            
            # Update master key
            self.master_key = new_master_key
            self.last_rotation = datetime.utcnow()
            
            # Clear key cache
            self._key_cache.clear()
            
            rotation_info = {
                'status': 'success',
                'timestamp': self.last_rotation.isoformat(),
                'new_key_fingerprint': self.get_key_fingerprint(),
                'rotation_period_days': 90
            }
            
            self.logger.info("Key rotation completed successfully")
            return rotation_info
            
        except Exception as e:
            self.logger.error(f"Key rotation failed: {str(e)}")
            raise
    
    def get_key_fingerprint(self) -> str:
        """
        Get fingerprint of current master key
        
        Returns:
            SHA-256 fingerprint of master key
        """
        return hashlib.sha256(self.master_key).hexdigest()
    
    def verify_integrity(self, encrypted_package: Dict[str, Any]) -> bool:
        """
        Verify integrity of encrypted package
        
        Args:
            encrypted_package: Encrypted data package
            
        Returns:
            True if integrity verification passes
        """
        try:
            # Attempt to decrypt to verify integrity
            self.decrypt_data(encrypted_package)
            return True
        except Exception:
            return False
    
    def export_public_key(self) -> bytes:
        """
        Export public key for key exchange
        
        Returns:
            Public key bytes
        """
        # This is a simplified version - in production, use proper asymmetric key pair
        return hashlib.sha256(self.master_key).digest()
    
    def secure_delete(self, file_path: str) -> bool:
        """
        Securely delete file using DoD 5220.22-M standard
        
        Args:
            file_path: Path to file to delete
            
        Returns:
            True if deletion successful
        """
        try:
            # Overwrite file multiple times
            file_size = os.path.getsize(file_path)
            
            # 1st pass: random data
            with open(file_path, 'r+b') as f:
                f.write(os.urandom(file_size))
                f.flush()
                os.fsync(f.fileno())
            
            # 2nd pass: zeros
            with open(file_path, 'r+b') as f:
                f.write(b'\x00' * file_size)
                f.flush()
                os.fsync(f.fileno())
            
            # 3rd pass: ones
            with open(file_path, 'r+b') as f:
                f.write(b'\xFF' * file_size)
                f.flush()
                os.fsync(f.fileno())
            
            # Remove file
            os.remove(file_path)
            
            self.logger.info(f"File securely deleted: {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Secure deletion failed: {str(e)}")
            return False

# Utility functions
def generate_secure_random_key(length: int = 32) -> bytes:
    """
    Generate cryptographically secure random key
    
    Args:
        length: Key length in bytes
        
    Returns:
        Random key bytes
    """
    return os.urandom(length)

def hash_password(password: str, salt: Optional[bytes] = None) -> tuple[bytes, bytes]:
    """
    Hash password using PBKDF2
    
    Args:
        password: Password to hash
        salt: Salt (generated if None)
        
    Returns:
        Tuple of (hashed_password, salt)
    """
    if salt is None:
        salt = os.urandom(32)
    
    pbkdf2 = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,  # OWASP recommended minimum
        backend=default_backend()
    )
    
    hashed_password = pbkdf2.derive(password.encode('utf-8'))
    return hashed_password, salt

def verify_password(password: str, hashed_password: bytes, salt: bytes) -> bool:
    """
    Verify password against hash
    
    Args:
        password: Password to verify
        hashed_password: Stored hash
        salt: Salt used in hashing
        
    Returns:
        True if password verification passes
    """
    try:
        pbkdf2 = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        
        pbkdf2.verify(password.encode('utf-8'), hashed_password)
        return True
    except Exception:
        return False