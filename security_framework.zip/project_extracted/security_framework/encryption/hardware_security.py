"""
Hardware Security Module (HSM) Integration
Provides enterprise-grade cryptographic operations using HSM
"""

import os
import logging
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from enum import Enum
import hashlib
import json

try:
    import pkcs11
    from pkcs11 import Mechanism, ObjectClass
    PKCS11_AVAILABLE = True
except ImportError:
    PKCS11_AVAILABLE = False
    logging.warning("PyPKCS11 not available - HSM integration disabled")

class HSMType(Enum):
    """Supported HSM types"""
    SOFTWARE = "software"
    CLOUD_HSM = "cloud"
    HARDWARE = "hardware"
    PKCS11 = "pkcs11"

class SecurityLevel(Enum):
    """Security levels for operations"""
    FIPS_140_2_LEVEL_1 = 1
    FIPS_140_2_LEVEL_2 = 2
    FIPS_140_2_LEVEL_3 = 3
    FIPS_140_2_LEVEL_4 = 4

class HSMCryptoProvider:
    """
    Hardware Security Module Crypto Provider
    Provides enterprise-grade cryptographic operations with HSM integration
    """
    
    def __init__(self, hsm_type: HSMType = HSMType.SOFTWARE, 
                 config: Optional[Dict[str, Any]] = None):
        """
        Initialize HSM Crypto Provider
        
        Args:
            hsm_type: Type of HSM to use
            config: HSM configuration parameters
        """
        self.hsm_type = hsm_type
        self.config = config or {}
        self.logger = logging.getLogger(__name__)
        self.backend = None
        self.session = None
        self.slot_id = None
        
        # Security configuration
        self.security_level = SecurityLevel.FIPS_140_2_LEVEL_3
        self.max_pin_attempts = 3
        self.pin_timeout = 300  # 5 minutes
        
        self._initialize_hsm()
    
    def _initialize_hsm(self):
        """Initialize HSM backend based on type"""
        try:
            if self.hsm_type == HSMType.PKCS11 and PKCS11_AVAILABLE:
                self._initialize_pkcs11()
            elif self.hsm_type == HSMType.CLOUD_HSM:
                self._initialize_cloud_hsm()
            elif self.hsm_type == HSMType.HARDWARE:
                self._initialize_hardware_hsm()
            else:
                self._initialize_software_hsm()
                
            self.logger.info(f"HSM provider initialized: {self.hsm_type.value}")
            
        except Exception as e:
            self.logger.error(f"HSM initialization failed: {str(e)}")
            raise
    
    def _initialize_pkcs11(self):
        """Initialize PKCS#11 HSM"""
        if not PKCS11_AVAILABLE:
            raise ImportError("PyPKCS11 not available")
        
        try:
            # Load PKCS#11 library
            library_path = self.config.get('library_path', '/usr/lib/libpkcs11.so')
            self.backend = pkcs11.lib(library_path)
            
            # Get slot
            self.slot_id = self.config.get('slot_id', 0)
            self.session = self.backend.open_session(self.slot_id)
            
            # Login with user PIN
            user_pin = self.config.get('user_pin')
            if user_pin:
                self.session.login(user_pin)
            
            self.logger.info("PKCS#11 HSM initialized successfully")
            
        except Exception as e:
            self.logger.error(f"PKCS#11 initialization failed: {str(e)}")
            raise
    
    def _initialize_cloud_hsm(self):
        """Initialize Cloud HSM (AWS CloudHSM, Azure HSM, etc.)"""
        try:
            # Implementation for cloud HSM services
            # This would integrate with specific cloud provider APIs
            cloud_provider = self.config.get('provider', 'aws')
            
            if cloud_provider == 'aws':
                self._initialize_aws_cloudhsm()
            elif cloud_provider == 'azure':
                self._initialize_azure_hsm()
            elif cloud_provider == 'gcp':
                self._initialize_gcp_hsm()
            
            self.logger.info(f"Cloud HSM initialized: {cloud_provider}")
            
        except Exception as e:
            self.logger.error(f"Cloud HSM initialization failed: {str(e)}")
            raise
    
    def _initialize_aws_cloudhsm(self):
        """Initialize AWS CloudHSM"""
        # Implementation would use boto3 to connect to CloudHSM cluster
        # This is a placeholder for the actual implementation
        pass
    
    def _initialize_azure_hsm(self):
        """Initialize Azure Dedicated HSM"""
        # Implementation would use Azure SDK to connect to HSM service
        # This is a placeholder for the actual implementation
        pass
    
    def _initialize_gcp_hsm(self):
        """Initialize Google Cloud HSM"""
        # Implementation would use Google Cloud SDK to connect to HSM service
        # This is a placeholder for the actual implementation
        pass
    
    def _initialize_hardware_hsm(self):
        """Initialize Hardware HSM (Thales, Gemalto, etc.)"""
        try:
            # Implementation for hardware HSM devices
            device_type = self.config.get('device_type', 'thales')
            
            if device_type == 'thales':
                self._initialize_thales_hsm()
            elif device_type == 'gemalto':
                self._initialize_gemalto_hsm()
            
            self.logger.info(f"Hardware HSM initialized: {device_type}")
            
        except Exception as e:
            self.logger.error(f"Hardware HSM initialization failed: {str(e)}")
            raise
    
    def _initialize_thales_hsm(self):
        """Initialize Thales Hardware HSM"""
        # Implementation would use Thales SDK to connect to HSM
        # This is a placeholder for the actual implementation
        pass
    
    def _initialize_gemalto_hsm(self):
        """Initialize Gemalto Hardware HSM"""
        # Implementation would use Gemalto SDK to connect to HSM
        # This is a placeholder for the actual implementation
        pass
    
    def _initialize_software_hsm(self):
        """Initialize Software-based HSM (FIPS-compliant software library)"""
        try:
            # Use software-based cryptographic library with FIPS compliance
            # This provides a fallback when hardware HSM is not available
            self.logger.info("Software HSM initialized (FIPS-compliant)")
            
        except Exception as e:
            self.logger.error(f"Software HSM initialization failed: {str(e)}")
            raise
    
    def generate_key(self, key_type: str, key_size: int = 256, 
                    key_usage: List[str] = None) -> Dict[str, Any]:
        """
        Generate cryptographic key in HSM
        
        Args:
            key_type: Type of key to generate
            key_size: Key size in bits
            key_usage: List of key usage flags
            
        Returns:
            Key information
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._generate_pkcs11_key(key_type, key_size, key_usage)
            elif self.hsm_type == HSMType.CLOUD_HSM:
                return self._generate_cloud_key(key_type, key_size, key_usage)
            elif self.hsm_type == HSMType.HARDWARE:
                return self._generate_hardware_key(key_type, key_size, key_usage)
            else:
                return self._generate_software_key(key_type, key_size, key_usage)
                
        except Exception as e:
            self.logger.error(f"Key generation failed: {str(e)}")
            raise
    
    def _generate_pkcs11_key(self, key_type: str, key_size: int, key_usage: List[str]) -> Dict[str, Any]:
        """Generate key using PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            if key_type.lower() == 'aes':
                # Generate AES key
                key = self.session.generate_key(
                    ObjectClass.SECRET_KEY,
                    template={
                        pkcs11.Attribute.CLASS: ObjectClass.SECRET_KEY,
                        pkcs11.Attribute.KEY_TYPE: pkcs11.KeyType.AES,
                        pkcs11.Attribute.VALUE_LEN: key_size // 8,
                        pkcs11.Attribute.ENCRYPT: True,
                        pkcs11.Attribute.DECRYPT: True,
                        pkcs11.Attribute.SIGN: False,
                        pkcs11.Attribute.VERIFY: False,
                        pkcs11.Attribute.SENSITIVE: True,
                        pkcs11.Attribute.EXTRACTABLE: False
                    }
                )
                
            elif key_type.lower() == 'rsa':
                # Generate RSA key pair
                public_exponent = int(self.config.get('public_exponent', 65537))
                private_key = self.session.generate_key(
                    ObjectClass.PRIVATE_KEY,
                    template={
                        pkcs11.Attribute.CLASS: ObjectClass.PRIVATE_KEY,
                        pkcs11.Attribute.KEY_TYPE: pkcs11.KeyType.RSA,
                        pkcs11.Attribute.MODULUS_BITS: key_size,
                        pkcs11.Attribute.PUBLIC_EXPONENT: bytes([1, 0, 1]),
                        pkcs11.Attribute.ENCRYPT: True,
                        pkcs11.Attribute.DECRYPT: True,
                        pkcs11.Attribute.SIGN: True,
                        pkcs11.Attribute.VERIFY: True,
                        pkcs11.Attribute.SENSITIVE: True,
                        pkcs11.Attribute.EXTRACTABLE: False
                    }
                )
                
                # Get public key
                public_key = private_key.public_key
                
            else:
                raise ValueError(f"Unsupported key type: {key_type}")
            
            # Get key attributes
            key_id = getattr(key, 'id', b'')
            label = getattr(key, 'label', f'{key_type}_{key_size}_{datetime.utcnow().isoformat()}')
            
            key_info = {
                'key_id': key_id.hex() if key_id else hashlib.sha256(label.encode()).hexdigest(),
                'key_type': key_type,
                'key_size': key_size,
                'label': label,
                'hsm_type': self.hsm_type.value,
                'created_at': datetime.utcnow().isoformat(),
                'sensitive': True,
                'extractable': False
            }
            
            self.logger.info(f"PKCS#11 key generated: {key_info['key_id']}")
            return key_info
            
        except Exception as e:
            self.logger.error(f"PKCS#11 key generation failed: {str(e)}")
            raise
    
    def _generate_cloud_key(self, key_type: str, key_size: int, key_usage: List[str]) -> Dict[str, Any]:
        """Generate key using Cloud HSM"""
        # Implementation for cloud HSM key generation
        # This would call the appropriate cloud provider API
        pass
    
    def _generate_hardware_key(self, key_type: str, key_size: int, key_usage: List[str]) -> Dict[str, Any]:
        """Generate key using Hardware HSM"""
        # Implementation for hardware HSM key generation
        # This would call the appropriate hardware HSM SDK
        pass
    
    def _generate_software_key(self, key_type: str, key_size: int, key_usage: List[str]) -> Dict[str, Any]:
        """Generate key using Software HSM"""
        # Software-based key generation with FIPS compliance
        key_id = f"{key_type}_{key_size}_{datetime.utcnow().timestamp()}"
        
        key_info = {
            'key_id': key_id,
            'key_type': key_type,
            'key_size': key_size,
            'label': f'software_{key_type}',
            'hsm_type': self.hsm_type.value,
            'created_at': datetime.utcnow().isoformat(),
            'sensitive': True,
            'extractable': False
        }
        
        self.logger.info(f"Software key generated: {key_id}")
        return key_info
    
    def encrypt(self, key_id: str, data: bytes) -> Dict[str, Any]:
        """
        Encrypt data using HSM
        
        Args:
            key_id: Key identifier in HSM
            data: Data to encrypt
            
        Returns:
            Encrypted data package
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._encrypt_pkcs11(key_id, data)
            else:
                return self._encrypt_generic(key_id, data)
                
        except Exception as e:
            self.logger.error(f"HSM encryption failed: {str(e)}")
            raise
    
    def _encrypt_pkcs11(self, key_id: str, data: bytes) -> Dict[str, Any]:
        """Encrypt using PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            # Find key by ID
            key = self.session.get_key(ObjectClass.SECRET_KEY, id=bytes.fromhex(key_id))
            
            # Generate IV
            iv = os.urandom(16)
            
            # Encrypt data
            encrypted_data = key.encrypt(data, mechanism=pkcs11.Mechanism.AES_ECB_CBC)
            
            result = {
                'encrypted_data': encrypted_data.hex(),
                'iv': iv.hex(),
                'key_id': key_id,
                'algorithm': 'AES-256-CBC',
                'hsm_type': self.hsm_type.value
            }
            
            self.logger.info(f"PKCS#11 encryption completed: {key_id}")
            return result
            
        except Exception as e:
            self.logger.error(f"PKCS#11 encryption failed: {str(e)}")
            raise
    
    def _encrypt_generic(self, key_id: str, data: bytes) -> Dict[str, Any]:
        """Generic encryption implementation"""
        # Fallback implementation for non-PKCS#11 HSMs
        pass
    
    def decrypt(self, key_id: str, encrypted_data: str, iv: str) -> bytes:
        """
        Decrypt data using HSM
        
        Args:
            key_id: Key identifier in HSM
            encrypted_data: Encrypted data
            iv: Initialization vector
            
        Returns:
            Decrypted data
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._decrypt_pkcs11(key_id, encrypted_data, iv)
            else:
                return self._decrypt_generic(key_id, encrypted_data, iv)
                
        except Exception as e:
            self.logger.error(f"HSM decryption failed: {str(e)}")
            raise
    
    def _decrypt_pkcs11(self, key_id: str, encrypted_data: str, iv: str) -> bytes:
        """Decrypt using PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            # Find key by ID
            key = self.session.get_key(ObjectClass.SECRET_KEY, id=bytes.fromhex(key_id))
            
            # Decrypt data
            decrypted_data = key.decrypt(
                bytes.fromhex(encrypted_data),
                mechanism=pkcs11.Mechanism.AES_ECB_CBC
            )
            
            self.logger.info(f"PKCS#11 decryption completed: {key_id}")
            return decrypted_data
            
        except Exception as e:
            self.logger.error(f"PKCS#11 decryption failed: {str(e)}")
            raise
    
    def _decrypt_generic(self, key_id: str, encrypted_data: str, iv: str) -> bytes:
        """Generic decryption implementation"""
        # Fallback implementation for non-PKCS#11 HSMs
        pass
    
    def sign(self, key_id: str, data: bytes) -> bytes:
        """
        Sign data using HSM
        
        Args:
            key_id: Key identifier in HSM
            data: Data to sign
            
        Returns:
            Digital signature
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._sign_pkcs11(key_id, data)
            else:
                return self._sign_generic(key_id, data)
                
        except Exception as e:
            self.logger.error(f"HSM signing failed: {str(e)}")
            raise
    
    def _sign_pkcs11(self, key_id: str, data: bytes) -> bytes:
        """Sign using PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            # Find private key by ID
            private_key = self.session.get_key(ObjectClass.PRIVATE_KEY, id=bytes.fromhex(key_id))
            
            # Sign data
            signature = private_key.sign(
                data,
                mechanism=pkcs11.Mechanism.RSA_PKCS
            )
            
            self.logger.info(f"PKCS#11 signing completed: {key_id}")
            return signature
            
        except Exception as e:
            self.logger.error(f"PKCS#11 signing failed: {str(e)}")
            raise
    
    def _sign_generic(self, key_id: str, data: bytes) -> bytes:
        """Generic signing implementation"""
        # Fallback implementation for non-PKCS#11 HSMs
        pass
    
    def verify_signature(self, key_id: str, data: bytes, signature: bytes) -> bool:
        """
        Verify digital signature using HSM
        
        Args:
            key_id: Key identifier in HSM
            data: Original data
            signature: Digital signature to verify
            
        Returns:
            True if signature is valid
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._verify_pkcs11(key_id, data, signature)
            else:
                return self._verify_generic(key_id, data, signature)
                
        except Exception as e:
            self.logger.error(f"HSM signature verification failed: {str(e)}")
            return False
    
    def _verify_pkcs11(self, key_id: str, data: bytes, signature: bytes) -> bool:
        """Verify signature using PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            # Find public key by ID
            public_key = self.session.get_key(ObjectClass.PUBLIC_KEY, id=bytes.fromhex(key_id))
            
            # Verify signature
            is_valid = public_key.verify(
                signature,
                data,
                mechanism=pkcs11.Mechanism.RSA_PKCS
            )
            
            self.logger.info(f"PKCS#11 signature verification: {key_id}, valid: {is_valid}")
            return is_valid
            
        except Exception as e:
            self.logger.error(f"PKCS#11 signature verification failed: {str(e)}")
            return False
    
    def _verify_generic(self, key_id: str, data: bytes, signature: bytes) -> bool:
        """Generic signature verification implementation"""
        # Fallback implementation for non-PKCS#11 HSMs
        pass
    
    def get_key_list(self) -> List[Dict[str, Any]]:
        """
        Get list of keys in HSM
        
        Returns:
            List of key information
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._get_pkcs11_key_list()
            else:
                return self._get_generic_key_list()
                
        except Exception as e:
            self.logger.error(f"Failed to get key list: {str(e)}")
            return []
    
    def _get_pkcs11_key_list(self) -> List[Dict[str, Any]]:
        """Get key list from PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            keys = []
            
            # Get all keys
            for key in self.session.get_objects():
                if hasattr(key, 'class_'):
                    key_info = {
                        'key_id': getattr(key, 'id', b'').hex(),
                        'label': getattr(key, 'label', 'unknown'),
                        'key_type': str(getattr(key, 'key_type', 'unknown')),
                        'class': str(key.class_),
                        'sensitive': getattr(key, 'sensitive', False),
                        'extractable': getattr(key, 'extractable', False)
                    }
                    keys.append(key_info)
            
            return keys
            
        except Exception as e:
            self.logger.error(f"PKCS#11 key listing failed: {str(e)}")
            return []
    
    def _get_generic_key_list(self) -> List[Dict[str, Any]]:
        """Get generic key list"""
        # Fallback implementation for non-PKCS#11 HSMs
        pass
    
    def delete_key(self, key_id: str) -> bool:
        """
        Delete key from HSM
        
        Args:
            key_id: Key identifier to delete
            
        Returns:
            True if deletion successful
        """
        try:
            if self.hsm_type == HSMType.PKCS11:
                return self._delete_pkcs11_key(key_id)
            else:
                return self._delete_generic_key(key_id)
                
        except Exception as e:
            self.logger.error(f"Key deletion failed: {str(e)}")
            return False
    
    def _delete_pkcs11_key(self, key_id: str) -> bool:
        """Delete key from PKCS#11 HSM"""
        if not self.session:
            raise RuntimeError("PKCS#11 session not initialized")
        
        try:
            # Find and destroy key
            key = self.session.get_key(ObjectClass.SECRET_KEY, id=bytes.fromhex(key_id))
            key.destroy()
            
            self.logger.info(f"PKCS#11 key deleted: {key_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"PKCS#11 key deletion failed: {str(e)}")
            return False
    
    def _delete_generic_key(self, key_id: str) -> bool:
        """Generic key deletion implementation"""
        # Fallback implementation for non-PKCS#11 HSMs
        pass
    
    def get_hsm_status(self) -> Dict[str, Any]:
        """
        Get HSM status information
        
        Returns:
            HSM status dictionary
        """
        try:
            status = {
                'hsm_type': self.hsm_type.value,
                'initialized': self.backend is not None,
                'session_active': self.session is not None,
                'security_level': self.security_level.value,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            if self.hsm_type == HSMType.PKCS11:
                status['slot_id'] = self.slot_id
            
            return status
            
        except Exception as e:
            self.logger.error(f"Failed to get HSM status: {str(e)}")
            return {}
    
    def close(self):
        """Clean up HSM resources"""
        try:
            if self.session:
                self.session.close()
            
            self.logger.info("HSM provider closed successfully")
            
        except Exception as e:
            self.logger.error(f"HSM cleanup failed: {str(e)}")

# Factory function for HSM provider creation
def create_hsm_provider(hsm_type: str, config: Optional[Dict[str, Any]] = None) -> HSMCryptoProvider:
    """
    Create HSM provider instance
    
    Args:
        hsm_type: Type of HSM to create
        config: HSM configuration
        
    Returns:
        HSMCryptoProvider instance
    """
    try:
        hsm_enum = HSMType(hsm_type.lower())
        return HSMCryptoProvider(hsm_enum, config)
    except ValueError:
        raise ValueError(f"Unsupported HSM type: {hsm_type}")

# Utility functions for HSM configuration
def get_hsm_recommendations() -> Dict[str, List[str]]:
    """
    Get HSM deployment recommendations by use case
    
    Returns:
        Dictionary of use cases and recommended HSM types
    """
    return {
        'high_security': [
            'FIPS 140-2 Level 3 Hardware HSM',
            'Cloud HSM with FIPS 140-2 Level 3',
            'PKCS#11 Hardware HSM'
        ],
        'enterprise': [
            'Cloud HSM (AWS CloudHSM, Azure Dedicated HSM)',
            'Hardware HSM (Thales, Gemalto)',
            'PKCS#11 Software HSM'
        ],
        'development': [
            'Software HSM (FIPS-compliant)',
            'PKCS#11 Software Library'
        ],
        'compliance': [
            'FIPS 140-2 Level 2+ HSM',
            'Validated cryptographic modules'
        ]
    }

def validate_hsm_configuration(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate HSM configuration
    
    Args:
        config: HSM configuration to validate
        
    Returns:
        Validation results
    """
    issues = []
    warnings = []
    
    # Check required fields based on HSM type
    hsm_type = config.get('type', 'software')
    
    if hsm_type == 'pkcs11':
        if not config.get('library_path'):
            issues.append("library_path required for PKCS#11 HSM")
        if not config.get('slot_id'):
            warnings.append("slot_id not specified, will use default")
    
    elif hsm_type == 'cloud':
        if not config.get('provider'):
            issues.append("provider required for cloud HSM")
        if not config.get('credentials'):
            issues.append("credentials required for cloud HSM")
    
    return {
        'valid': len(issues) == 0,
        'issues': issues,
        'warnings': warnings
    }