"""
Enterprise Key Management System
Handles secure key storage, rotation, and distribution
"""

import os
import json
import hashlib
import sqlite3
import logging
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend
from .aes_encryption import AES256Encryptor, generate_secure_random_key

class KeyType:
    """Key type definitions"""
    MASTER_KEY = "master"
    DATA_ENCRYPTION_KEY = "dek"
    SIGNING_KEY = "signing"
    TOKEN_KEY = "token"
    BACKUP_KEY = "backup"

class KeyStatus:
    """Key status definitions"""
    ACTIVE = "active"
    ROTATED = "rotated"
    EXPIRED = "expired"
    REVOKED = "revoked"
    ARCHIVED = "archived"

class KeyManager:
    """
    Enterprise Key Management System
    Implements secure key storage, rotation, and lifecycle management
    """
    
    def __init__(self, database_path: str = "security_framework/encryption/keys.db",
                 master_password: Optional[str] = None):
        """
        Initialize Key Manager
        
        Args:
            database_path: Path to SQLite database for key storage
            master_password: Master password for key encryption
        """
        self.database_path = database_path
        self.logger = logging.getLogger(__name__)
        self.backend = default_backend()
        
        # Initialize master key for database encryption
        if master_password:
            self.master_key = hashlib.sha256(master_password.encode()).digest()
        else:
            self.master_key = generate_secure_random_key(32)
            self.logger.warning("Generated temporary master key - secure storage required")
        
        # Initialize encryptor for database
        self.db_encryptor = AES256Encryptor(master_key=self.master_key)
        
        # Initialize database
        self._initialize_database()
        
        # Key rotation policies
        self.rotation_policies = {
            KeyType.MASTER_KEY: timedelta(days=365),
            KeyType.DATA_ENCRYPTION_KEY: timedelta(days=90),
            KeyType.SIGNING_KEY: timedelta(days=180),
            KeyType.TOKEN_KEY: timedelta(days=30),
            KeyType.BACKUP_KEY: timedelta(days=90)
        }
    
    def _initialize_database(self):
        """Initialize SQLite database for key storage"""
        try:
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            # Create keys table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS keys (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key_id TEXT UNIQUE NOT NULL,
                    key_type TEXT NOT NULL,
                    key_data BLOB NOT NULL,
                    key_metadata TEXT,
                    status TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP,
                    last_used TIMESTAMP,
                    rotation_count INTEGER DEFAULT 0,
                    parent_key_id TEXT,
                    FOREIGN KEY (parent_key_id) REFERENCES keys(key_id)
                )
            ''')
            
            # Create key usage log table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS key_usage_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key_id TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    success BOOLEAN NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    source_ip TEXT,
                    user_id TEXT,
                    FOREIGN KEY (key_id) REFERENCES keys(key_id)
                )
            ''')
            
            # Create indexes for performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_key_type ON keys(key_type)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_key_status ON keys(status)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_key_created ON keys(created_at)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_key_usage ON key_usage_log(key_id, timestamp)')
            
            conn.commit()
            conn.close()
            
            self.logger.info("Key database initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Database initialization failed: {str(e)}")
            raise
    
    def generate_key(self, key_type: str, key_id: Optional[str] = None,
                    metadata: Optional[Dict[str, Any]] = None,
                    parent_key_id: Optional[str] = None,
                    key_size: int = 32) -> Dict[str, Any]:
        """
        Generate new cryptographic key
        
        Args:
            key_type: Type of key to generate
            key_id: Custom key identifier
            metadata: Additional metadata for key
            parent_key_id: Parent key for key derivation
            key_size: Key size in bytes
            
        Returns:
            Key information dictionary
        """
        try:
            if not key_id:
                key_id = f"{key_type}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{hashlib.sha256(os.urandom(16)).hexdigest()[:8]}"
            
            # Generate key based on type
            if key_type == KeyType.SIGNING_KEY:
                # Generate RSA key pair for signing
                private_key = rsa.generate_private_key(
                    public_exponent=65537,
                    key_size=2048,
                    backend=self.backend
                )
                public_key = private_key.public_key()
                
                # Serialize keys
                private_key_pem = private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                )
                public_key_pem = public_key.public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                )
                
                # Store both keys
                key_data = {
                    'private_key': private_key_pem,
                    'public_key': public_key_pem
                }
            else:
                # Generate symmetric key
                key_data = generate_secure_random_key(key_size)
            
            # Encrypt key data for storage
            encrypted_package = self.db_encryptor.encrypt_data(
                json.dumps(key_data).encode('utf-8')
            )
            
            # Prepare metadata
            key_metadata = {
                'algorithm': 'RSA-2048' if key_type == KeyType.SIGNING_KEY else 'AES-256',
                'key_size': 2048 if key_type == KeyType.SIGNING_KEY else key_size,
                'generation_time': datetime.utcnow().isoformat(),
                'usage_count': 0
            }
            
            if metadata:
                key_metadata.update(metadata)
            
            # Set expiration based on rotation policy
            expires_at = None
            if key_type in self.rotation_policies:
                expires_at = datetime.utcnow() + self.rotation_policies[key_type]
            
            # Store key in database
            self._store_key(
                key_id=key_id,
                key_type=key_type,
                key_data=encrypted_package,
                metadata=key_metadata,
                expires_at=expires_at,
                parent_key_id=parent_key_id
            )
            
            self.logger.info(f"Generated {key_type} key: {key_id}")
            
            return {
                'key_id': key_id,
                'key_type': key_type,
                'status': KeyStatus.ACTIVE,
                'created_at': datetime.utcnow().isoformat(),
                'expires_at': expires_at.isoformat() if expires_at else None,
                'fingerprint': self._calculate_key_fingerprint(key_data)
            }
            
        except Exception as e:
            self.logger.error(f"Key generation failed: {str(e)}")
            raise
    
    def get_key(self, key_id: str, decrypt: bool = True) -> Optional[Dict[str, Any]]:
        """
        Retrieve key from storage
        
        Args:
            key_id: Key identifier
            decrypt: Whether to decrypt key data
            
        Returns:
            Key information and data if found
        """
        try:
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT key_id, key_type, key_data, key_metadata, status, 
                       created_at, expires_at, last_used, rotation_count, parent_key_id
                FROM keys WHERE key_id = ?
            ''', (key_id,))
            
            row = cursor.fetchone()
            conn.close()
            
            if not row:
                return None
            
            # Update last used timestamp
            self._update_key_usage(key_id)
            
            result = {
                'key_id': row[0],
                'key_type': row[1],
                'status': row[4],
                'created_at': row[5],
                'expires_at': row[6],
                'last_used': row[7],
                'rotation_count': row[8],
                'parent_key_id': row[9]
            }
            
            # Decrypt key data if requested
            if decrypt and row[2]:
                key_data = self.db_encryptor.decrypt_data(json.loads(row[2]))
                result['key_data'] = json.loads(key_data.decode('utf-8'))
            
            # Parse metadata
            if row[3]:
                result['metadata'] = json.loads(row[3])
            
            return result
            
        except Exception as e:
            self.logger.error(f"Key retrieval failed: {str(e)}")
            return None
    
    def rotate_key(self, key_id: str, generate_new: bool = True) -> Dict[str, Any]:
        """
        Rotate a key by generating a new version
        
        Args:
            key_id: Key identifier to rotate
            generate_new: Whether to generate new key data
            
        Returns:
            Rotation status and new key information
        """
        try:
            # Get current key information
            current_key = self.get_key(key_id, decrypt=True)
            if not current_key:
                raise ValueError(f"Key not found: {key_id}")
            
            # Mark current key as rotated
            self._update_key_status(key_id, KeyStatus.ROTATED)
            
            # Generate new key with same type and metadata
            new_key_id = f"{key_id}_rotated_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
            
            rotation_metadata = current_key.get('metadata', {})
            rotation_metadata['rotated_from'] = key_id
            rotation_metadata['rotation_time'] = datetime.utcnow().isoformat()
            rotation_metadata['rotation_reason'] = 'scheduled'
            
            new_key_info = self.generate_key(
                key_type=current_key['key_type'],
                key_id=new_key_id,
                metadata=rotation_metadata,
                parent_key_id=key_id
            )
            
            # Log key rotation
            self._log_key_usage(key_id, 'rotate', True)
            
            self.logger.info(f"Key rotated: {key_id} -> {new_key_id}")
            
            return {
                'status': 'success',
                'original_key': key_id,
                'new_key': new_key_id,
                'rotation_time': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Key rotation failed: {str(e)}")
            raise
    
    def revoke_key(self, key_id: str, reason: str = "manual_revocation") -> bool:
        """
        Revoke a key to prevent further use
        
        Args:
            key_id: Key identifier to revoke
            reason: Reason for revocation
            
        Returns:
            True if revocation successful
        """
        try:
            self._update_key_status(key_id, KeyStatus.REVOKED)
            
            # Add revocation metadata
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE keys SET key_metadata = ?
                WHERE key_id = ?
            ''', (json.dumps({'revocation_reason': reason, 'revoked_at': datetime.utcnow().isoformat()}), key_id))
            
            conn.commit()
            conn.close()
            
            self._log_key_usage(key_id, 'revoke', True)
            
            self.logger.info(f"Key revoked: {key_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Key revocation failed: {str(e)}")
            return False
    
    def list_keys(self, key_type: Optional[str] = None, 
                 status: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List keys with optional filtering
        
        Args:
            key_type: Filter by key type
            status: Filter by key status
            
        Returns:
            List of key information
        """
        try:
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            query = "SELECT key_id, key_type, status, created_at, expires_at FROM keys WHERE 1=1"
            params = []
            
            if key_type:
                query += " AND key_type = ?"
                params.append(key_type)
            
            if status:
                query += " AND status = ?"
                params.append(status)
            
            query += " ORDER BY created_at DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            conn.close()
            
            keys = []
            for row in rows:
                keys.append({
                    'key_id': row[0],
                    'key_type': row[1],
                    'status': row[2],
                    'created_at': row[3],
                    'expires_at': row[4]
                })
            
            return keys
            
        except Exception as e:
            self.logger.error(f"Key listing failed: {str(e)}")
            return []
    
    def backup_keys(self, backup_path: str, password: str) -> bool:
        """
        Create encrypted backup of all keys
        
        Args:
            backup_path: Path to backup file
            password: Password to encrypt backup
            
        Returns:
            True if backup successful
        """
        try:
            # Export all keys
            keys_data = self.list_keys()
            
            # Add full key data for backup
            full_keys_data = []
            for key_info in keys_data:
                key_id = key_info['key_id']
                key_data = self.get_key(key_id, decrypt=True)
                if key_data:
                    full_keys_data.append(key_data)
            
            backup_package = {
                'timestamp': datetime.utcnow().isoformat(),
                'keys': full_keys_data,
                'version': '1.0'
            }
            
            # Encrypt and save backup
            backup_encryptor = AES256Encryptor(
                master_key=hashlib.sha256(password.encode()).digest()
            )
            encrypted_backup = backup_encryptor.encrypt_data(
                json.dumps(backup_package).encode('utf-8')
            )
            
            with open(backup_path, 'w') as f:
                json.dump(encrypted_backup, f)
            
            self.logger.info(f"Keys backup created: {backup_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Key backup failed: {str(e)}")
            return False
    
    def restore_keys(self, backup_path: str, password: str) -> bool:
        """
        Restore keys from encrypted backup
        
        Args:
            backup_path: Path to backup file
            password: Password to decrypt backup
            
        Returns:
            True if restoration successful
        """
        try:
            # Load encrypted backup
            with open(backup_path, 'r') as f:
                encrypted_backup = json.load(f)
            
            # Decrypt backup
            backup_encryptor = AES256Encryptor(
                master_key=hashlib.sha256(password.encode()).digest()
            )
            backup_data = backup_encryptor.decrypt_data(encrypted_backup)
            backup_package = json.loads(backup_data.decode('utf-8'))
            
            # Restore keys
            restored_count = 0
            for key_data in backup_package['keys']:
                try:
                    # Re-encrypt and store key
                    encrypted_package = self.db_encryptor.encrypt_data(
                        json.dumps(key_data['key_data']).encode('utf-8')
                    )
                    
                    self._store_key(
                        key_id=key_data['key_id'],
                        key_type=key_data['key_type'],
                        key_data=encrypted_package,
                        metadata=key_data.get('metadata', {}),
                        status=KeyStatus.ACTIVE
                    )
                    restored_count += 1
                    
                except Exception as e:
                    self.logger.warning(f"Failed to restore key {key_data.get('key_id', 'unknown')}: {str(e)}")
            
            self.logger.info(f"Restored {restored_count} keys from backup")
            return True
            
        except Exception as e:
            self.logger.error(f"Key restoration failed: {str(e)}")
            return False
    
    def get_key_statistics(self) -> Dict[str, Any]:
        """
        Get key management statistics
        
        Returns:
            Statistics dictionary
        """
        try:
            conn = sqlite3.connect(self.database_path)
            cursor = conn.cursor()
            
            # Key counts by type and status
            cursor.execute('''
                SELECT key_type, status, COUNT(*) as count
                FROM keys GROUP BY key_type, status
            ''')
            type_status_counts = cursor.fetchall()
            
            # Total keys
            cursor.execute('SELECT COUNT(*) FROM keys')
            total_keys = cursor.fetchone()[0]
            
            # Active keys
            cursor.execute('SELECT COUNT(*) FROM keys WHERE status = ?', (KeyStatus.ACTIVE,))
            active_keys = cursor.fetchone()[0]
            
            # Keys expiring in next 30 days
            cursor.execute('''
                SELECT COUNT(*) FROM keys 
                WHERE expires_at IS NOT NULL 
                AND expires_at <= datetime('now', '+30 days')
                AND status = ?
            ''', (KeyStatus.ACTIVE,))
            expiring_keys = cursor.fetchone()[0]
            
            # Key usage in last 24 hours
            cursor.execute('''
                SELECT COUNT(*) FROM key_usage_log
                WHERE timestamp >= datetime('now', '-24 hours')
            ''')
            usage_24h = cursor.fetchone()[0]
            
            conn.close()
            
            # Format statistics
            stats = {
                'total_keys': total_keys,
                'active_keys': active_keys,
                'expiring_soon': expiring_keys,
                'usage_24h': usage_24h,
                'key_distribution': {}
            }
            
            for key_type, status, count in type_status_counts:
                if key_type not in stats['key_distribution']:
                    stats['key_distribution'][key_type] = {}
                stats['key_distribution'][key_type][status] = count
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Failed to get statistics: {str(e)}")
            return {}
    
    def _store_key(self, key_id: str, key_type: str, key_data: Dict[str, Any],
                  metadata: Dict[str, Any], status: str = KeyStatus.ACTIVE,
                  expires_at: Optional[datetime] = None, parent_key_id: Optional[str] = None):
        """Store key in database"""
        conn = sqlite3.connect(self.database_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO keys (key_id, key_type, key_data, key_metadata, status, expires_at, parent_key_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            key_id, key_type, json.dumps(key_data), json.dumps(metadata),
            status, expires_at, parent_key_id
        ))
        
        conn.commit()
        conn.close()
    
    def _update_key_status(self, key_id: str, status: str):
        """Update key status"""
        conn = sqlite3.connect(self.database_path)
        cursor = conn.cursor()
        
        cursor.execute('UPDATE keys SET status = ? WHERE key_id = ?', (status, key_id))
        
        conn.commit()
        conn.close()
    
    def _update_key_usage(self, key_id: str):
        """Update key last used timestamp"""
        conn = sqlite3.connect(self.database_path)
        cursor = conn.cursor()
        
        cursor.execute('UPDATE keys SET last_used = CURRENT_TIMESTAMP WHERE key_id = ?', (key_id,))
        
        conn.commit()
        conn.close()
    
    def _log_key_usage(self, key_id: str, operation: str, success: bool):
        """Log key usage"""
        conn = sqlite3.connect(self.database_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO key_usage_log (key_id, operation, success)
            VALUES (?, ?, ?)
        ''', (key_id, operation, success))
        
        conn.commit()
        conn.close()
    
    def _calculate_key_fingerprint(self, key_data: Any) -> str:
        """Calculate fingerprint for key data"""
        if isinstance(key_data, dict):
            # Hash the serialized representation
            serialized = json.dumps(key_data, sort_keys=True).encode('utf-8')
        else:
            serialized = str(key_data).encode('utf-8')
        
        return hashlib.sha256(serialized).hexdigest()

# Utility functions
def initialize_key_manager(database_path: str, master_password: str) -> KeyManager:
    """
    Initialize key manager with secure setup
    
    Args:
        database_path: Path to key database
        master_password: Master password for encryption
        
    Returns:
        Initialized KeyManager instance
    """
    return KeyManager(database_path, master_password)

def create_emergency_recovery_key(backup_path: str) -> str:
    """
    Create emergency recovery key for disaster recovery
    
    Args:
        backup_path: Path to store recovery key
        
    Returns:
        Recovery key identifier
    """
    import secrets
    
    recovery_key = secrets.token_hex(32)
    recovery_info = {
        'key': recovery_key,
        'created_at': datetime.utcnow().isoformat(),
        'purpose': 'emergency_recovery'
    }
    
    with open(backup_path, 'w') as f:
        json.dump(recovery_info, f)
    
    return recovery_key