"""
JWT Token Handler for Enterprise Authentication
Implements secure JWT generation, validation, and lifecycle management
"""

import jwt
import time
import uuid
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.asymmetric.padding import PSS, MGF1

class TokenType(Enum):
    """JWT token types"""
    ACCESS = "access"
    REFRESH = "refresh"
    ID = "id"
    SESSION = "session"

class TokenStatus(Enum):
    """Token status definitions"""
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    BLACKLISTED = "blacklisted"

class SecurityContext:
    """Security context for token generation"""
    def __init__(self, user_id: str, roles: List[str], permissions: List[str],
                 device_id: str, ip_address: str, user_agent: str):
        self.user_id = user_id
        self.roles = roles
        self.permissions = permissions
        self.device_id = device_id
        self.ip_address = ip_address
        self.user_agent = user_agent
        self.timestamp = datetime.utcnow()

class JWTHandler:
    """
    Enterprise JWT Token Handler
    Implements secure JWT token management with advanced security features
    """
    
    def __init__(self, private_key_pem: Optional[bytes] = None, 
                 public_key_pem: Optional[bytes] = None,
                 algorithm: str = "RS256",
                 issuer: str = "security_framework"):
        """
        Initialize JWT Handler
        
        Args:
            private_key_pem: PEM-encoded private key for signing
            public_key_pem: PEM-encoded public key for verification
            algorithm: JWT signing algorithm
            issuer: Token issuer identifier
        """
        self.algorithm = algorithm
        self.issuer = issuer
        self.logger = logging.getLogger(__name__)
        
        # Generate or use provided keys
        if private_key_pem and public_key_pem:
            self.private_key = serialization.load_pem_private_key(
                private_key_pem, password=None, backend=default_backend()
            )
            self.public_key = serialization.load_pem_public_key(
                public_key_pem, backend=default_backend()
            )
        else:
            # Generate new RSA key pair
            self.private_key, self.public_key = self._generate_key_pair()
            self.logger.warning("Generated new JWT key pair - secure key management required")
        
        # Token configuration
        self.token_config = {
            TokenType.ACCESS: {"lifetime_minutes": 15},
            TokenType.REFRESH: {"lifetime_hours": 24 * 7},  # 7 days
            TokenType.ID: {"lifetime_minutes": 60},
            TokenType.SESSION: {"lifetime_hours": 8}
        }
        
        # Security settings
        self.clock_skew_tolerance = 30  # seconds
        self.enable_audience_validation = True
        self.enable_jti_blacklist = True
        
        # Blacklisted token tracking
        self._blacklisted_tokens: Dict[str, Dict[str, Any]] = {}
        self._token_store: Dict[str, Dict[str, Any]] = {}
    
    def _generate_key_pair(self) -> tuple:
        """Generate RSA key pair for JWT signing"""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        public_key = private_key.public_key()
        return private_key, public_key
    
    def generate_token(self, security_context: SecurityContext, 
                      token_type: TokenType = TokenType.ACCESS,
                      custom_claims: Optional[Dict[str, Any]] = None) -> str:
        """
        Generate JWT token with security context
        
        Args:
            security_context: Security context information
            token_type: Type of token to generate
            custom_claims: Additional custom claims
            
        Returns:
            JWT token string
        """
        try:
            now = datetime.utcnow()
            
            # Get token configuration
            config = self.token_config[token_type]
            
            # Calculate expiration
            if 'lifetime_minutes' in config:
                exp = now + timedelta(minutes=config['lifetime_minutes'])
            elif 'lifetime_hours' in config:
                exp = now + timedelta(hours=config['lifetime_hours'])
            else:
                exp = now + timedelta(minutes=15)  # Default
            
            # Create standard claims
            claims = {
                'iss': self.issuer,
                'sub': security_context.user_id,
                'aud': f"{self.issuer}_{token_type.value}",
                'iat': now,
                'exp': exp,
                'jti': str(uuid.uuid4()),
                'ctx': {
                    'roles': security_context.roles,
                    'permissions': security_context.permissions,
                    'device_id': security_context.device_id,
                    'ip_address': security_context.ip_address,
                    'user_agent': security_context.user_agent
                }
            }
            
            # Add token type specific claims
            if token_type == TokenType.ACCESS:
                claims['typ'] = 'access'
                claims['scope'] = ' '.join(security_context.permissions)
            elif token_type == TokenType.REFRESH:
                claims['typ'] = 'refresh'
                # Reference to the access token
                claims['ref'] = str(uuid.uuid4())
            elif token_type == TokenType.ID:
                claims['typ'] = 'id'
                # Include user identity information
                claims['name'] = security_context.user_id
                claims['email'] = f"{security_context.user_id}@example.com"
            
            # Add custom claims
            if custom_claims:
                claims.update(custom_claims)
            
            # Generate token
            token = jwt.encode(claims, self.private_key, algorithm=self.algorithm)
            
            # Store token information
            token_info = {
                'token': token,
                'type': token_type.value,
                'user_id': security_context.user_id,
                'created_at': now.isoformat(),
                'expires_at': exp.isoformat(),
                'jti': claims['jti'],
                'status': TokenStatus.ACTIVE.value,
                'security_context': {
                    'device_id': security_context.device_id,
                    'ip_address': security_context.ip_address,
                    'user_agent': security_context.user_agent
                }
            }
            
            self._token_store[claims['jti']] = token_info
            
            self.logger.info(f"JWT token generated: {claims['jti']} for user {security_context.user_id}")
            return token
            
        except Exception as e:
            self.logger.error(f"JWT token generation failed: {str(e)}")
            raise
    
    def validate_token(self, token: str, token_type: Optional[TokenType] = None,
                      audience: Optional[str] = None) -> Dict[str, Any]:
        """
        Validate JWT token
        
        Args:
            token: JWT token to validate
            token_type: Expected token type
            audience: Expected audience
            
        Returns:
            Token claims if valid
        """
        try:
            # Decode token
            try:
                claims = jwt.decode(
                    token,
                    self.public_key,
                    algorithms=[self.algorithm],
                    audience=audience or f"{self.issuer}_{token_type.value if token_type else ''}",
                    issuer=self.issuer,
                    options={
                        'verify_signature': True,
                        'verify_exp': True,
                        'verify_iat': True,
                        'verify_aud': self.enable_audience_validation
                    }
                )
            except jwt.ExpiredSignatureError:
                raise ValueError("Token has expired")
            except jwt.InvalidTokenError as e:
                raise ValueError(f"Invalid token: {str(e)}")
            
            # Get token info from store
            jti = claims.get('jti')
            if jti and jti in self._token_store:
                token_info = self._token_store[jti]
                
                # Check if token is blacklisted
                if token_info['status'] == TokenStatus.BLACKLISTED.value:
                    raise ValueError("Token is blacklisted")
                
                # Validate token type
                if token_type and token_info['type'] != token_type.value:
                    raise ValueError(f"Invalid token type: expected {token_type.value}, got {token_info['type']}")
                
                # Validate audience
                if audience and claims.get('aud') != audience:
                    raise ValueError(f"Invalid audience: expected {audience}, got {claims.get('aud')}")
            
            self.logger.info(f"JWT token validated successfully: {jti}")
            return claims
            
        except Exception as e:
            self.logger.error(f"JWT token validation failed: {str(e)}")
            raise
    
    def refresh_token(self, refresh_token: str) -> str:
        """
        Refresh access token using refresh token
        
        Args:
            refresh_token: Refresh token to use
            
        Returns:
            New access token
        """
        try:
            # Validate refresh token
            claims = self.validate_token(refresh_token, TokenType.REFRESH)
            
            # Get original security context
            jti = claims.get('jti')
            if jti and jti in self._token_store:
                token_info = self._token_store[jti]
                user_id = token_info['user_id']
                security_context_data = token_info['security_context']
                
                # Create new security context
                security_context = SecurityContext(
                    user_id=user_id,
                    roles=token_info.get('roles', []),
                    permissions=token_info.get('permissions', []),
                    device_id=security_context_data['device_id'],
                    ip_address=security_context_data['ip_address'],
                    user_agent=security_context_data['user_agent']
                )
                
                # Generate new access token
                new_access_token = self.generate_token(security_context, TokenType.ACCESS)
                
                # Mark refresh token as used
                self._token_store[jti]['status'] = TokenStatus.EXPIRED.value
                
                self.logger.info(f"Token refreshed: {jti} for user {user_id}")
                return new_access_token
            else:
                raise ValueError("Refresh token not found or invalid")
                
        except Exception as e:
            self.logger.error(f"Token refresh failed: {str(e)}")
            raise
    
    def revoke_token(self, jti: str, reason: str = "manual_revocation") -> bool:
        """
        Revoke token by JTI
        
        Args:
            jti: JWT ID to revoke
            reason: Reason for revocation
            
        Returns:
            True if revocation successful
        """
        try:
            if jti in self._token_store:
                self._token_store[jti]['status'] = TokenStatus.REVOKED.value
                self._blacklisted_tokens[jti] = {
                    'reason': reason,
                    'revoked_at': datetime.utcnow().isoformat()
                }
                
                self.logger.info(f"JWT token revoked: {jti}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Token revocation failed: {str(e)}")
            return False
    
    def blacklist_token(self, token: str, reason: str = "security_incident") -> bool:
        """
        Blacklist token to prevent further use
        
        Args:
            token: Token to blacklist
            reason: Reason for blacklisting
            
        Returns:
            True if blacklisting successful
        """
        try:
            # Decode token to get JTI (without verification to handle compromised tokens)
            try:
                unverified = jwt.decode(token, options={"verify_signature": False})
                jti = unverified.get('jti')
                
                if jti and jti in self._token_store:
                    self._token_store[jti]['status'] = TokenStatus.BLACKLISTED.value
                    self._blacklisted_tokens[jti] = {
                        'reason': reason,
                        'blacklisted_at': datetime.utcnow().isoformat(),
                        'original_token': token[:20] + "..."  # Don't store full token
                    }
                    
                    self.logger.info(f"JWT token blacklisted: {jti}")
                    return True
                
            except Exception:
                # Token might be malformed, attempt to extract JTI manually
                pass
            
            return False
            
        except Exception as e:
            self.logger.error(f"Token blacklisting failed: {str(e)}")
            return False
    
    def get_token_info(self, jti: str) -> Optional[Dict[str, Any]]:
        """
        Get token information by JTI
        
        Args:
            jti: JWT ID
            
        Returns:
            Token information or None
        """
        return self._token_store.get(jti)
    
    def list_user_tokens(self, user_id: str) -> List[Dict[str, Any]]:
        """
        List all tokens for a user
        
        Args:
            user_id: User identifier
            
        Returns:
            List of token information
        """
        user_tokens = []
        for token_info in self._token_store.values():
            if token_info['user_id'] == user_id:
                user_tokens.append(token_info)
        
        return user_tokens
    
    def cleanup_expired_tokens(self) -> int:
        """
        Clean up expired and revoked tokens
        
        Returns:
            Number of tokens cleaned up
        """
        try:
            now = datetime.utcnow()
            cleanup_count = 0
            
            # Remove expired tokens from token store
            expired_jtis = []
            for jti, token_info in self._token_store.items():
                try:
                    expires_at = datetime.fromisoformat(token_info['expires_at'])
                    if expires_at < now - timedelta(hours=1):  # Give 1 hour grace period
                        expired_jtis.append(jti)
                except Exception:
                    # Invalid date format, remove it
                    expired_jtis.append(jti)
            
            for jti in expired_jtis:
                del self._token_store[jti]
                cleanup_count += 1
            
            # Keep blacklisted tokens for audit trail
            # But limit the blacklist size
            max_blacklist_size = 10000
            if len(self._blacklisted_tokens) > max_blacklist_size:
                # Remove oldest entries
                sorted_blacklist = sorted(
                    self._blacklisted_tokens.items(),
                    key=lambda x: x[1].get('blacklisted_at', '')
                )
                
                for jti, _ in sorted_blacklist[:len(sorted_blacklist) - max_blacklist_size]:
                    del self._blacklisted_tokens[jti]
                    cleanup_count += 1
            
            self.logger.info(f"Cleaned up {cleanup_count} expired tokens")
            return cleanup_count
            
        except Exception as e:
            self.logger.error(f"Token cleanup failed: {str(e)}")
            return 0
    
    def rotate_keys(self) -> Dict[str, Any]:
        """
        Rotate signing keys for enhanced security
        
        Returns:
            Key rotation status
        """
        try:
            # Generate new key pair
            new_private_key, new_public_key = self._generate_key_pair()
            
            # Store current keys as "old" keys (for key rotation transition)
            # In a production system, you would implement a proper key rollover mechanism
            
            # Update current keys
            self.private_key = new_private_key
            self.public_key = new_public_key
            
            rotation_info = {
                'status': 'success',
                'timestamp': datetime.utcnow().isoformat(),
                'algorithm': self.algorithm,
                'keys_rotated': True
            }
            
            self.logger.info("JWT signing keys rotated successfully")
            return rotation_info
            
        except Exception as e:
            self.logger.error(f"Key rotation failed: {str(e)}")
            raise
    
    def export_public_key(self) -> str:
        """
        Export public key in PEM format
        
        Returns:
            Public key as PEM-encoded string
        """
        return self.public_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode('utf-8')
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get token statistics
        
        Returns:
            Statistics dictionary
        """
        try:
            now = datetime.utcnow()
            
            # Count tokens by status
            status_counts = {}
            for token_info in self._token_store.values():
                status = token_info['status']
                status_counts[status] = status_counts.get(status, 0) + 1
            
            # Count tokens by type
            type_counts = {}
            for token_info in self._token_store.values():
                token_type = token_info['type']
                type_counts[token_type] = type_counts.get(token_type, 0) + 1
            
            # Calculate expiry statistics
            expiring_tokens = 0
            for token_info in self._token_store.values():
                try:
                    expires_at = datetime.fromisoformat(token_info['expires_at'])
                    if expires_at > now and expires_at < now + timedelta(minutes=15):
                        expiring_tokens += 1
                except Exception:
                    pass
            
            statistics = {
                'total_tokens': len(self._token_store),
                'status_distribution': status_counts,
                'type_distribution': type_counts,
                'expiring_soon': expiring_tokens,
                'blacklisted_tokens': len(self._blacklisted_tokens),
                'issuer': self.issuer,
                'algorithm': self.algorithm
            }
            
            return statistics
            
        except Exception as e:
            self.logger.error(f"Failed to get statistics: {str(e)}")
            return {}

# Utility functions
def create_security_context(user_id: str, roles: List[str], permissions: List[str],
                          device_id: str, ip_address: str, user_agent: str) -> SecurityContext:
    """
    Create security context for token generation
    
    Args:
        user_id: User identifier
        roles: User roles
        permissions: User permissions
        device_id: Device identifier
        ip_address: Client IP address
        user_agent: Client user agent
        
    Returns:
        SecurityContext instance
    """
    return SecurityContext(user_id, roles, permissions, device_id, ip_address, user_agent)

def decode_jwt_without_validation(token: str) -> Dict[str, Any]:
    """
    Decode JWT token without validation (for debugging and logging)
    
    Args:
        token: JWT token to decode
        
    Returns:
        Token claims (unverified)
    """
    try:
        return jwt.decode(token, options={"verify_signature": False})
    except Exception as e:
        logging.error(f"JWT decode failed: {str(e)}")
        return {}

def is_jwt_expired(token: str) -> bool:
    """
    Check if JWT token is expired without full validation
    
    Args:
        token: JWT token to check
        
    Returns:
        True if token is expired
    """
    try:
        unverified = jwt.decode(token, options={"verify_signature": False})
        exp = unverified.get('exp')
        if exp:
            return time.time() > exp
        return True
    except Exception:
        return True