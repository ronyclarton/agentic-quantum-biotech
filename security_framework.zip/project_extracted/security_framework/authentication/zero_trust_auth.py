"""
Zero-Trust Authentication System
Enterprise-grade zero-trust architecture with comprehensive security features
"""

import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from enum import Enum

from .jwt_handler import JWTHandler, SecurityContext, TokenType
from .oauth2_provider import OAuth2Provider
from .mfa_manager import MFAManager, MFAMethod, MFAMethod as AuthMethod

class TrustLevel(Enum):
    """Trust levels for zero-trust evaluation"""
    UNKNOWN = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    VERIFIED = 4

class AuthenticationResult(Enum):
    """Authentication result types"""
    SUCCESS = "success"
    FAILED = "failed"
    MFA_REQUIRED = "mfa_required"
    PARTIAL = "partial"
    EXPIRED = "expired"

class SecurityEvent(Enum):
    """Security event types"""
    LOGIN_SUCCESS = "login_success"
    LOGIN_FAILED = "login_failed"
    MFA_SUCCESS = "mfa_success"
    MFA_FAILED = "mfa_failed"
    SUSPICIOUS_ACTIVITY = "suspicious_activity"
    POLICY_VIOLATION = "policy_violation"
    TOKEN_REVOKED = "token_revoked"

class ZeroTrustAuth:
    """
    Zero-Trust Authentication System
    Implements enterprise-grade zero-trust security architecture
    """
    
    def __init__(self, jwt_handler: JWTHandler, oauth2_provider: OAuth2Provider,
                 mfa_manager: MFAManager, issuer: str = "security_framework_zerotrust"):
        """
        Initialize Zero-Trust Authentication System
        
        Args:
            jwt_handler: JWT token handler
            oauth2_provider: OAuth2 provider
            mfa_manager: MFA manager
            issuer: System issuer identifier
        """
        self.jwt_handler = jwt_handler
        self.oauth2_provider = oauth2_provider
        self.mfa_manager = mfa_manager
        self.issuer = issuer
        self.logger = logging.getLogger(__name__)
        
        # Zero-trust configuration
        self.max_login_attempts = 5
        self.lockout_duration_minutes = 30
        self.session_timeout_minutes = 30
        self.continuous_authentication = True
        self.risk_based_authentication = True
        
        # Security policies
        self._login_attempts: Dict[str, Dict[str, Any]] = {}
        self._user_sessions: Dict[str, Dict[str, Any]] = {}
        self._security_events: List[Dict[str, Any]] = []
        self._trust_scores: Dict[str, float] = {}
        
        self.logger.info("Zero-Trust Authentication System initialized")
    
    def authenticate_user(self, username: str, password: str,
                         device_info: Optional[Dict[str, Any]] = None,
                         context_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Authenticate user with zero-trust evaluation
        
        Args:
            username: Username
            password: Password
            device_info: Device information
            context_data: Additional context data
            
        Returns:
            Authentication result
        """
        try:
            # Initial authentication
            auth_result = self._perform_primary_authentication(username, password)
            
            if auth_result['status'] != AuthenticationResult.SUCCESS:
                return auth_result
            
            # Zero-trust evaluation
            trust_evaluation = self._evaluate_trust_level(username, device_info, context_data)
            
            # Determine if MFA is required
            mfa_required = self._determine_mfa_requirement(trust_evaluation, username)
            
            if mfa_required:
                # Generate MFA challenge
                mfa_challenge = self._generate_mfa_challenge(username, trust_evaluation['risk_score'])
                
                return {
                    'status': AuthenticationResult.MFA_REQUIRED,
                    'mfa_challenge': mfa_challenge,
                    'trust_level': trust_evaluation['level'],
                    'risk_score': trust_evaluation['risk_score'],
                    'session_id': self._create_session(username, trust_evaluation),
                    'next_mfa_method': mfa_challenge.get('preferred_method')
                }
            
            # Complete authentication without MFA
            return self._complete_authentication(username, trust_evaluation, device_info)
            
        except Exception as e:
            self.logger.error(f"Authentication failed: {str(e)}")
            return {
                'status': AuthenticationResult.FAILED,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    def verify_mfa(self, username: str, mfa_token: str, mfa_method: MFAMethod,
                  session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Verify MFA and complete authentication
        
        Args:
            username: Username
            mfa_token: MFA token/code
            mfa_method: MFA method used
            session_id: Session identifier
            
        Returns:
            MFA verification result
        """
        try:
            # Verify MFA
            mfa_authenticated = self.mfa_manager.authenticate_mfa(
                username, mfa_method, {'token': mfa_token}
            )
            
            if not mfa_authenticated:
                self._log_security_event(
                    username, SecurityEvent.MFA_FAILED,
                    f"MFA failed for method: {mfa_method.value}"
                )
                return {
                    'status': AuthenticationResult.FAILED,
                    'error': 'MFA verification failed'
                }
            
            # Log MFA success
            self._log_security_event(
                username, SecurityEvent.MFA_SUCCESS,
                f"MFA successful: {mfa_method.value}"
            )
            
            # Get trust evaluation from session or recalculate
            trust_evaluation = None
            if session_id:
                session_data = self._user_sessions.get(session_id)
                if session_data and session_data['username'] == username:
                    trust_evaluation = session_data['trust_evaluation']
            
            if not trust_evaluation:
                trust_evaluation = self._evaluate_trust_level(username)
            
            # Complete authentication
            return self._complete_authentication(username, trust_evaluation, mfa_method=mfa_method)
            
        except Exception as e:
            self.logger.error(f"MFA verification failed: {str(e)}")
            return {
                'status': AuthenticationResult.FAILED,
                'error': str(e)
            }
    
    def _perform_primary_authentication(self, username: str, password: str) -> Dict[str, Any]:
        """
        Perform primary authentication (username/password)
        
        Args:
            username: Username
            password: Password
            
        Returns:
            Authentication result
        """
        try:
            # Check account lockout
            if self._is_account_locked(username):
                return {
                    'status': AuthenticationResult.FAILED,
                    'error': 'Account is locked',
                    'locked_until': self._get_lockout_end_time(username)
                }
            
            # Simplified password verification (in production, use proper user database)
            if self._verify_password(username, password):
                # Reset login attempts on successful authentication
                self._reset_login_attempts(username)
                
                return {
                    'status': AuthenticationResult.SUCCESS,
                    'username': username
                }
            else:
                # Increment login attempts
                self._increment_login_attempts(username)
                
                return {
                    'status': AuthenticationResult.FAILED,
                    'error': 'Invalid credentials'
                }
                
        except Exception as e:
            self.logger.error(f"Primary authentication failed: {str(e)}")
            return {
                'status': AuthenticationResult.FAILED,
                'error': str(e)
            }
    
    def _evaluate_trust_level(self, username: str, device_info: Optional[Dict[str, Any]] = None,
                            context_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Evaluate trust level using zero-trust principles
        
        Args:
            username: Username
            device_info: Device information
            context_data: Additional context
            
        Returns:
            Trust evaluation result
        """
        try:
            risk_score = 0.0
            trust_indicators = []
            
            # Device fingerprinting
            device_fingerprint = self._get_device_fingerprint(device_info)
            device_trust = self._evaluate_device_trust(username, device_fingerprint)
            trust_indicators.append(('device_trust', device_trust))
            
            # IP address analysis
            ip_address = context_data.get('ip_address') if context_data else None
            ip_trust = self._evaluate_ip_trust(username, ip_address)
            trust_indicators.append(('ip_trust', ip_trust))
            
            # Behavioral analysis
            behavioral_score = self._analyze_behavior(username, device_info, context_data)
            trust_indicators.append(('behavioral', behavioral_score))
            
            # Time-based analysis
            time_score = self._analyze_access_time(username)
            trust_indicators.append(('time_based', time_score))
            
            # Historical context
            historical_score = self._analyze_historical_context(username)
            trust_indicators.append(('historical', historical_score))
            
            # Calculate overall risk score
            risk_score = 1.0 - (device_trust + ip_trust + behavioral_score + time_score + historical_score) / 5.0
            risk_score = max(0.0, min(1.0, risk_score))  # Clamp between 0 and 1
            
            # Determine trust level
            if risk_score <= 0.1:
                trust_level = TrustLevel.VERIFIED
            elif risk_score <= 0.3:
                trust_level = TrustLevel.HIGH
            elif risk_score <= 0.5:
                trust_level = TrustLevel.MEDIUM
            elif risk_score <= 0.7:
                trust_level = TrustLevel.LOW
            else:
                trust_level = TrustLevel.UNKNOWN
            
            # Store trust score
            self._trust_scores[username] = risk_score
            
            return {
                'level': trust_level,
                'risk_score': risk_score,
                'indicators': dict(trust_indicators),
                'device_fingerprint': device_fingerprint,
                'evaluated_at': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Trust evaluation failed: {str(e)}")
            return {
                'level': TrustLevel.UNKNOWN,
                'risk_score': 1.0,
                'error': str(e)
            }
    
    def _determine_mfa_requirement(self, trust_evaluation: Dict[str, Any], username: str) -> bool:
        """
        Determine if MFA is required based on trust evaluation
        
        Args:
            trust_evaluation: Trust evaluation result
            username: Username
            
        Returns:
            True if MFA required
        """
        risk_score = trust_evaluation['risk_score']
        trust_level = trust_evaluation['level']
        
        # MFA required for low trust levels
        if trust_level in [TrustLevel.UNKNOWN, TrustLevel.LOW]:
            return True
        
        # Risk-based MFA requirement
        if risk_score > 0.5:
            return True
        
        # Always require MFA for administrative accounts
        if self._is_admin_account(username):
            return True
        
        # Check user's preferred MFA settings
        user_mfa_methods = self.mfa_manager.list_user_mfa_methods(username)
        if not user_mfa_methods:
            return True  # Require MFA enrollment
        
        return False
    
    def _generate_mfa_challenge(self, username: str, risk_score: float) -> Dict[str, Any]:
        """
        Generate MFA challenge based on risk and user preferences
        
        Args:
            username: Username
            risk_score: Risk score
            
        Returns:
            MFA challenge data
        """
        try:
            # Get user's enrolled MFA methods
            user_methods = self.mfa_manager.list_user_mfa_methods(username)
            enrolled_methods = [method['method'] for method in user_methods if method['status'] == 'enrolled']
            
            if not enrolled_methods:
                # Force TOTP enrollment
                return {
                    'type': 'enrollment_required',
                    'enrolled_methods': [],
                    'preferred_method': 'totp'
                }
            
            # Select MFA method based on risk score
            if risk_score > 0.8:
                # High risk: require strongest available method
                if 'fido2' in enrolled_methods:
                    preferred_method = 'fido2'
                elif 'totp' in enrolled_methods:
                    preferred_method = 'totp'
                else:
                    preferred_method = enrolled_methods[0]
            else:
                # Lower risk: allow user choice
                preferred_method = enrolled_methods[0] if enrolled_methods else 'totp'
            
            # Generate challenge based on method
            challenge_data = {
                'type': 'mfa_required',
                'enrolled_methods': enrolled_methods,
                'preferred_method': preferred_method,
                'challenge_id': f"mfa_{username}_{int(time.time())}",
                'expires_at': (datetime.utcnow() + timedelta(minutes=5)).isoformat()
            }
            
            return challenge_data
            
        except Exception as e:
            self.logger.error(f"MFA challenge generation failed: {str(e)}")
            return {
                'type': 'error',
                'error': str(e)
            }
    
    def _complete_authentication(self, username: str, trust_evaluation: Dict[str, Any],
                               device_info: Optional[Dict[str, Any]] = None,
                               mfa_method: Optional[MFAMethod] = None) -> Dict[str, Any]:
        """
        Complete authentication and generate tokens
        
        Args:
            username: Username
            trust_evaluation: Trust evaluation result
            device_info: Device information
            mfa_method: MFA method used
            
        Returns:
            Complete authentication result
        """
        try:
            # Create security context
            security_context = SecurityContext(
                user_id=username,
                roles=self._get_user_roles(username),
                permissions=self._get_user_permissions(username),
                device_id=device_info.get('device_id') if device_info else 'unknown',
                ip_address=device_info.get('ip_address') if device_info else '0.0.0.0',
                user_agent=device_info.get('user_agent') if device_info else 'unknown'
            )
            
            # Generate access token
            access_token = self.jwt_handler.generate_token(
                security_context, TokenType.ACCESS
            )
            
            # Generate refresh token
            refresh_token = self.jwt_handler.generate_token(
                security_context, TokenType.REFRESH
            )
            
            # Create session
            session_id = self._create_session(username, trust_evaluation, mfa_method)
            
            # Log successful authentication
            self._log_security_event(
                username, SecurityEvent.LOGIN_SUCCESS,
                f"Authentication completed. Trust level: {trust_evaluation['level'].name}"
            )
            
            return {
                'status': AuthenticationResult.SUCCESS,
                'access_token': access_token,
                'refresh_token': refresh_token,
                'session_id': session_id,
                'trust_level': trust_evaluation['level'].value,
                'risk_score': trust_evaluation['risk_score'],
                'expires_in': 900,  # 15 minutes
                'token_type': 'Bearer'
            }
            
        except Exception as e:
            self.logger.error(f"Authentication completion failed: {str(e)}")
            return {
                'status': AuthenticationResult.FAILED,
                'error': str(e)
            }
    
    def validate_session(self, token: str, session_id: str) -> Dict[str, Any]:
        """
        Validate user session with zero-trust continuous authentication
        
        Args:
            token: Access token
            session_id: Session identifier
            
        Returns:
            Session validation result
        """
        try:
            # Validate token
            claims = self.jwt_handler.validate_token(token)
            if not claims:
                return {
                    'valid': False,
                    'reason': 'Invalid token'
                }
            
            # Check session
            session_data = self._user_sessions.get(session_id)
            if not session_data:
                return {
                    'valid': False,
                    'reason': 'Session not found'
                }
            
            if session_data['username'] != claims.get('sub'):
                return {
                    'valid': False,
                    'reason': 'Session/user mismatch'
                }
            
            # Check session expiration
            if datetime.utcnow() > session_data['expires_at']:
                return {
                    'valid': False,
                    'reason': 'Session expired'
                }
            
            # Continuous authentication (if enabled)
            if self.continuous_authentication:
                re_evaluation = self._evaluate_trust_level(claims['sub'])
                
                # Check if trust level has degraded significantly
                if re_evaluation['risk_score'] > session_data['trust_evaluation']['risk_score'] + 0.3:
                    # Significant trust degradation - require re-authentication
                    return {
                        'valid': False,
                        'reason': 'Trust level degraded',
                        're_authentication_required': True,
                        'risk_score': re_evaluation['risk_score']
                    }
            
            # Update session activity
            session_data['last_activity'] = datetime.utcnow()
            
            return {
                'valid': True,
                'username': claims['sub'],
                'permissions': claims.get('ctx', {}).get('permissions', []),
                'risk_score': session_data['trust_evaluation']['risk_score']
            }
            
        except Exception as e:
            self.logger.error(f"Session validation failed: {str(e)}")
            return {
                'valid': False,
                'reason': str(e)
            }
    
    def revoke_session(self, username: str, session_id: str) -> bool:
        """
        Revoke user session
        
        Args:
            username: Username
            session_id: Session identifier
            
        Returns:
            True if revocation successful
        """
        try:
            session_data = self._user_sessions.get(session_id)
            if session_data and session_data['username'] == username:
                session_data['status'] = 'revoked'
                session_data['revoked_at'] = datetime.utcnow()
                
                self._log_security_event(
                    username, SecurityEvent.TOKEN_REVOKED,
                    f"Session revoked: {session_id}"
                )
                
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Session revocation failed: {str(e)}")
            return False
    
    def get_user_sessions(self, username: str) -> List[Dict[str, Any]]:
        """
        Get all active sessions for user
        
        Args:
            username: Username
            
        Returns:
            List of session information
        """
        sessions = []
        for session_id, session_data in self._user_sessions.items():
            if session_data['username'] == username and session_data['status'] == 'active':
                sessions.append({
                    'session_id': session_id,
                    'created_at': session_data['created_at'].isoformat(),
                    'last_activity': session_data['last_activity'].isoformat(),
                    'expires_at': session_data['expires_at'].isoformat(),
                    'trust_level': session_data['trust_evaluation']['level'].name,
                    'risk_score': session_data['trust_evaluation']['risk_score']
                })
        
        return sessions
    
    def _create_session(self, username: str, trust_evaluation: Dict[str, Any],
                      mfa_method: Optional[MFAMethod] = None) -> str:
        """Create user session"""
        session_id = f"session_{username}_{int(time.time())}"
        
        session_data = {
            'session_id': session_id,
            'username': username,
            'created_at': datetime.utcnow(),
            'last_activity': datetime.utcnow(),
            'expires_at': datetime.utcnow() + timedelta(minutes=self.session_timeout_minutes),
            'status': 'active',
            'trust_evaluation': trust_evaluation,
            'mfa_method': mfa_method.value if mfa_method else None
        }
        
        self._user_sessions[session_id] = session_data
        return session_id
    
    # Simplified implementations (in production, use proper user database)
    def _verify_password(self, username: str, password: str) -> bool:
        """Verify user password (simplified)"""
        # In production, use proper password hashing and user database
        return password == f"{username}_password"  # Demo only
    
    def _get_user_roles(self, username: str) -> List[str]:
        """Get user roles (simplified)"""
        # In production, get from user database
        return ['user']
    
    def _get_user_permissions(self, username: str) -> List[str]:
        """Get user permissions (simplified)"""
        # In production, get from user database
        return ['read', 'write']
    
    def _is_admin_account(self, username: str) -> bool:
        """Check if user is admin (simplified)"""
        return username.startswith('admin_')
    
    def _get_device_fingerprint(self, device_info: Optional[Dict[str, Any]]) -> str:
        """Get device fingerprint"""
        if not device_info:
            return 'unknown'
        
        # Create fingerprint from available device info
        fingerprint_data = f"{device_info.get('user_agent', '')}{device_info.get('screen_resolution', '')}"
        import hashlib
        return hashlib.md5(fingerprint_data.encode()).hexdigest()
    
    def _evaluate_device_trust(self, username: str, device_fingerprint: str) -> float:
        """Evaluate device trust"""
        # Check if this device has been used before
        # Simplified implementation
        if device_fingerprint == 'known_device':
            return 0.9  # High trust for known device
        else:
            return 0.5  # Medium trust for unknown device
    
    def _evaluate_ip_trust(self, username: str, ip_address: Optional[str]) -> float:
        """Evaluate IP address trust"""
        # Check if IP is from trusted location
        # Simplified implementation
        if not ip_address:
            return 0.5
        
        # Known IP ranges get higher trust
        trusted_ranges = ['127.0.0.1', '192.168.1.', '10.0.0.']
        for trusted_range in trusted_ranges:
            if ip_address.startswith(trusted_range):
                return 0.9
        
        return 0.6
    
    def _analyze_behavior(self, username: str, device_info: Optional[Dict[str, Any]],
                        context_data: Optional[Dict[str, Any]]) -> float:
        """Analyze user behavior patterns"""
        # Analyze login patterns, time of day, etc.
        # Simplified implementation
        return 0.7  # Good behavior score
    
    def _analyze_access_time(self, username: str) -> float:
        """Analyze access time patterns"""
        current_hour = datetime.utcnow().hour
        
        # Higher trust during business hours
        if 9 <= current_hour <= 17:
            return 0.8
        else:
            return 0.6
    
    def _analyze_historical_context(self, username: str) -> float:
        """Analyze historical access patterns"""
        # Check user's historical access patterns
        # Simplified implementation
        return 0.75
    
    def _is_account_locked(self, username: str) -> bool:
        """Check if account is locked"""
        attempts = self._login_attempts.get(username)
        if not attempts:
            return False
        
        return (attempts['count'] >= self.max_login_attempts and 
                datetime.utcnow() < attempts['lockout_until'])
    
    def _get_lockout_end_time(self, username: str) -> Optional[datetime]:
        """Get account lockout end time"""
        attempts = self._login_attempts.get(username)
        return attempts.get('lockout_until') if attempts else None
    
    def _increment_login_attempts(self, username: str):
        """Increment login attempts"""
        if username not in self._login_attempts:
            self._login_attempts[username] = {'count': 0, 'first_attempt': datetime.utcnow()}
        
        attempts = self._login_attempts[username]
        attempts['count'] += 1
        
        if attempts['count'] >= self.max_login_attempts:
            attempts['lockout_until'] = datetime.utcnow() + timedelta(minutes=self.lockout_duration_minutes)
    
    def _reset_login_attempts(self, username: str):
        """Reset login attempts"""
        if username in self._login_attempts:
            del self._login_attempts[username]
    
    def _log_security_event(self, username: str, event_type: SecurityEvent, description: str):
        """Log security event"""
        event = {
            'username': username,
            'event_type': event_type.value,
            'description': description,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        self._security_events.append(event)
        
        # Limit security events log size
        if len(self._security_events) > 10000:
            self._security_events = self._security_events[-5000:]
        
        # Log to application logger
        self.logger.info(f"Security Event: {username} - {event_type.value} - {description}")
    
    def get_security_statistics(self) -> Dict[str, Any]:
        """Get zero-trust security statistics"""
        try:
            # Count active sessions
            active_sessions = len([s for s in self._user_sessions.values() if s['status'] == 'active'])
            
            # Count locked accounts
            locked_accounts = len([a for a in self._login_attempts.values() 
                                 if a['count'] >= self.max_login_attempts and
                                 datetime.utcnow() < a['lockout_until']])
            
            # Count recent security events
            recent_events = len([e for e in self._security_events 
                               if datetime.fromisoformat(e['timestamp']) > datetime.utcnow() - timedelta(days=1)])
            
            # Average trust score
            trust_scores = list(self._trust_scores.values())
            avg_trust_score = sum(trust_scores) / len(trust_scores) if trust_scores else 0.0
            
            statistics = {
                'active_sessions': active_sessions,
                'locked_accounts': locked_accounts,
                'recent_security_events': recent_events,
                'average_trust_score': avg_trust_score,
                'total_login_attempts': len(self._login_attempts)
            }
            
            return statistics
            
        except Exception as e:
            self.logger.error(f"Failed to get security statistics: {str(e)}")
            return {}
