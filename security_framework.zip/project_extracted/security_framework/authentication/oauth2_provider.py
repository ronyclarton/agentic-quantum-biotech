"""
OAuth2 Provider Implementation
Enterprise-grade OAuth2 server with advanced security features
"""

import secrets
import time
import hashlib
import base64
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from urllib.parse import urlparse, parse_qs
import json

from .jwt_handler import JWTHandler, SecurityContext, TokenType

class GrantType(Enum):
    """OAuth2 grant types"""
    AUTHORIZATION_CODE = "authorization_code"
    IMPLICIT = "implicit"
    RESOURCE_OWNER_PASSWORD_CREDENTIALS = "password"
    CLIENT_CREDENTIALS = "client_credentials"
    REFRESH_TOKEN = "refresh_token"

class ResponseType(Enum):
    """OAuth2 response types"""
    CODE = "code"
    TOKEN = "token"
    ID_TOKEN = "id_token"
    CODE_TOKEN = "code token"
    ID_TOKEN_TOKEN = "id_token token"
    CODE_ID_TOKEN = "code id_token"
    CODE_TOKEN_ID_TOKEN = "code token id_token"

class ClientType(Enum):
    """OAuth2 client types"""
    CONFIDENTIAL = "confidential"
    PUBLIC = "public"

class AuthorizationScope(Enum):
    """Predefined OAuth2 scopes"""
    OPENID = "openid"
    PROFILE = "profile"
    EMAIL = "email"
    READ = "read"
    WRITE = "write"
    ADMIN = "admin"

class OAuth2Provider:
    """
    Enterprise OAuth2 Provider
    Implements OAuth2 authorization server with advanced security features
    """
    
    def __init__(self, jwt_handler: JWTHandler, issuer: str = "security_framework_oauth"):
        """
        Initialize OAuth2 Provider
        
        Args:
            jwt_handler: JWT handler for token generation
            issuer: OAuth2 issuer identifier
        """
        self.jwt_handler = jwt_handler
        self.issuer = issuer
        self.logger = logging.getLogger(__name__)
        
        # OAuth2 configuration
        self.authorization_code_lifetime = timedelta(minutes=10)
        self.access_token_lifetime = timedelta(minutes=15)
        self.refresh_token_lifetime = timedelta(days=7)
        self.id_token_lifetime = timedelta(minutes=15)
        
        # Security settings
        self.enable_pkce = True
        self.enable_state_validation = True
        self.max_authorization_codes = 1000
        self.max_access_tokens = 10000
        
        # Data stores (in production, use database)
        self._clients: Dict[str, Dict[str, Any]] = {}
        self._authorization_codes: Dict[str, Dict[str, Any]] = {}
        self._access_tokens: Dict[str, Dict[str, Any]] = {}
        self._refresh_tokens: Dict[str, Dict[str, Any]] = {}
        self._consent_records: Dict[str, Dict[str, Any]] = {}
        
        # Predefined scopes
        self._scopes = {
            'openid': 'OpenID Connect',
            'profile': 'User profile information',
            'email': 'User email address',
            'read': 'Read access',
            'write': 'Write access',
            'admin': 'Administrative access'
        }
        
        self._initialize_default_client()
    
    def _initialize_default_client(self):
        """Initialize default client for testing"""
        client_id = secrets.token_urlsafe(32)
        client_secret = secrets.token_urlsafe(32)
        
        default_client = {
            'client_id': client_id,
            'client_secret': client_secret,
            'client_name': 'Security Framework Default Client',
            'client_type': ClientType.CONFIDENTIAL.value,
            'redirect_uris': ['http://localhost:8000/callback'],
            'grant_types': [GrantType.AUTHORIZATION_CODE.value, GrantType.CLIENT_CREDENTIALS.value],
            'response_types': [ResponseType.CODE.value],
            'scopes': list(self._scopes.keys()),
            'created_at': datetime.utcnow().isoformat(),
            'status': 'active'
        }
        
        self._clients[client_id] = default_client
        self.logger.info(f"Default OAuth2 client initialized: {client_id}")
    
    def register_client(self, client_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Register new OAuth2 client
        
        Args:
            client_data: Client registration data
            
        Returns:
            Client registration response
        """
        try:
            # Generate client credentials
            client_id = secrets.token_urlsafe(32)
            client_secret = secrets.token_urlsafe(32)
            
            # Validate client data
            required_fields = ['client_name', 'client_type', 'redirect_uris']
            for field in required_fields:
                if field not in client_data:
                    raise ValueError(f"Required field missing: {field}")
            
            if client_data['client_type'] not in [ct.value for ct in ClientType]:
                raise ValueError("Invalid client type")
            
            # Create client record
            client = {
                'client_id': client_id,
                'client_secret': client_secret if client_data['client_type'] == ClientType.CONFIDENTIAL.value else None,
                'client_name': client_data['client_name'],
                'client_type': client_data['client_type'],
                'redirect_uris': client_data['redirect_uris'],
                'grant_types': client_data.get('grant_types', []),
                'response_types': client_data.get('response_types', []),
                'scopes': client_data.get('scopes', []),
                'created_at': datetime.utcnow().isoformat(),
                'status': 'active'
            }
            
            # Store client
            self._clients[client_id] = client
            
            self.logger.info(f"OAuth2 client registered: {client_id}")
            
            # Return client information (don't expose secret in production response)
            response = {
                'client_id': client_id,
                'client_secret': client_secret,  # Only returned once
                'client_name': client['client_name'],
                'client_type': client['client_type'],
                'redirect_uris': client['redirect_uris'],
                'grant_types': client['grant_types'],
                'response_types': client['response_types'],
                'scopes': client['scopes']
            }
            
            return response
            
        except Exception as e:
            self.logger.error(f"Client registration failed: {str(e)}")
            raise
    
    def validate_client(self, client_id: str, client_secret: Optional[str] = None,
                       redirect_uri: Optional[str] = None) -> bool:
        """
        Validate OAuth2 client credentials
        
        Args:
            client_id: Client identifier
            client_secret: Client secret (for confidential clients)
            redirect_uri: Redirect URI to validate
            
        Returns:
            True if client is valid
        """
        try:
            client = self._clients.get(client_id)
            if not client or client['status'] != 'active':
                return False
            
            # Validate client secret for confidential clients
            if client['client_type'] == ClientType.CONFIDENTIAL.value:
                if not client_secret or client_secret != client['client_secret']:
                    return False
            
            # Validate redirect URI if provided
            if redirect_uri and redirect_uri not in client['redirect_uris']:
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Client validation failed: {str(e)}")
            return False
    
    def generate_authorization_code(self, client_id: str, user_id: str,
                                  redirect_uri: str, scope: str,
                                  state: Optional[str] = None,
                                  nonce: Optional[str] = None) -> str:
        """
        Generate authorization code
        
        Args:
            client_id: Client identifier
            user_id: User identifier
            redirect_uri: Redirect URI
            scope: Requested scope
            state: State parameter for CSRF protection
            nonce: Nonce for ID token
            
        Returns:
            Authorization code
        """
        try:
            # Generate code
            code = secrets.token_urlsafe(32)
            
            # Calculate expiration
            expires_at = datetime.utcnow() + self.authorization_code_lifetime
            
            # Store authorization code
            authorization_code = {
                'code': code,
                'client_id': client_id,
                'user_id': user_id,
                'redirect_uri': redirect_uri,
                'scope': scope,
                'state': state,
                'nonce': nonce,
                'created_at': datetime.utcnow(),
                'expires_at': expires_at,
                'used': False
            }
            
            self._authorization_codes[code] = authorization_code
            
            # Limit number of active codes
            if len(self._authorization_codes) > self.max_authorization_codes:
                self._cleanup_expired_codes()
            
            self.logger.info(f"Authorization code generated: {code[:16]}...")
            return code
            
        except Exception as e:
            self.logger.error(f"Authorization code generation failed: {str(e)}")
            raise
    
    def validate_authorization_code(self, code: str, client_id: str,
                                  client_secret: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Validate and consume authorization code
        
        Args:
            code: Authorization code
            client_id: Client identifier
            client_secret: Client secret
            
        Returns:
            Authorization code data if valid
        """
        try:
            auth_code = self._authorization_codes.get(code)
            if not auth_code:
                return None
            
            # Check if code is used
            if auth_code['used']:
                self.logger.warning(f"Authorization code already used: {code[:16]}...")
                return None
            
            # Check expiration
            if datetime.utcnow() > auth_code['expires_at']:
                del self._authorization_codes[code]
                return None
            
            # Validate client
            if not self.validate_client(client_id, client_secret, auth_code['redirect_uri']):
                return None
            
            # Mark code as used
            auth_code['used'] = True
            
            self.logger.info(f"Authorization code validated: {code[:16]}...")
            return auth_code
            
        except Exception as e:
            self.logger.error(f"Authorization code validation failed: {str(e)}")
            return None
    
    def exchange_code_for_tokens(self, authorization_code: str, client_id: str,
                               client_secret: Optional[str] = None,
                               code_verifier: Optional[str] = None) -> Dict[str, Any]:
        """
        Exchange authorization code for access tokens
        
        Args:
            authorization_code: Authorization code
            client_id: Client identifier
            client_secret: Client secret
            code_verifier: PKCE code verifier
            
        Returns:
            Token response
        """
        try:
            # Validate authorization code
            auth_code_data = self.validate_authorization_code(authorization_code, client_id, client_secret)
            if not auth_code_data:
                raise ValueError("Invalid or expired authorization code")
            
            # Get user information
            user_id = auth_code_data['user_id']
            scope = auth_code_data['scope']
            
            # Generate tokens
            tokens = self._generate_tokens(user_id, client_id, scope, auth_code_data.get('nonce'))
            
            # Clean up authorization code
            del self._authorization_codes[authorization_code]
            
            self.logger.info(f"Token exchange completed for user: {user_id}")
            return tokens
            
        except Exception as e:
            self.logger.error(f"Token exchange failed: {str(e)}")
            raise
    
    def generate_access_token(self, user_id: str, client_id: str,
                            scope: str, security_context: SecurityContext) -> str:
        """
        Generate access token
        
        Args:
            user_id: User identifier
            client_id: Client identifier
            scope: Granted scope
            security_context: Security context
            
        Returns:
            Access token
        """
        try:
            # Create custom claims for OAuth2
            custom_claims = {
                'aud': client_id,
                'scope': scope,
                'grant_type': GrantType.AUTHORIZATION_CODE.value
            }
            
            # Generate JWT token
            token = self.jwt_handler.generate_token(
                security_context=security_context,
                token_type=TokenType.ACCESS,
                custom_claims=custom_claims
            )
            
            # Store token information
            token_info = {
                'token': token,
                'user_id': user_id,
                'client_id': client_id,
                'scope': scope,
                'grant_type': GrantType.AUTHORIZATION_CODE.value,
                'created_at': datetime.utcnow().isoformat()
            }
            
            self._access_tokens[token] = token_info
            
            self.logger.info(f"Access token generated for user: {user_id}")
            return token
            
        except Exception as e:
            self.logger.error(f"Access token generation failed: {str(e)}")
            raise
    
    def generate_refresh_token(self, user_id: str, client_id: str,
                             scope: str, security_context: SecurityContext) -> str:
        """
        Generate refresh token
        
        Args:
            user_id: User identifier
            client_id: Client identifier
            scope: Granted scope
            security_context: Security context
            
        Returns:
            Refresh token
        """
        try:
            # Generate opaque refresh token
            refresh_token = secrets.token_urlsafe(32)
            
            # Store refresh token
            token_info = {
                'refresh_token': refresh_token,
                'user_id': user_id,
                'client_id': client_id,
                'scope': scope,
                'created_at': datetime.utcnow(),
                'expires_at': datetime.utcnow() + self.refresh_token_lifetime
            }
            
            self._refresh_tokens[refresh_token] = token_info
            
            self.logger.info(f"Refresh token generated for user: {user_id}")
            return refresh_token
            
        except Exception as e:
            self.logger.error(f"Refresh token generation failed: {str(e)}")
            raise
    
    def generate_id_token(self, user_id: str, client_id: str,
                         nonce: Optional[str] = None) -> str:
        """
        Generate ID token (OpenID Connect)
        
        Args:
            user_id: User identifier
            client_id: Client identifier
            nonce: Nonce for replay protection
            
        Returns:
            ID token
        """
        try:
            # Create basic security context
            security_context = SecurityContext(
                user_id=user_id,
                roles=['user'],  # Default role
                permissions=['openid'],
                device_id='oauth2_server',
                ip_address='127.0.0.1',
                user_agent='OAuth2 Provider'
            )
            
            # Create custom claims for ID token
            custom_claims = {
                'aud': client_id,
                'nonce': nonce,
                'iss': f"{self.issuer}_openid"
            }
            
            # Generate JWT token
            token = self.jwt_handler.generate_token(
                security_context=security_context,
                token_type=TokenType.ID,
                custom_claims=custom_claims
            )
            
            self.logger.info(f"ID token generated for user: {user_id}")
            return token
            
        except Exception as e:
            self.logger.error(f"ID token generation failed: {str(e)}")
            raise
    
    def refresh_access_token(self, refresh_token: str, client_id: str,
                           client_secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Refresh access token using refresh token
        
        Args:
            refresh_token: Refresh token
            client_id: Client identifier
            client_secret: Client secret
            
        Returns:
            New token response
        """
        try:
            # Validate refresh token
            token_info = self._refresh_tokens.get(refresh_token)
            if not token_info:
                raise ValueError("Invalid refresh token")
            
            # Check expiration
            if datetime.utcnow() > token_info['expires_at']:
                del self._refresh_tokens[refresh_token]
                raise ValueError("Refresh token expired")
            
            # Validate client
            if token_info['client_id'] != client_id:
                raise ValueError("Client mismatch")
            
            if not self.validate_client(client_id, client_secret):
                raise ValueError("Invalid client credentials")
            
            # Generate new tokens
            user_id = token_info['user_id']
            scope = token_info['scope']
            
            # Create security context (simplified)
            security_context = SecurityContext(
                user_id=user_id,
                roles=['user'],
                permissions=scope.split(),
                device_id='oauth2_refresh',
                ip_address='127.0.0.1',
                user_agent='OAuth2 Provider'
            )
            
            tokens = self._generate_tokens(user_id, client_id, scope, nonce=None)
            
            # Revoke old refresh token
            del self._refresh_tokens[refresh_token]
            
            self.logger.info(f"Access token refreshed for user: {user_id}")
            return tokens
            
        except Exception as e:
            self.logger.error(f"Access token refresh failed: {str(e)}")
            raise
    
    def validate_access_token(self, access_token: str) -> Optional[Dict[str, Any]]:
        """
        Validate access token
        
        Args:
            access_token: Access token to validate
            
        Returns:
            Token claims if valid
        """
        try:
            # Validate JWT
            claims = self.jwt_handler.validate_token(access_token, TokenType.ACCESS)
            
            # Get token info
            token_info = self._access_tokens.get(access_token)
            if token_info:
                claims.update(token_info)
            
            return claims
            
        except Exception as e:
            self.logger.error(f"Access token validation failed: {str(e)}")
            return None
    
    def revoke_token(self, token: str, token_type_hint: Optional[str] = None) -> bool:
        """
        Revoke token (RFC 7009)
        
        Args:
            token: Token to revoke
            token_type_hint: Hint about token type
            
        Returns:
            True if revocation successful
        """
        try:
            revoked = False
            
            # Try to revoke as access token
            if token in self._access_tokens:
                del self._access_tokens[token]
                revoked = True
            
            # Try to revoke as refresh token
            if token in self._refresh_tokens:
                del self._refresh_tokens[token]
                revoked = True
            
            if revoked:
                self.logger.info(f"Token revoked: {token[:16]}...")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Token revocation failed: {str(e)}")
            return False
    
    def get_client_info(self, client_id: str) -> Optional[Dict[str, Any]]:
        """
        Get client information
        
        Args:
            client_id: Client identifier
            
        Returns:
            Client information
        """
        client = self._clients.get(client_id)
        if client:
            # Return client info without sensitive data
            return {
                'client_id': client['client_id'],
                'client_name': client['client_name'],
                'client_type': client['client_type'],
                'redirect_uris': client['redirect_uris'],
                'grant_types': client['grant_types'],
                'response_types': client['response_types'],
                'scopes': client['scopes']
            }
        return None
    
    def get_user_consent(self, user_id: str, client_id: str) -> Optional[Dict[str, Any]]:
        """
        Get user consent for client
        
        Args:
            user_id: User identifier
            client_id: Client identifier
            
        Returns:
            Consent information
        """
        consent_key = f"{user_id}:{client_id}"
        return self._consent_records.get(consent_key)
    
    def save_user_consent(self, user_id: str, client_id: str, 
                         scope: str, granted: bool = True) -> bool:
        """
        Save user consent
        
        Args:
            user_id: User identifier
            client_id: Client identifier
            scope: Granted scope
            granted: Whether consent was granted
            
        Returns:
            True if saved successfully
        """
        try:
            consent_key = f"{user_id}:{client_id}"
            consent_record = {
                'user_id': user_id,
                'client_id': client_id,
                'scope': scope,
                'granted': granted,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            self._consent_records[consent_key] = consent_record
            self.logger.info(f"User consent saved: {user_id} -> {client_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Consent saving failed: {str(e)}")
            return False
    
    def _generate_tokens(self, user_id: str, client_id: str, scope: str,
                        nonce: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate complete token response
        
        Args:
            user_id: User identifier
            client_id: Client identifier
            scope: Granted scope
            nonce: Nonce for ID token
            
        Returns:
            Token response dictionary
        """
        try:
            # Create security context
            security_context = SecurityContext(
                user_id=user_id,
                roles=['user'],  # Default - in production, get from user database
                permissions=scope.split(),
                device_id='oauth2_client',
                ip_address='127.0.0.1',
                user_agent='OAuth2 Client'
            )
            
            # Generate access token
            access_token = self.generate_access_token(user_id, client_id, scope, security_context)
            
            # Generate refresh token
            refresh_token = self.generate_refresh_token(user_id, client_id, scope, security_context)
            
            # Generate ID token if scope includes 'openid'
            id_token = None
            if 'openid' in scope.split():
                id_token = self.generate_id_token(user_id, client_id, nonce)
            
            # Prepare response
            token_response = {
                'access_token': access_token,
                'token_type': 'Bearer',
                'expires_in': int(self.access_token_lifetime.total_seconds()),
                'refresh_token': refresh_token
            }
            
            if id_token:
                token_response['id_token'] = id_token
                token_response['expires_in'] = int(self.id_token_lifetime.total_seconds())
            
            return token_response
            
        except Exception as e:
            self.logger.error(f"Token generation failed: {str(e)}")
            raise
    
    def _cleanup_expired_codes(self):
        """Clean up expired authorization codes"""
        try:
            now = datetime.utcnow()
            expired_codes = [
                code for code, data in self._authorization_codes.items()
                if now > data['expires_at']
            ]
            
            for code in expired_codes:
                del self._authorization_codes[code]
            
            if expired_codes:
                self.logger.info(f"Cleaned up {len(expired_codes)} expired authorization codes")
                
        except Exception as e:
            self.logger.error(f"Authorization code cleanup failed: {str(e)}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get OAuth2 provider statistics
        
        Returns:
            Statistics dictionary
        """
        try:
            statistics = {
                'clients': len(self._clients),
                'authorization_codes': len(self._authorization_codes),
                'access_tokens': len(self._access_tokens),
                'refresh_tokens': len(self._refresh_tokens),
                'consent_records': len(self._consent_records),
                'issuer': self.issuer
            }
            
            return statistics
            
        except Exception as e:
            self.logger.error(f"Failed to get statistics: {str(e)}")
            return {}

# Utility functions
def generate_pkce_challenge(verifier: str) -> str:
    """
    Generate PKCE code challenge
    
    Args:
        verifier: Code verifier
        
    Returns:
        Code challenge
    """
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()
    ).decode().rstrip('=')
    return challenge

def validate_redirect_uri(redirect_uri: str, allowed_uris: List[str]) -> bool:
    """
    Validate redirect URI against allowed list
    
    Args:
        redirect_uri: Redirect URI to validate
        allowed_uris: List of allowed redirect URIs
        
    Returns:
        True if redirect URI is valid
    """
    try:
        parsed = urlparse(redirect_uri)
        
        # Basic validation
        if not parsed.scheme or not parsed.netloc:
            return False
        
        # Check against allowed URIs
        return redirect_uri in allowed_uris
        
    except Exception:
        return False