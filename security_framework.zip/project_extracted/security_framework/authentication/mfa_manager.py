"""
Multi-Factor Authentication (MFA) Manager
Implements enterprise-grade MFA with multiple authentication methods
"""

import secrets
import qrcode
import base64
import hashlib
import hmac
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from io import BytesIO
import pyotp
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend
import json

class MFAMethod(Enum):
    """Supported MFA methods"""
    TOTP = "totp"  # Time-based One-Time Password
    HOTP = "hotp"  # HMAC-based One-Time Password
    SMS = "sms"    # SMS-based verification
    EMAIL = "email"  # Email verification
    FIDO2 = "fido2"  # FIDO2/WebAuthn
    PUSH = "push"    # Push notification
    BIOMETRIC = "biometric"  # Biometric authentication

class MFAStatus(Enum):
    """MFA enrollment status"""
    PENDING = "pending"
    ENROLLED = "enrolled"
    DISABLED = "disabled"
    EXPIRED = "expired"

class MFAManager:
    """
    Enterprise Multi-Factor Authentication Manager
    Provides comprehensive MFA with support for multiple authentication methods
    """
    
    def __init__(self, issuer: str = "Security Framework MFA"):
        """
        Initialize MFA Manager
        
        Args:
            issuer: Issuer name for TOTP/HOTP
        """
        self.issuer = issuer
        self.logger = logging.getLogger(__name__)
        self.backend = default_backend()
        
        # Configuration
        self.totp_window = 1  # TOTP window tolerance
        self.hotp_counter_window = 10  # HOTP counter window
        self.otp_length = 6  # Default OTP length
        self.setup_expiry_hours = 24  # MFA setup link expiry
        
        # Rate limiting
        self.max_sms_attempts = 3
        self.max_email_attempts = 3
        self.sms_cooldown_minutes = 5
        self.email_cooldown_minutes = 2
        
        # Data stores (in production, use database)
        self._mfa_secrets: Dict[str, Dict[str, Any]] = {}
        self._otp_codes: Dict[str, Dict[str, Any]] = {}
        self._mfa_attempts: Dict[str, Dict[str, int]] = {}
        self._rate_limits: Dict[str, Dict[str, datetime]] = {}
        
        self.logger.info("MFA Manager initialized")
    
    def enroll_mfa_method(self, user_id: str, method: MFAMethod,
                         method_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Enroll user for MFA method
        
        Args:
            user_id: User identifier
            method: MFA method to enroll
            method_data: Method-specific data
            
        Returns:
            Enrollment response
        """
        try:
            enrollment_data = {}
            
            if method == MFAMethod.TOTP:
                enrollment_data = self._enroll_totp(user_id)
            elif method == MFAMethod.HOTP:
                enrollment_data = self._enroll_hotp(user_id)
            elif method == MFAMethod.SMS:
                enrollment_data = self._enroll_sms(user_id, method_data)
            elif method == MFAMethod.EMAIL:
                enrollment_data = self._enroll_email(user_id, method_data)
            elif method == MFAMethod.FIDO2:
                enrollment_data = self._enroll_fido2(user_id, method_data)
            elif method == MFAMethod.PUSH:
                enrollment_data = self._enroll_push(user_id, method_data)
            else:
                raise ValueError(f"Unsupported MFA method: {method}")
            
            # Store MFA secret
            self._mfa_secrets[f"{user_id}_{method.value}"] = {
                'user_id': user_id,
                'method': method.value,
                'secret': enrollment_data.get('secret'),
                'status': MFAStatus.PENDING.value,
                'created_at': datetime.utcnow().isoformat(),
                'method_data': method_data or {},
                'enrollment_data': enrollment_data
            }
            
            self.logger.info(f"MFA enrollment initiated for user {user_id}: {method.value}")
            return enrollment_data
            
        except Exception as e:
            self.logger.error(f"MFA enrollment failed: {str(e)}")
            raise
    
    def _enroll_totp(self, user_id: str) -> Dict[str, Any]:
        """Enroll for TOTP authentication"""
        # Generate secret
        secret = pyotp.random_base32()
        
        # Generate QR code
        totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
            name=user_id,
            issuer_name=self.issuer
        )
        
        qr_code_data = self._generate_qr_code(totp_uri)
        
        return {
            'secret': secret,
            'qr_code': qr_code_data,
            'totp_uri': totp_uri,
            'manual_entry_key': secret,
            'enrollment_type': 'totp'
        }
    
    def _enroll_hotp(self, user_id: str) -> Dict[str, Any]:
        """Enroll for HOTP authentication"""
        # Generate secret
        secret = pyotp.random_base32()
        
        # HOTP requires counter-based generation
        hotp = pyotp.HOTP(secret)
        initial_counter = 0
        
        return {
            'secret': secret,
            'counter': initial_counter,
            'hotp_uri': hotp.provisioning_uri(
                name=user_id,
                issuer_name=self.issuer,
                initial_count=initial_counter
            ),
            'enrollment_type': 'hotp'
        }
    
    def _enroll_sms(self, user_id: str, method_data: Dict[str, Any]) -> Dict[str, Any]:
        """Enroll for SMS authentication"""
        if not method_data or 'phone_number' not in method_data:
            raise ValueError("Phone number required for SMS enrollment")
        
        phone_number = method_data['phone_number']
        
        return {
            'phone_number': phone_number,
            'verified': False,
            'enrollment_type': 'sms'
        }
    
    def _enroll_email(self, user_id: str, method_data: Dict[str, Any]) -> Dict[str, Any]:
        """Enroll for email authentication"""
        if not method_data or 'email' not in method_data:
            raise ValueError("Email address required for email enrollment")
        
        email = method_data['email']
        
        return {
            'email': email,
            'verified': False,
            'enrollment_type': 'email'
        }
    
    def _enroll_fido2(self, user_id: str, method_data: Dict[str, Any]) -> Dict[str, Any]:
        """Enroll for FIDO2 authentication"""
        # FIDO2 enrollment would involve WebAuthn API
        # This is a simplified placeholder
        
        return {
            'credential_id': secrets.token_hex(16),
            'public_key': secrets.token_hex(32),
            'enrollment_type': 'fido2'
        }
    
    def _enroll_push(self, user_id: str, method_data: Dict[str, Any]) -> Dict[str, Any]:
        """Enroll for push notification authentication"""
        # Push notification setup
        device_token = method_data.get('device_token', secrets.token_hex(32))
        
        return {
            'device_token': device_token,
            'platform': method_data.get('platform', 'unknown'),
            'enrollment_type': 'push'
        }
    
    def verify_mfa_enrollment(self, user_id: str, method: MFAMethod,
                             verification_data: Dict[str, Any]) -> bool:
        """
        Verify MFA enrollment with proof of possession
        
        Args:
            user_id: User identifier
            method: MFA method
            verification_data: Verification data
            
        Returns:
            True if verification successful
        """
        try:
            secret_key = f"{user_id}_{method.value}"
            secret_data = self._mfa_secrets.get(secret_key)
            
            if not secret_data:
                raise ValueError("MFA enrollment not found")
            
            if method == MFAMethod.TOTP:
                return self._verify_totp(secret_data, verification_data)
            elif method == MFAMethod.HOTP:
                return self._verify_hotp(secret_data, verification_data)
            elif method == MFAMethod.SMS:
                return self._verify_sms(secret_data, verification_data)
            elif method == MFAMethod.EMAIL:
                return self._verify_email(secret_data, verification_data)
            elif method == MFAMethod.FIDO2:
                return self._verify_fido2(secret_data, verification_data)
            elif method == MFAMethod.PUSH:
                return self._verify_push(secret_data, verification_data)
            else:
                raise ValueError(f"Unsupported MFA method: {method}")
                
        except Exception as e:
            self.logger.error(f"MFA verification failed: {str(e)}")
            return False
    
    def _verify_totp(self, secret_data: Dict[str, Any], verification_data: Dict[str, Any]) -> bool:
        """Verify TOTP code"""
        secret = secret_data['secret']
        totp = pyotp.TOTP(secret)
        
        token = verification_data.get('token')
        if not token:
            return False
        
        # Verify TOTP token
        is_valid = totp.verify(token, valid_window=self.totp_window)
        
        if is_valid:
            # Mark as enrolled
            secret_data['status'] = MFAStatus.ENROLLED.value
            secret_data['verified_at'] = datetime.utcnow().isoformat()
        
        return is_valid
    
    def _verify_hotp(self, secret_data: Dict[str, Any], verification_data: Dict[str, Any]) -> bool:
        """Verify HOTP code"""
        secret = secret_data['secret']
        hotp = pyotp.HOTP(secret)
        
        token = verification_data.get('token')
        counter = secret_data.get('counter', 0)
        
        if not token:
            return False
        
        # Verify HOTP token with counter window
        is_valid = hotp.verify(token, counter=counter)
        
        if is_valid:
            # Increment counter
            secret_data['counter'] = counter + 1
            secret_data['status'] = MFAStatus.ENROLLED.value
            secret_data['verified_at'] = datetime.utcnow().isoformat()
        
        return is_valid
    
    def _verify_sms(self, secret_data: Dict[str, Any], verification_data: Dict[str, Any]) -> bool:
        """Verify SMS verification"""
        # This would involve sending SMS and verifying the code
        # Simplified implementation
        
        phone_number = secret_data.get('phone_number')
        verification_code = verification_data.get('code')
        
        if not verification_code:
            return False
        
        # In real implementation, verify against SMS service
        # For now, just check if code format is valid
        is_valid = len(verification_code) == 6 and verification_code.isdigit()
        
        if is_valid:
            secret_data['verified'] = True
            secret_data['status'] = MFAStatus.ENROLLED.value
            secret_data['verified_at'] = datetime.utcnow().isoformat()
        
        return is_valid
    
    def _verify_email(self, secret_data: Dict[str, Any], verification_data: Dict[str, Any]) -> bool:
        """Verify email verification"""
        email = secret_data.get('email')
        verification_code = verification_data.get('code')
        
        if not verification_code:
            return False
        
        # In real implementation, verify against email service
        # For now, just check if code format is valid
        is_valid = len(verification_code) == 6 and verification_code.isdigit()
        
        if is_valid:
            secret_data['verified'] = True
            secret_data['status'] = MFAStatus.ENROLLED.value
            secret_data['verified_at'] = datetime.utcnow().isoformat()
        
        return is_valid
    
    def _verify_fido2(self, secret_data: Dict[str, Any], verification_data: Dict[str, Any]) -> bool:
        """Verify FIDO2 authentication"""
        # FIDO2 verification would involve WebAuthn API
        # Simplified implementation
        
        credential_id = secret_data.get('credential_id')
        signature = verification_data.get('signature')
        
        if not signature:
            return False
        
        # In real implementation, verify WebAuthn signature
        # For now, assume valid
        is_valid = True
        
        if is_valid:
            secret_data['status'] = MFAStatus.ENROLLED.value
            secret_data['verified_at'] = datetime.utcnow().isoformat()
        
        return is_valid
    
    def _verify_push(self, secret_data: Dict[str, Any], verification_data: Dict[str, Any]) -> bool:
        """Verify push notification response"""
        device_token = secret_data.get('device_token')
        response = verification_data.get('response')
        
        if not response:
            return False
        
        # In real implementation, verify push notification response
        # For now, just check if response is approved
        is_valid = response.get('approved', False)
        
        if is_valid:
            secret_data['status'] = MFAStatus.ENROLLED.value
            secret_data['verified_at'] = datetime.utcnow().isoformat()
        
        return is_valid
    
    def authenticate_mfa(self, user_id: str, method: MFAMethod,
                        authentication_data: Dict[str, Any]) -> bool:
        """
        Authenticate user using MFA method
        
        Args:
            user_id: User identifier
            method: MFA method to use
            authentication_data: Authentication data
            
        Returns:
            True if authentication successful
        """
        try:
            # Check if user has enrolled for this method
            secret_key = f"{user_id}_{method.value}"
            secret_data = self._mfa_secrets.get(secret_key)
            
            if not secret_data or secret_data['status'] != MFAStatus.ENROLLED.value:
                return False
            
            # Rate limiting
            if not self._check_rate_limit(user_id, method.value):
                self.logger.warning(f"MFA rate limit exceeded for user {user_id}")
                return False
            
            # Perform authentication based on method
            is_authenticated = False
            
            if method == MFAMethod.TOTP:
                is_authenticated = self._authenticate_totp(secret_data, authentication_data)
            elif method == MFAMethod.HOTP:
                is_authenticated = self._authenticate_hotp(secret_data, authentication_data)
            elif method == MFAMethod.SMS:
                is_authenticated = self._authenticate_sms(secret_data, authentication_data)
            elif method == MFAMethod.EMAIL:
                is_authenticated = self._authenticate_email(secret_data, authentication_data)
            elif method == MFAMethod.FIDO2:
                is_authenticated = self._authenticate_fido2(secret_data, authentication_data)
            elif method == MFAMethod.PUSH:
                is_authenticated = self._authenticate_push(secret_data, authentication_data)
            else:
                raise ValueError(f"Unsupported MFA method: {method}")
            
            # Track authentication attempts
            self._track_attempt(user_id, method.value, is_authenticated)
            
            if is_authenticated:
                self.logger.info(f"MFA authentication successful for user {user_id}: {method.value}")
            else:
                self.logger.warning(f"MFA authentication failed for user {user_id}: {method.value}")
            
            return is_authenticated
            
        except Exception as e:
            self.logger.error(f"MFA authentication failed: {str(e)}")
            return False
    
    def _authenticate_totp(self, secret_data: Dict[str, Any], auth_data: Dict[str, Any]) -> bool:
        """Authenticate using TOTP"""
        secret = secret_data['secret']
        totp = pyotp.TOTP(secret)
        
        token = auth_data.get('token')
        if not token:
            return False
        
        return totp.verify(token, valid_window=self.totp_window)
    
    def _authenticate_hotp(self, secret_data: Dict[str, Any], auth_data: Dict[str, Any]) -> bool:
        """Authenticate using HOTP"""
        secret = secret_data['secret']
        hotp = pyotp.HOTP(secret)
        
        token = auth_data.get('token')
        counter = secret_data.get('counter', 0)
        
        if not token:
            return False
        
        # Try multiple counter values for synchronization
        for counter_attempt in range(counter, counter + self.hotp_counter_window + 1):
            if hotp.verify(token, counter=counter_attempt):
                # Update counter
                secret_data['counter'] = counter_attempt + 1
                return True
        
        return False
    
    def _authenticate_sms(self, secret_data: Dict[str, Any], auth_data: Dict[str, Any]) -> bool:
        """Authenticate using SMS"""
        # Send OTP via SMS service
        phone_number = secret_data['phone_number']
        
        # Generate and store OTP
        otp = f"{secrets.randbelow(1000000):06d}"
        otp_key = f"sms_{phone_number}_{datetime.utcnow().strftime('%Y%m%d_%H')}"
        
        self._otp_codes[otp_key] = {
            'otp': otp,
            'phone_number': phone_number,
            'created_at': datetime.utcnow(),
            'used': False
        }
        
        # In real implementation, send SMS here
        self.logger.info(f"SMS OTP sent to {phone_number}: {otp}")
        
        # Verify provided OTP
        provided_otp = auth_data.get('code')
        return provided_otp == otp
    
    def _authenticate_email(self, secret_data: Dict[str, Any], auth_data: Dict[str, Any]) -> bool:
        """Authenticate using email"""
        # Send OTP via email service
        email = secret_data['email']
        
        # Generate and store OTP
        otp = f"{secrets.randbelow(1000000):06d}"
        otp_key = f"email_{email}_{datetime.utcnow().strftime('%Y%m%d_%H')}"
        
        self._otp_codes[otp_key] = {
            'otp': otp,
            'email': email,
            'created_at': datetime.utcnow(),
            'used': False
        }
        
        # In real implementation, send email here
        self.logger.info(f"Email OTP sent to {email}: {otp}")
        
        # Verify provided OTP
        provided_otp = auth_data.get('code')
        return provided_otp == otp
    
    def _authenticate_fido2(self, secret_data: Dict[str, Any], auth_data: Dict[str, Any]) -> bool:
        """Authenticate using FIDO2"""
        # FIDO2 authentication would involve WebAuthn
        # Simplified implementation
        
        credential_id = secret_data['credential_id']
        assertion = auth_data.get('assertion')
        
        if not assertion:
            return False
        
        # In real implementation, verify WebAuthn assertion
        return True
    
    def _authenticate_push(self, secret_data: Dict[str, Any], auth_data: Dict[str, Any]) -> bool:
        """Authenticate using push notification"""
        device_token = secret_data['device_token']
        
        # Send push notification
        # In real implementation, send push notification and wait for response
        
        # Simulate push notification approval
        response = auth_data.get('response', {})
        return response.get('approved', False)
    
    def list_user_mfa_methods(self, user_id: str) -> List[Dict[str, Any]]:
        """
        List user's enrolled MFA methods
        
        Args:
            user_id: User identifier
            
        Returns:
            List of MFA method information
        """
        methods = []
        
        for key, secret_data in self._mfa_secrets.items():
            if secret_data['user_id'] == user_id:
                methods.append({
                    'method': secret_data['method'],
                    'status': secret_data['status'],
                    'created_at': secret_data['created_at'],
                    'verified_at': secret_data.get('verified_at'),
                    'method_data': secret_data.get('method_data', {})
                })
        
        return methods
    
    def disable_mfa_method(self, user_id: str, method: MFAMethod) -> bool:
        """
        Disable MFA method for user
        
        Args:
            user_id: User identifier
            method: MFA method to disable
            
        Returns:
            True if disabling successful
        """
        try:
            secret_key = f"{user_id}_{method.value}"
            secret_data = self._mfa_secrets.get(secret_key)
            
            if secret_data:
                secret_data['status'] = MFAStatus.DISABLED.value
                secret_data['disabled_at'] = datetime.utcnow().isoformat()
                
                self.logger.info(f"MFA method disabled: {user_id} -> {method.value}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"MFA method disabling failed: {str(e)}")
            return False
    
    def _generate_qr_code(self, totp_uri: str) -> str:
        """Generate QR code as base64 image"""
        try:
            qr = qrcode.QRCode(version=1, box_size=10, border=4)
            qr.add_data(totp_uri)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            # Convert to base64
            buffer = BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)
            
            return base64.b64encode(buffer.getvalue()).decode()
            
        except Exception as e:
            self.logger.error(f"QR code generation failed: {str(e)}")
            return ""
    
    def _check_rate_limit(self, user_id: str, method: str) -> bool:
        """Check rate limiting for MFA attempts"""
        current_time = datetime.utcnow()
        
        # Initialize user attempts tracking
        if user_id not in self._mfa_attempts:
            self._mfa_attempts[user_id] = {'count': 0, 'first_attempt': current_time}
        
        # Check if within cooldown period
        rate_key = f"{user_id}_{method}"
        if rate_key in self._rate_limits:
            last_attempt = self._rate_limits[rate_key]
            if method in ['sms', 'email']:
                cooldown_minutes = self.sms_cooldown_minutes if method == 'sms' else self.email_cooldown_minutes
                if current_time < last_attempt + timedelta(minutes=cooldown_minutes):
                    return False
        
        return True
    
    def _track_attempt(self, user_id: str, method: str, success: bool):
        """Track MFA authentication attempts"""
        self._mfa_attempts[user_id]['count'] += 1
        
        # Update rate limiting
        if not success:
            self._rate_limits[f"{user_id}_{method}"] = datetime.utcnow()
    
    def get_mfa_statistics(self) -> Dict[str, Any]:
        """
        Get MFA statistics
        
        Returns:
            Statistics dictionary
        """
        try:
            # Count enrolled methods by status
            status_counts = {}
            method_counts = {}
            
            for secret_data in self._mfa_secrets.values():
                status = secret_data['status']
                method = secret_data['method']
                
                status_counts[status] = status_counts.get(status, 0) + 1
                method_counts[method] = method_counts.get(method, 0) + 1
            
            # Count total users with MFA
            users_with_mfa = len(set(data['user_id'] for data in self._mfa_secrets.values()))
            
            # Count active OTP codes
            now = datetime.utcnow()
            active_otps = len([
                otp_data for otp_data in self._otp_codes.values()
                if now - otp_data['created_at'] < timedelta(hours=1) and not otp_data['used']
            ])
            
            statistics = {
                'total_enrollments': len(self._mfa_secrets),
                'users_with_mfa': users_with_mfa,
                'status_distribution': status_counts,
                'method_distribution': method_counts,
                'active_otps': active_otps,
                'issuer': self.issuer
            }
            
            return statistics
            
        except Exception as e:
            self.logger.error(f"Failed to get MFA statistics: {str(e)}")
            return {}

# Utility functions
def generate_backup_codes(count: int = 10) -> List[str]:
    """
    Generate backup codes for MFA recovery
    
    Args:
        count: Number of backup codes to generate
        
    Returns:
        List of backup codes
    """
    codes = []
    for _ in range(count):
        code = f"{secrets.randbelow(1000000):06d}"
        codes.append(code)
    
    return codes

def validate_phone_number(phone_number: str) -> bool:
    """
    Validate phone number format
    
    Args:
        phone_number: Phone number to validate
        
    Returns:
        True if valid format
    """
    # Basic validation - in production, use proper phone number validation library
    return len(phone_number) >= 10 and phone_number.replace('+', '').replace('-', '').replace(' ', '').isdigit()

def validate_email_address(email: str) -> bool:
    """
    Validate email address format
    
    Args:
        email: Email address to validate
        
    Returns:
        True if valid format
    """
    import re
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None