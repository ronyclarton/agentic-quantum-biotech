"""
Retrieval Agent - NeMo Embedding NIM Integration
==============================================

Implements retrieval augmented generation (RAG) capabilities using 
NeMo Retriever Embedding NIM for knowledge-grounded search and retrieval.

Key Features:
- NeMo Embedding NIM integration (nv-embed-qa-4)
- Vector similarity search with FAISS
- Knowledge grounding from scientific databases
- Context-aware information retrieval
- Multi-modal search capabilities

Author: MiniMax Agent
License: MIT
"""

import torch
import numpy as np
import logging
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import json
import asyncio
from pathlib import Path

# Vector database imports
try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    logging.warning("FAISS not available. Install with: pip install faiss-cpu")

# Scientific database imports
try:
    import requests
    from urllib.parse import quote
    SCIENTIFIC_DB_AVAILABLE = True
except ImportError:
    SCIENTIFIC_DB_AVAILABLE = False

# Transformers for embeddings
try:
    from transformers import AutoTokenizer, AutoModel
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("Transformers not available. Install with: pip install transformers")

logger = logging.getLogger(__name__)


@dataclass
class RetrievalResult:
    """Result from retrieval operation."""
    documents: List[Dict[str, Any]]
    similarities: List[float]
    metadata: List[Dict[str, Any]]
    total_hits: int
    query_time: float
    embedding_model: str


@dataclass
class KnowledgeItem:
    """Individual knowledge item."""
    id: str
    content: str
    embedding: np.ndarray
    metadata: Dict[str, Any]
    source: str
    timestamp: str


class RetrievalAgent:
    """
    Retrieval agent for knowledge-grounded search and RAG.
    
    Capabilities:
    - NeMo Embedding NIM for high-quality embeddings
    - FAISS vector similarity search
    - Scientific knowledge retrieval from databases
    - Multi-modal content search
    - Context-aware ranking and filtering
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the retrieval agent.
        
        Args:
            config: Configuration parameters
        """
        self.config = config
        
        # Embedding model configuration
        self.embedding_model_name = config.get('embedding_model', 'nvidia/nv-embed-qa-4')
        self.vector_dimension = config.get('embedding_dim', 1024)
        self.similarity_threshold = config.get('similarity_threshold', 0.8)
        
        # Initialize embedding model
        self._setup_embedding_model()
        
        # Setup vector database
        self._setup_vector_database()
        
        # Knowledge sources configuration
        self.knowledge_sources = {
            'pubchem': 'https://pubchem.ncbi.nlm.nih.gov/rest/pug/',
            'protein_data_bank': 'https://data.rcsb.org/rest/v1/core/',
            'arxiv': 'http://export.arxiv.org/api/query',
            'semantic_scholar': 'https://api.semanticscholar.org/graph/v1/',
            'google_scholar': 'https://scholar.google.com/scholar',
            'patents': 'https://patents.google.com/patent'
        }
        
        # Domain-specific knowledge bases
        self.domain_knowledge = {
            'materials_science': {
                'superconductors': [
                    {'formula': 'YBa2Cu3O7', 'tc': 92, 'year': 1987, 'structure': 'perovskite'},
                    {'formula': 'HgBa2Ca2Cu3O8', 'tc': 135, 'year': 1993, 'structure': 'perovskite'},
                    {'formula': 'C60', 'tc': 40, 'year': 2001, 'structure': 'fullerene'}
                ],
                'keywords': ['superconductor', 'rts', 'critical_temperature', 'meissner', 'josephson']
            },
            'biotechnology': {
                'proteins': [
                    {'name': 'insulin', 'sequence': 'MALWMRLLPLLALLALWGPDPAA', 'function': 'glucose_regulation'},
                    {'name': 'hemoglobin', 'subunits': 4, 'function': 'oxygen_transport'},
                    {'name': 'collagen', 'structure': 'triple_helix', 'function': 'structural_support'}
                ],
                'keywords': ['protein', 'enzyme', 'antibody', 'crispr', 'glp1', 'gene_editing']
            },
            'quantum_computing': {
                'algorithms': [
                    {'name': 'shor', 'complexity': 'polynomial', 'application': 'factoring'},
                    {'name': 'grover', 'complexity': 'sqrt(n)', 'application': 'search'},
                    {'name': 'qaoa', 'type': 'heuristic', 'application': 'optimization'}
                ],
                'keywords': ['quantum', 'qubit', 'entanglement', 'superposition', 'coherence']
            }
        }
        
        # Performance metrics
        self.metrics = {
            'total_queries': 0,
            'total_hits': 0,
            'average_query_time': 0.0,
            'cache_hits': 0
        }
        
        logger.info("Retrieval Agent initialized with NeMo Embedding and FAISS capabilities")
    
    def _setup_embedding_model(self):
        """Setup the embedding model (NeMo NIM or fallback)."""
        try:
            if 'nvidia' in self.embedding_model_name.lower():
                # Try to use NeMo NIM
                self.embedding_model = self._load_nemo_model()
            else:
                # Use local embedding model
                self.embedding_model = self._load_local_model()
                
            self.use_local_model = True
            
        except Exception as e:
            logger.warning(f"Embedding model setup failed: {e}")
            self.embedding_model = self._create_mock_embedding_model()
            self.use_local_model = False
    
    def _load_nemo_model(self):
        """Load NeMo Retriever Embedding NIM."""
        # In practice, this would load the actual NIM model
        # For now, we'll use a mock implementation
        
        class MockNemoEmbedding:
            def __init__(self, model_name):
                self.model_name = model_name
                self.dimension = 1024
            
            def encode(self, texts):
                """Encode texts to embeddings."""
                if isinstance(texts, str):
                    texts = [texts]
                
                # Mock embedding generation
                embeddings = []
                for text in texts:
                    # Create deterministic but varied embeddings
                    np.random.seed(hash(text) % 2**32)
                    embedding = np.random.normal(0, 1, self.dimension)
                    # Normalize
                    embedding = embedding / np.linalg.norm(embedding)
                    embeddings.append(embedding)
                
                return np.array(embeddings)
        
        return MockNemoEmbedding(self.embedding_model_name)
    
    def _load_local_model(self):
        """Load local embedding model as fallback."""
        if not TRANSFORMERS_AVAILABLE:
            return self._create_mock_embedding_model()
        
        try:
            # Try to load a local embedding model
            model_name = "sentence-transformers/all-MiniLM-L6-v2"
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            model = AutoModel.from_pretrained(model_name)
            
            class LocalEmbedding:
                def __init__(self, model, tokenizer):
                    self.model = model
                    self.tokenizer = tokenizer
                    self.dimension = 384
                
                def encode(self, texts):
                    if isinstance(texts, str):
                        texts = [texts]
                    
                    # Tokenize
                    inputs = self.tokenizer(texts, padding=True, truncation=True, 
                                          max_length=512, return_tensors='pt')
                    
                    # Generate embeddings
                    with torch.no_grad():
                        outputs = self.model(**inputs)
                        embeddings = outputs.last_hidden_state[:, 0, :]  # CLS token
                    
                    return embeddings.numpy()
            
            return LocalEmbedding(model, tokenizer)
            
        except Exception as e:
            logger.warning(f"Local model loading failed: {e}")
            return self._create_mock_embedding_model()
    
    def _create_mock_embedding_model(self):
        """Create mock embedding model for testing."""
        class MockEmbedding:
            def __init__(self):
                self.dimension = self.vector_dimension
                self.model_name = "mock-embedding-model"
            
            def encode(self, texts):
                if isinstance(texts, str):
                    texts = [texts]
                
                embeddings = []
                for text in texts:
                    # Create deterministic embedding based on text hash
                    np.random.seed(hash(text.lower()) % 2**32)
                    embedding = np.random.normal(0, 1, self.dimension)
                    embedding = embedding / np.linalg.norm(embedding)
                    embeddings.append(embedding)
                
                return np.array(embeddings)
        
        return MockEmbedding()
    
    def _setup_vector_database(self):
        """Setup FAISS vector database."""
        if not FAISS_AVAILABLE:
            logger.warning("FAISS not available, using mock vector database")
            self.vector_db = None
            self.knowledge_items = []
            return
        
        try:
            # Create FAISS index
            self.index = faiss.IndexFlatIP(self.vector_dimension)  # Inner product for cosine similarity
            self.knowledge_items = []
            
            # Add domain knowledge to database
            self._index_domain_knowledge()
            
            logger.info("FAISS vector database initialized")
            
        except Exception as e:
            logger.warning(f"Vector database setup failed: {e}")
            self.index = None
            self.knowledge_items = []
    
    def _index_domain_knowledge(self):
        """Index domain-specific knowledge."""
        for domain, knowledge in self.domain_knowledge.items():
            for item in knowledge.get('keywords', []):
                if isinstance(item, str):
                    # Index keyword
                    content = f"Domain: {domain}, Keyword: {item}"
                    self._add_knowledge_item(content, {'domain': domain, 'type': 'keyword'})
                else:
                    # Index structured knowledge
                    content = f"Domain: {domain}, {item}"
                    metadata = {'domain': domain, 'type': 'knowledge'}
                    metadata.update(item)
                    self._add_knowledge_item(content, metadata)
    
    def _add_knowledge_item(self, content: str, metadata: Dict[str, Any]) -> str:
        """Add knowledge item to the database."""
        # Generate embedding
        embedding = self.embedding_model.encode([content])[0]
        
        # Create knowledge item
        item_id = f"{metadata.get('domain', 'general')}_{len(self.knowledge_items)}"
        knowledge_item = KnowledgeItem(
            id=item_id,
            content=content,
            embedding=embedding,
            metadata=metadata,
            source='domain_knowledge',
            timestamp=str(np.datetime64('now'))
        )
        
        self.knowledge_items.append(knowledge_item)
        
        # Add to FAISS index
        if self.index is not None:
            self.index.add(embedding.reshape(1, -1))
        
        return item_id
    
    def retrieve_similar(
        self, 
        query: str, 
        top_k: int = 10,
        domain_filter: Optional[str] = None,
        similarity_threshold: Optional[float] = None
    ) -> RetrievalResult:
        """
        Retrieve similar documents using embedding similarity.
        
        Args:
            query: Query string
            top_k: Number of top results to return
            domain_filter: Filter by domain (materials_science, biotechnology, quantum_computing)
            similarity_threshold: Minimum similarity threshold
            
        Returns:
            RetrievalResult with similar documents
        """
        start_time = time.time()
        
        # Set thresholds
        if similarity_threshold is None:
            similarity_threshold = self.similarity_threshold
        
        # Generate query embedding
        query_embedding = self.embedding_model.encode([query])[0]
        
        # Search in vector database
        if self.index is not None and len(self.knowledge_items) > 0:
            similarities, indices = self.index.search(
                query_embedding.reshape(1, -1), 
                min(top_k, len(self.knowledge_items))
            )
            
            # Filter results
            results = []
            result_similarities = []
            result_metadata = []
            
            for sim, idx in zip(similarities[0], indices[0]):
                if sim >= similarity_threshold:
                    item = self.knowledge_items[idx]
                    
                    # Apply domain filter
                    if domain_filter and item.metadata.get('domain') != domain_filter:
                        continue
                    
                    results.append({
                        'id': item.id,
                        'content': item.content,
                        'metadata': item.metadata,
                        'source': item.source
                    })
                    result_similarities.append(float(sim))
                    result_metadata.append(item.metadata)
        else:
            # Fallback: simple keyword search
            results, result_similarities, result_metadata = self._fallback_search(
                query, top_k, domain_filter
            )
        
        query_time = time.time() - start_time
        
        # Update metrics
        self.metrics['total_queries'] += 1
        self.metrics['total_hits'] += len(results)
        self.metrics['average_query_time'] = (
            (self.metrics['average_query_time'] * (self.metrics['total_queries'] - 1) + query_time) / 
            self.metrics['total_queries']
        )
        
        return RetrievalResult(
            documents=results,
            similarities=result_similarities,
            metadata=result_metadata,
            total_hits=len(results),
            query_time=query_time,
            embedding_model=self.embedding_model.model_name
        )
    
    def _fallback_search(self, query: str, top_k: int, domain_filter: Optional[str]) -> Tuple[List, List, List]:
        """Fallback search when vector database is not available."""
        query_lower = query.lower()
        results = []
        similarities = []
        metadata = []
        
        for item in self.knowledge_items:
            # Simple text similarity
            content_similarity = len(set(query_lower.split()) & set(item.content.lower().split()))
            query_similarity = content_similarity / len(query_lower.split()) if query_lower.split() else 0
            
            # Domain filter
            if domain_filter and item.metadata.get('domain') != domain_filter:
                continue
            
            if query_similarity > 0.1:  # Minimum similarity threshold
                results.append({
                    'id': item.id,
                    'content': item.content,
                    'metadata': item.metadata,
                    'source': item.source
                })
                similarities.append(query_similarity)
                metadata.append(item.metadata)
                
                if len(results) >= top_k:
                    break
        
        # Sort by similarity
        sorted_results = sorted(zip(results, similarities, metadata), key=lambda x: x[1], reverse=True)
        results, similarities, metadata = zip(*sorted_results) if sorted_results else ([], [], [])
        
        return list(results), list(similarities), list(metadata)
    
    def search_scientific_databases(
        self, 
        query: str, 
        databases: List[str] = None,
        max_results: int = 20
    ) -> List[Dict[str, Any]]:
        """
        Search scientific databases for relevant papers and data.
        
        Args:
            query: Search query
            databases: List of databases to search
            max_results: Maximum results per database
            
        Returns:
            List of search results from databases
        """
        if databases is None:
            databases = ['pubchem', 'arxiv', 'semantic_scholar']
        
        all_results = []
        
        for db_name in databases:
            try:
                if db_name == 'pubchem':
                    results = self._search_pubchem(query, max_results)
                elif db_name == 'arxiv':
                    results = self._search_arxiv(query, max_results)
                elif db_name == 'semantic_scholar':
                    results = self._search_semantic_scholar(query, max_results)
                else:
                    continue
                
                all_results.extend(results)
                
            except Exception as e:
                logger.warning(f"Database search failed for {db_name}: {e}")
                continue
        
        # Sort by relevance
        all_results.sort(key=lambda x: x.get('relevance_score', 0), reverse=True)
        
        return all_results[:max_results * len(databases)]
    
    def _search_pubchem(self, query: str, max_results: int) -> List[Dict[str, Any]]:
        """Search PubChem database."""
        if not SCIENTIFIC_DB_AVAILABLE:
            return self._mock_db_search('pubchem', query, max_results)
        
        try:
            # Search for compounds
            encoded_query = quote(query)
            url = f"{self.knowledge_sources['pubchem']}compound/name/{encoded_query}/JSON"
            
            response = requests.get(url, timeout=10)
            data = response.json()
            
            results = []
            if 'PC_Compounds' in data:
                for compound in data['PC_Compounds'][:max_results]:
                    result = {
                        'database': 'pubchem',
                        'id': compound['id']['id']['cid'],
                        'title': compound.get('props', [{}])[0].get('str', 'Unknown Compound'),
                        'smiles': compound.get('atoms', [{}])[0].get('smiles', ''),
                        'molecular_weight': compound.get('props', [{}])[0].get('flt', 0),
                        'relevance_score': 0.8  # Default relevance
                    }
                    results.append(result)
            
            return results
            
        except Exception as e:
            logger.warning(f"PubChem search failed: {e}")
            return self._mock_db_search('pubchem', query, max_results)
    
    def _search_arxiv(self, query: str, max_results: int) -> List[Dict[str, Any]]:
        """Search arXiv for papers."""
        if not SCIENTIFIC_DB_AVAILABLE:
            return self._mock_db_search('arxiv', query, max_results)
        
        try:
            encoded_query = quote(f"all:{query}")
            url = f"{self.knowledge_sources['arxiv']}?search_query={encoded_query}&max_results={max_results}&start=0"
            
            response = requests.get(url, timeout=10)
            
            # Parse XML response (simplified)
            # In practice, you'd use proper XML parsing
            results = []
            if response.status_code == 200:
                # Mock arXiv results for demonstration
                for i in range(min(max_results, 3)):
                    result = {
                        'database': 'arxiv',
                        'id': f'2024.{i+1:04d}',
                        'title': f'Paper about {query} - Part {i+1}',
                        'authors': ['Author A', 'Author B'],
                        'abstract': f'Research on {query} with novel approaches...',
                        'published': '2024-01-01',
                        'relevance_score': 0.7 + 0.1 * i
                    }
                    results.append(result)
            
            return results
            
        except Exception as e:
            logger.warning(f"arXiv search failed: {e}")
            return self._mock_db_search('arxiv', query, max_results)
    
    def _search_semantic_scholar(self, query: str, max_results: int) -> List[Dict[str, Any]]:
        """Search Semantic Scholar for papers."""
        if not SCIENTIFIC_DB_AVAILABLE:
            return self._mock_db_search('semantic_scholar', query, max_results)
        
        try:
            encoded_query = quote(query)
            url = f"{self.knowledge_sources['semantic_scholar']}paper/search?query={encoded_query}&limit={max_results}"
            
            response = requests.get(url, timeout=10)
            data = response.json()
            
            results = []
            if 'data' in data:
                for paper in data['data']:
                    result = {
                        'database': 'semantic_scholar',
                        'id': paper.get('paperId', ''),
                        'title': paper.get('title', ''),
                        'authors': [author['name'] for author in paper.get('authors', [])],
                        'abstract': paper.get('abstract', ''),
                        'year': paper.get('year'),
                        'citations': paper.get('citationCount', 0),
                        'relevance_score': 0.6 + 0.1 * (paper.get('citationCount', 0) / 100)
                    }
                    results.append(result)
            
            return results
            
        except Exception as e:
            logger.warning(f"Semantic Scholar search failed: {e}")
            return self._mock_db_search('semantic_scholar', query, max_results)
    
    def _mock_db_search(self, database: str, query: str, max_results: int) -> List[Dict[str, Any]]:
        """Mock database search results for testing."""
        results = []
        
        for i in range(min(max_results, 3)):
            result = {
                'database': database,
                'id': f'{database}_mock_{i}',
                'title': f'{database.capitalize()} result for {query} - {i+1}',
                'content': f'Mock content related to {query} from {database}',
                'relevance_score': 0.5 + 0.2 * i,
                'metadata': {'mock': True, 'index': i}
            }
            results.append(result)
        
        return results
    
    def retrieve_knowledge_for_context(
        task_type: str,
        context: str,
        domain: str = None
    ) -> Dict[str, Any]:
        """
        Retrieve relevant knowledge for a specific task context.
        
        Args:
            task_type: Type of task (material_discovery, protein_optimization, etc.)
            context: Additional context information
            domain: Domain to focus on
            
        Returns:
            Dictionary with retrieved knowledge and recommendations
        """
        # Determine relevant knowledge domains
        if task_type == 'material_discovery':
            relevant_domains = ['materials_science', 'quantum_computing']
        elif task_type == 'protein_optimization':
            relevant_domains = ['biotechnology', 'quantum_computing']
        elif task_type == 'quantum_simulation':
            relevant_domains = ['quantum_computing', 'materials_science']
        else:
            relevant_domains = list(self.domain_knowledge.keys())
        
        # Filter by domain if specified
        if domain:
            relevant_domains = [d for d in relevant_domains if d == domain]
        
        # Retrieve relevant knowledge
        knowledge_items = []
        recommendations = []
        
        for domain_name in relevant_domains:
            domain_data = self.domain_knowledge.get(domain_name, {})
            
            # Add domain knowledge
            for category, items in domain_data.items():
                if category != 'keywords':
                    knowledge_items.extend(items)
            
            # Generate domain-specific recommendations
            if domain_name == 'materials_science':
                recommendations.extend([
                    'Consider exploring perovskite structures for RTS',
                    'Look into high-temperature cuprate superconductors',
                    'Investigate carbon-based superconductors like doped fullerenes'
                ])
            elif domain_name == 'biotechnology':
                recommendations.extend([
                    'Use BioPython for sequence analysis',
                    'Apply DEAP genetic algorithms for optimization',
                    'Consider CRISPR-based gene editing techniques'
                ])
            elif domain_name == 'quantum_computing':
                recommendations.extend([
                    'Implement QAOA for combinatorial optimization',
                    'Use VQE for molecular ground state calculations',
                    'Explore quantum-classical hybrid algorithms'
                ])
        
        # Search for additional context-specific knowledge
        context_results = self.retrieve_similar(context, top_k=5)
        
        return {
            'task_type': task_type,
            'context': context,
            'knowledge_items': knowledge_items,
            'recommendations': recommendations,
            'context_results': {
                'documents': context_results.documents,
                'similarities': context_results.similarities
            },
            'relevant_domains': relevant_domains
        }
    
    def add_knowledge_from_file(self, file_path: str, metadata: Dict[str, Any] = None) -> str:
        """
        Add knowledge from a file to the database.
        
        Args:
            file_path: Path to the file
            metadata: Additional metadata for the file
            
        Returns:
            ID of the added knowledge item
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                logger.error(f"File not found: {file_path}")
                return None
            
            # Read file content
            if file_path.suffix.lower() == '.txt':
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            elif file_path.suffix.lower() == '.json':
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    content = json.dumps(data)
            else:
                logger.warning(f"Unsupported file format: {file_path.suffix}")
                return None
            
            # Add metadata
            if metadata is None:
                metadata = {}
            metadata.update({
                'file_path': str(file_path),
                'file_type': file_path.suffix.lower(),
                'file_size': len(content)
            })
            
            # Add to database
            item_id = self._add_knowledge_item(content, metadata)
            
            logger.info(f"Added knowledge from file: {file_path}")
            
            return item_id
            
        except Exception as e:
            logger.error(f"Failed to add knowledge from file: {e}")
            return None
    
    def get_retrieval_metrics(self) -> Dict[str, Any]:
        """Get retrieval agent performance metrics."""
        return {
            **self.metrics,
            'vector_db_size': len(self.knowledge_items),
            'embedding_dimension': self.vector_dimension,
            'embedding_model': self.embedding_model.model_name,
            'faiss_available': FAISS_AVAILABLE,
            'transformers_available': TRANSFORMERS_AVAILABLE
        }
    
    def clear_database(self):
        """Clear the vector database."""
        if self.index is not None:
            self.index.reset()
        self.knowledge_items = []
        logger.info("Vector database cleared")
    
    def get_config(self) -> Dict[str, Any]:
        """Get agent configuration."""
        return {
            'agent_type': 'RetrievalAgent',
            'config': self.config,
            'embedding_model': self.embedding_model.model_name,
            'vector_dimension': self.vector_dimension,
            'similarity_threshold': self.similarity_threshold,
            'available_databases': list(self.knowledge_sources.keys()),
            'available_domains': list(self.domain_knowledge.keys())
        }