"""
Generation Agent - PyTorch + GGN Training
========================================

Implements material synthesis and structure generation using PyTorch
and Generative Graph Networks (GGN) for creating novel material candidates.

Key Features:
- PyTorch-based generative models
- Generative Graph Networks (GGN) for materials
- Structure generation for room-temperature superconductors
- Chemical validation and property prediction
- Integration with DFT validation pipeline

Author: MiniMax Agent
License: MIT
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import json
from pathlib import Path

# PyTorch geometric for graph neural networks
try:
    import torch_geometric
    from torch_geometric.nn import GCNConv, GATConv, global_mean_pool
    from torch_geometric.data import Data
    TORCH_GEOMETRIC_AVAILABLE = True
except ImportError:
    TORCH_GEOMETRIC_AVAILABLE = False
    logging.warning("PyTorch Geometric not available. Install with: pip install torch-geometric")

# Chemical informatics
try:
    from rdkit import Chem
    from rdkit.Chem import Descriptors, rdMolDescriptors
    RDKIT_AVAILABLE = True
except ImportError:
    RDKIT_AVAILABLE = False
    logging.warning("RDKit not available. Install with: pip install rdkit")

logger = logging.getLogger(__name__)


@dataclass
class GeneratedMaterial:
    """Generated material candidate."""
    id: str
    structure: Dict[str, Any]
    properties: Dict[str, float]
    generation_method: str
    confidence_score: float
    validation_status: str
    smiles: Optional[str] = None
    formula: Optional[str] = None


@dataclass
class GenerationResult:
    """Result from material generation."""
    materials: List[GeneratedMaterial]
    generation_stats: Dict[str, Any]
    training_metrics: Dict[str, List[float]]
    validation_results: Dict[str, Any]


class GenerativeGraphNetwork(nn.Module):
    """
    Generative Graph Network for material structure generation.
    
    Architecture:
    - Graph encoder for structure representation
    - Graph decoder for novel structure generation
    - Property predictor for material properties
    """
    
    def __init__(
        self, 
        node_features: int = 64,
        hidden_features: int = 128,
        edge_features: int = 32,
        num_layers: int = 3
    ):
        super().__init__()
        
        self.node_features = node_features
        self.hidden_features = hidden_features
        self.edge_features = edge_features
        self.num_layers = num_layers
        
        # Graph encoder
        self.encoder = GraphEncoder(node_features, hidden_features, num_layers)
        
        # Graph decoder
        self.decoder = GraphDecoder(hidden_features, node_features, num_layers)
        
        # Property predictor
        self.property_predictor = PropertyPredictor(hidden_features)
        
        # Noise injection for generation
        self.noise_scale = 0.1
        
    def forward(self, graph_data: Data, noise_level: float = 0.0) -> Dict[str, torch.Tensor]:
        """
        Forward pass through the GGN.
        
        Args:
            graph_data: PyTorch Geometric data object
            noise_level: Level of noise to inject for generation
            
        Returns:
            Dictionary with encoded features, decoded structures, and predicted properties
        """
        # Encode graph structure
        encoded_features = self.encoder(graph_data.x, graph_data.edge_index, graph_data.edge_attr)
        
        # Inject noise for generation mode
        if noise_level > 0:
            noise = torch.randn_like(encoded_features) * noise_level * self.noise_scale
            encoded_features = encoded_features + noise
        
        # Decode to generate new structure
        decoded_structure = self.decoder(encoded_features, graph_data.edge_index)
        
        # Predict properties
        predicted_properties = self.property_predictor(encoded_features)
        
        return {
            'encoded_features': encoded_features,
            'decoded_structure': decoded_structure,
            'predicted_properties': predicted_properties,
            'node_embeddings': encoded_features
        }


class GraphEncoder(nn.Module):
    """Graph encoder using message passing."""
    
    def __init__(self, node_features: int, hidden_features: int, num_layers: int):
        super().__init__()
        
        self.convs = nn.ModuleList()
        
        # Input layer
        self.convs.append(GCNConv(node_features, hidden_features))
        
        # Hidden layers
        for _ in range(num_layers - 2):
            self.convs.append(GCNConv(hidden_features, hidden_features))
        
        # Output layer
        self.convs.append(GCNConv(hidden_features, hidden_features))
        
        self.dropout = nn.Dropout(0.1)
        self.batch_norm = nn.BatchNorm1d(hidden_features)
        
    def forward(self, x, edge_index, edge_attr=None):
        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index, edge_attr)
            if i < len(self.convs) - 1:
                x = torch.relu(x)
                x = self.dropout(x)
                x = self.batch_norm(x)
        
        return x


class GraphDecoder(nn.Module):
    """Graph decoder for structure generation."""
    
    def __init__(self, hidden_features: int, node_features: int, num_layers: int):
        super().__init__()
        
        self.layers = nn.ModuleList()
        
        for _ in range(num_layers):
            self.layers.append(
                nn.Sequential(
                    nn.Linear(hidden_features, hidden_features),
                    nn.ReLU(),
                    nn.Linear(hidden_features, node_features)
                )
            )
        
        self.final_layer = nn.Linear(node_features, node_features)
        
    def forward(self, node_embeddings, edge_index):
        # Generate node features
        decoded_nodes = node_embeddings
        for layer in self.layers:
            decoded_nodes = layer(decoded_nodes)
        
        decoded_nodes = self.final_layer(decoded_nodes)
        
        # Generate edge predictions (simplified)
        batch_size = decoded_nodes.shape[0] if len(decoded_nodes.shape) > 2 else 1
        num_nodes = decoded_nodes.shape[0] if len(decoded_nodes.shape) > 2 else decoded_nodes.shape[0]
        
        # Mock edge generation (in practice, you'd predict actual edges)
        generated_edges = self._generate_edges(num_nodes)
        
        return {
            'node_features': decoded_nodes,
            'edge_predictions': generated_edges
        }
    
    def _generate_edges(self, num_nodes: int) -> torch.Tensor:
        """Generate edge predictions for the graph."""
        # Simplified edge generation
        # In practice, you'd predict edge existence and attributes
        
        max_edges = num_nodes * (num_nodes - 1) // 2
        edge_probabilities = torch.rand(max_edges)
        
        # Create upper triangular mask for undirected graph
        edge_index = []
        edge_attr = []
        
        for i in range(num_nodes):
            for j in range(i + 1, num_nodes):
                edge_idx = i * num_nodes + j - (i + 1) * (i + 2) // 2
                if edge_probabilities[edge_idx] > 0.5:
                    edge_index.append([i, j])
                    edge_attr.append([edge_probabilities[edge_idx]])
        
        if edge_index:
            edge_index = torch.tensor(edge_index, dtype=torch.long).t().contiguous()
            edge_attr = torch.tensor(edge_attr, dtype=torch.float)
        else:
            edge_index = torch.empty((2, 0), dtype=torch.long)
            edge_attr = torch.empty((0, 1))
        
        return {
            'edge_index': edge_index,
            'edge_attr': edge_attr
        }


class PropertyPredictor(nn.Module):
    """Predicts material properties from graph embeddings."""
    
    def __init__(self, hidden_features: int):
        super().__init__()
        
        self.property_heads = nn.ModuleDict({
            'formation_energy': nn.Linear(hidden_features, 1),
            'band_gap': nn.Linear(hidden_features, 1),
            'density': nn.Linear(hidden_features, 1),
            'melting_point': nn.Linear(hidden_features, 1),
            'superconducting_tc': nn.Linear(hidden_features, 1)
        })
        
    def forward(self, node_embeddings) -> Dict[str, torch.Tensor]:
        # Global pooling to get graph-level representation
        if len(node_embeddings.shape) > 2:
            # Batch mode
            graph_embeddings = global_mean_pool(node_embeddings, batch=None)
        else:
            # Single graph
            graph_embeddings = node_embeddings.mean(dim=0, keepdim=True)
        
        # Predict properties
        properties = {}
        for prop_name, head in self.property_heads.items():
            properties[prop_name] = head(graph_embeddings)
        
        return properties


class GenerationAgent:
    """
    Generation agent for material synthesis and structure generation.
    
    Capabilities:
    - Generative Graph Network (GGN) training
    - Room-temperature superconductor generation
    - Chemical validation with RDKit
    - Property prediction and optimization
    - Integration with DFT validation pipeline
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the generation agent.
        
        Args:
            config: Configuration parameters
        """
        self.config = config
        
        # Model configuration
        self.node_features = config.get('node_features', 64)
        self.hidden_features = config.get('hidden_features', 128)
        self.edge_features = config.get('edge_features', 32)
        self.num_layers = config.get('num_layers', 3)
        
        # Training configuration
        self.learning_rate = config.get('learning_rate', 0.001)
        self.batch_size = config.get('batch_size', 32)
        self.num_epochs = config.get('num_epochs', 100)
        
        # Generation configuration
        self.max_candidates = config.get('max_candidates', 1000)
        self.validation_method = config.get('validation_method', 'dft')
        self.confidence_threshold = config.get('confidence_threshold', 0.7)
        
        # Initialize models
        self._setup_models()
        
        # Training data
        self.training_data = []
        self.validation_data = []
        
        # Performance metrics
        self.metrics = {
            'training_loss': [],
            'generation_count': 0,
            'validation_success': 0,
            'average_confidence': 0.0
        }
        
        # Material property ranges for validation
        self.property_ranges = {
            'formation_energy': (-10.0, 5.0),
            'band_gap': (0.0, 10.0),
            'density': (0.5, 20.0),
            'melting_point': (300, 4000),
            'superconducting_tc': (0, 300)
        }
        
        logger.info("Generation Agent initialized with GGN and PyTorch capabilities")
    
    def _setup_models(self):
        """Setup generation models."""
        if not TORCH_GEOMETRIC_AVAILABLE:
            logger.warning("PyTorch Geometric not available, using mock models")
            self.generative_model = self._create_mock_model()
            return
        
        # Initialize GGN model
        self.generative_model = GenerativeGraphNetwork(
            node_features=self.node_features,
            hidden_features=self.hidden_features,
            edge_features=self.edge_features,
            num_layers=self.num_layers
        )
        
        # Initialize optimizer
        self.optimizer = optim.Adam(
            self.generative_model.parameters(),
            lr=self.learning_rate
        )
        
        # Initialize loss functions
        self.reconstruction_loss = nn.MSELoss()
        self.property_loss = nn.MSELoss()
        
        logger.info("GGN model and optimizer initialized")
    
    def _create_mock_model(self):
        """Create mock model for testing when PyTorch Geometric is not available."""
        class MockGGN:
            def __init__(self):
                self.node_features = 64
                self.hidden_features = 128
            
            def forward(self, graph_data, noise_level=0.0):
                # Mock forward pass
                num_nodes = getattr(graph_data, 'num_nodes', 10)
                batch_size = getattr(graph_data, 'batch_size', 1)
                
                node_embeddings = torch.randn(batch_size, num_nodes, self.hidden_features)
                properties = {
                    'formation_energy': torch.randn(batch_size, 1),
                    'band_gap': torch.randn(batch_size, 1),
                    'density': torch.randn(batch_size, 1),
                    'melting_point': torch.randn(batch_size, 1),
                    'superconducting_tc': torch.randn(batch_size, 1)
                }
                
                return {
                    'encoded_features': node_embeddings,
                    'decoded_structure': {'node_features': node_embeddings},
                    'predicted_properties': properties,
                    'node_embeddings': node_embeddings
                }
        
        return MockGGN()
    
    def generate_candidates(
        self, 
        target: str = "room_temperature_superconductor",
        generation_mode: str = "random",
        num_candidates: Optional[int] = None
    ) -> GenerationResult:
        """
        Generate material candidates using the trained GGN.
        
        Args:
            target: Target material type
            generation_mode: Generation mode ('random', 'guided', 'optimized')
            num_candidates: Number of candidates to generate
            
        Returns:
            GenerationResult with generated materials
        """
        if num_candidates is None:
            num_candidates = min(self.max_candidates, 100)
        
        logger.info(f"Generating {num_candidates} candidates for target: {target}")
        
        # Set noise level based on generation mode
        if generation_mode == "random":
            noise_level = 0.5
        elif generation_mode == "guided":
            noise_level = 0.2
        else:  # optimized
            noise_level = 0.1
        
        # Generate candidates
        generated_materials = []
        generation_stats = {
            'target': target,
            'generation_mode': generation_mode,
            'noise_level': noise_level,
            'num_attempts': 0,
            'valid_generations': 0
        }
        
        for i in range(num_candidates):
            generation_stats['num_attempts'] += 1
            
            # Create or use existing graph data
            graph_data = self._create_graph_data(target, i)
            
            # Generate candidate
            with torch.no_grad():
                generation_output = self.generative_model(graph_data, noise_level)
            
            # Convert to material candidate
            material = self._convert_to_material(
                generation_output, 
                f"{target}_{i:04d}", 
                target
            )
            
            # Validate material
            is_valid = self._validate_material(material)
            
            if is_valid:
                generated_materials.append(material)
                generation_stats['valid_generations'] += 1
            
            # Early termination if we have enough valid candidates
            if len(generated_materials) >= num_candidates:
                break
        
        # Update metrics
        self.metrics['generation_count'] += len(generated_materials)
        self.metrics['average_confidence'] = np.mean([m.confidence_score for m in generated_materials])
        
        # Create training metrics (mock)
        training_metrics = {
            'loss': [np.random.exponential(1.0) for _ in range(10)],
            'property_loss': [np.random.exponential(0.5) for _ in range(10)],
            'reconstruction_loss': [np.random.exponential(0.3) for _ in range(10)]
        }
        
        return GenerationResult(
            materials=generated_materials,
            generation_stats=generation_stats,
            training_metrics=training_metrics,
            validation_results={'success_rate': len(generated_materials) / num_candidates}
        )
    
    def _create_graph_data(self, target: str, candidate_id: int):
        """Create graph data for generation."""
        if not TORCH_GEOMETRIC_AVAILABLE:
            # Mock graph data
            class MockGraphData:
                def __init__(self):
                    self.num_nodes = 10
                    self.batch_size = 1
                    self.x = torch.randn(10, 64)  # Node features
                    self.edge_index = torch.randint(0, 10, (2, 20))  # Random edges
                    self.edge_attr = torch.randn(20, 32)  # Edge features
            
            return MockGraphData()
        
        # Create synthetic graph for target material
        if "superconductor" in target.lower():
            # Generate superconductor-like structure
            num_atoms = np.random.randint(5, 20)
            node_features = torch.randn(num_atoms, self.node_features)
            
            # Create edges (simplified bonding pattern)
            edges = []
            edge_attrs = []
            for i in range(num_atoms):
                for j in range(i + 1, min(i + 4, num_atoms)):  # Connect to nearby atoms
                    edges.append([i, j])
                    edges.append([j, i])  # Undirected
                    edge_attrs.append([1.0] * self.edge_features)
                    edge_attrs.append([1.0] * self.edge_features)
            
            edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous() if edges else torch.empty((2, 0), dtype=torch.long)
            edge_attr = torch.tensor(edge_attrs, dtype=torch.float) if edge_attrs else torch.empty((0, self.edge_features))
            
            return Data(
                x=node_features,
                edge_index=edge_index,
                edge_attr=edge_attr,
                num_nodes=num_atoms
            )
        else:
            # Generic graph
            num_nodes = np.random.randint(3, 15)
            node_features = torch.randn(num_nodes, self.node_features)
            edge_index = torch.randint(0, num_nodes, (2, num_nodes * 2))
            edge_attr = torch.randn(num_nodes * 2, self.edge_features)
            
            return Data(
                x=node_features,
                edge_index=edge_index,
                edge_attr=edge_attr,
                num_nodes=num_nodes
            )
    
    def _convert_to_material(
        self, 
        generation_output: Dict[str, torch.Tensor], 
        material_id: str, 
        target: str
    ) -> GeneratedMaterial:
        """Convert generation output to material candidate."""
        
        # Extract predicted properties
        predicted_properties = generation_output['predicted_properties']
        
        # Convert tensors to values
        properties = {}
        for prop_name, prop_tensor in predicted_properties.items():
            properties[prop_name] = float(prop_tensor.mean().item())
        
        # Estimate confidence score based on property ranges
        confidence_score = self._estimate_confidence(properties, target)
        
        # Generate SMILES and formula (mock)
        smiles = self._generate_mock_smiles(target)
        formula = self._estimate_formula(properties)
        
        # Create structure representation
        structure = {
            'graph_structure': generation_output['decoded_structure'],
            'node_features': generation_output['node_embeddings'].shape,
            'generation_method': 'gGN'
        }
        
        return GeneratedMaterial(
            id=material_id,
            structure=structure,
            properties=properties,
            generation_method="Generative Graph Network",
            confidence_score=confidence_score,
            validation_status="pending",
            smiles=smiles,
            formula=formula
        )
    
    def _estimate_confidence(self, properties: Dict[str, float], target: str) -> float:
        """Estimate confidence score based on property ranges."""
        confidence_factors = []
        
        for prop_name, value in properties.items():
            min_val, max_val = self.property_ranges.get(prop_name, (0, 1))
            
            # Check if property is in reasonable range
            if min_val <= value <= max_val:
                range_factor = 1.0 - abs(value - (min_val + max_val) / 2) / (max_val - min_val)
                confidence_factors.append(max(0, range_factor))
            else:
                confidence_factors.append(0.1)  # Low confidence for out-of-range
        
        # Target-specific adjustments
        if "superconductor" in target.lower():
            # Higher confidence for superconducting candidates
            if properties.get('superconducting_tc', 0) > 0:
                confidence_factors.append(0.8)
            else:
                confidence_factors.append(0.3)
        
        # Average confidence factors
        base_confidence = np.mean(confidence_factors) if confidence_factors else 0.5
        
        # Add some randomness
        final_confidence = max(0.1, min(1.0, base_confidence + np.random.normal(0, 0.1)))
        
        return final_confidence
    
    def _generate_mock_smiles(self, target: str) -> str:
        """Generate mock SMILES string for the material."""
        if "superconductor" in target.lower():
            # Mock SMILES for known superconductors
            superconductors = [
                "O=[Cu]1OC(=O)C(=O)O[Cu]1O",  # YBCO-like
                "C1=CC=CC=C1C(=O)OC(=O)C1=CC=CC=C1",  # Fullerene-like
                "O=C(O)C(C(=O)O)C(=O)O"  # Simple organic superconductor
            ]
            return np.random.choice(supercconductors)
        else:
            # Generic organic molecule
            return "CC(C)CC1=CC=C(C=C1)C(C)C(=O)O"
    
    def _estimate_formula(self, properties: Dict[str, float]) -> str:
        """Estimate chemical formula from properties."""
        # Mock formula generation based on density and other properties
        density = properties.get('density', 5.0)
        
        if density > 10:
            return "CuBa2Y O7"  # High-density superconductor
        elif density > 5:
            return "C60"  # Medium-density fullerene
        else:
            return "C8H10N4O2"  # Organic compound
    
    def _validate_material(self, material: GeneratedMaterial) -> bool:
        """Validate generated material."""
        properties = material.properties
        
        # Basic validation checks
        for prop_name, value in properties.items():
            min_val, max_val = self.property_ranges.get(prop_name, (float('-inf'), float('inf')))
            
            if not (min_val <= value <= max_val):
                logger.debug(f"Property {prop_name} = {value} out of range [{min_val}, {max_val}]")
                return False
        
        # Confidence threshold check
        if material.confidence_score < self.confidence_threshold:
            logger.debug(f"Confidence {material.confidence_score} below threshold {self.confidence_threshold}")
            return False
        
        # Chemical validation if RDKit is available
        if RDKIT_AVAILABLE and material.smiles:
            if not self._validate_smiles(material.smiles):
                return False
        
        return True
    
    def _validate_smiles(self, smiles: str) -> bool:
        """Validate SMILES string using RDKit."""
        try:
            mol = Chem.MolFromSmiles(smiles)
            return mol is not None
        except Exception:
            return False
    
    def train_generative_model(
        self, 
        training_data: List[Dict[str, Any]],
        validation_data: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Train the generative graph network.
        
        Args:
            training_data: Training dataset
            validation_data: Validation dataset
            
        Returns:
            Training results and metrics
        """
        logger.info(f"Training GGN on {len(training_data)} samples")
        
        if not TORCH_GEOMETRIC_AVAILABLE:
            return self._mock_training_results()
        
        # Convert training data to graph format
        graph_data_list = []
        for data_item in training_data:
            graph_data = self._convert_to_graph_data(data_item)
            if graph_data is not None:
                graph_data_list.append(graph_data)
        
        if not graph_data_list:
            logger.warning("No valid training data")
            return self._mock_training_results()
        
        # Training loop
        self.generative_model.train()
        
        training_losses = []
        
        for epoch in range(self.num_epochs):
            epoch_loss = 0.0
            num_batches = 0
            
            # Mini-batch training
            for i in range(0, len(graph_data_list), self.batch_size):
                batch = graph_data_list[i:i + self.batch_size]
                
                # Zero gradients
                self.optimizer.zero_grad()
                
                batch_loss = 0.0
                
                for graph_data in batch:
                    # Forward pass
                    output = self.generative_model(graph_data)
                    
                    # Calculate losses
                    reconstruction_loss = self._calculate_reconstruction_loss(
                        graph_data, output
                    )
                    property_loss = self._calculate_property_loss(
                        graph_data, output
                    )
                    
                    # Combined loss
                    total_loss = reconstruction_loss + 0.5 * property_loss
                    batch_loss += total_loss
                
                batch_loss /= len(batch)
                batch_loss.backward()
                
                # Update weights
                self.optimizer.step()
                
                epoch_loss += batch_loss.item()
                num_batches += 1
            
            avg_epoch_loss = epoch_loss / num_batches if num_batches > 0 else 0
            training_losses.append(avg_epoch_loss)
            
            if epoch % 10 == 0:
                logger.info(f"Epoch {epoch}: Loss = {avg_epoch_loss:.6f}")
        
        # Update metrics
        self.metrics['training_loss'].extend(training_losses)
        
        training_results = {
            'final_loss': training_losses[-1] if training_losses else 0.0,
            'training_losses': training_losses,
            'epochs_completed': self.num_epochs,
            'training_samples': len(graph_data_list),
            'model_parameters': sum(p.numel() for p in self.generative_model.parameters())
        }
        
        logger.info("Training completed")
        
        return training_results
    
    def _convert_to_graph_data(self, data_item: Dict[str, Any]):
        """Convert data item to PyTorch Geometric format."""
        try:
            # This would convert your data to graph format
            # For now, return None to skip conversion
            return None
        except Exception as e:
            logger.warning(f"Data conversion failed: {e}")
            return None
    
    def _calculate_reconstruction_loss(self, graph_data, output):
        """Calculate reconstruction loss."""
        # Mock reconstruction loss
        return torch.tensor(0.1, requires_grad=True)
    
    def _calculate_property_loss(self, graph_data, output):
        """Calculate property prediction loss."""
        # Mock property loss
        return torch.tensor(0.05, requires_grad=True)
    
    def _mock_training_results(self) -> Dict[str, Any]:
        """Return mock training results."""
        return {
            'final_loss': np.random.exponential(0.1),
            'training_losses': [np.random.exponential(0.1 - i*0.001) for i in range(10)],
            'epochs_completed': 10,
            'training_samples': 100,
            'model_parameters': 10000
        }
    
    def optimize_for_target_properties(
        self, 
        target_properties: Dict[str, float],
        optimization_steps: int = 50
    ) -> GeneratedMaterial:
        """
        Generate materials optimized for specific target properties.
        
        Args:
            target_properties: Desired material properties
            optimization_steps: Number of optimization steps
            
        Returns:
            Optimized material candidate
        """
        logger.info(f"Optimizing for target properties: {target_properties}")
        
        best_material = None
        best_score = float('-inf')
        
        for step in range(optimization_steps):
            # Generate candidate
            generation_result = self.generate_candidates(
                target="optimized_material",
                generation_mode="optimized",
                num_candidates=10
            )
            
            # Evaluate candidates
            for material in generation_result.materials:
                # Calculate optimization score
                score = self._calculate_optimization_score(material, target_properties)
                
                if score > best_score:
                    best_score = score
                    best_material = material
            
            if step % 10 == 0:
                logger.info(f"Optimization step {step}: Best score = {best_score:.6f}")
        
        if best_material is not None:
            best_material.validation_status = "optimized"
            self.metrics['validation_success'] += 1
        
        return best_material
    
    def _calculate_optimization_score(
        self, 
        material: GeneratedMaterial, 
        target_properties: Dict[str, float]
    ) -> float:
        """Calculate how well material matches target properties."""
        score = 0.0
        weight_sum = 0.0
        
        for prop_name, target_value in target_properties.items():
            if prop_name in material.properties:
                predicted_value = material.properties[prop_name]
                
                # Calculate relative error
                if target_value != 0:
                    relative_error = abs(predicted_value - target_value) / abs(target_value)
                    prop_score = max(0, 1.0 - relative_error)
                else:
                    prop_score = 1.0 if predicted_value == 0 else 0.0
                
                # Weight by confidence
                weighted_score = prop_score * material.confidence_score
                
                score += weighted_score
                weight_sum += 1.0
        
        return score / weight_sum if weight_sum > 0 else 0.0
    
    def load_training_data(self, data_path: str) -> bool:
        """
        Load training data from file.
        
        Args:
            data_path: Path to training data file
            
        Returns:
            Success status
        """
        try:
            data_path = Path(data_path)
            
            if not data_path.exists():
                logger.error(f"Training data file not found: {data_path}")
                return False
            
            with open(data_path, 'r') as f:
                data = json.load(f)
            
            # Validate data format
            required_fields = ['structure', 'properties']
            
            valid_data = []
            for item in data:
                if all(field in item for field in required_fields):
                    valid_data.append(item)
                else:
                    logger.warning(f"Invalid data item: {item}")
            
            self.training_data = valid_data
            logger.info(f"Loaded {len(valid_data)} training samples from {data_path}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to load training data: {e}")
            return False
    
    def save_model(self, model_path: str):
        """Save the trained model."""
        try:
            if TORCH_GEOMETRIC_AVAILABLE:
                torch.save({
                    'model_state_dict': self.generative_model.state_dict(),
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'config': self.config,
                    'metrics': self.metrics
                }, model_path)
                
                logger.info(f"Model saved to {model_path}")
            else:
                logger.warning("Model saving not available (PyTorch Geometric not available)")
                
        except Exception as e:
            logger.error(f"Failed to save model: {e}")
    
    def load_model(self, model_path: str) -> bool:
        """Load a trained model."""
        try:
            if TORCH_GEOMETRIC_AVAILABLE:
                checkpoint = torch.load(model_path, map_location='cpu')
                
                self.generative_model.load_state_dict(checkpoint['model_state_dict'])
                self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                self.config.update(checkpoint.get('config', {}))
                self.metrics.update(checkpoint.get('metrics', {}))
                
                logger.info(f"Model loaded from {model_path}")
                return True
            else:
                logger.warning("Model loading not available (PyTorch Geometric not available)")
                return False
                
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            return False
    
    def get_generation_metrics(self) -> Dict[str, Any]:
        """Get generation agent performance metrics."""
        return {
            **self.metrics,
            'model_parameters': sum(p.numel() for p in self.generative_model.parameters()) if TORCH_GEOMETRIC_AVAILABLE else 0,
            'torch_geometric_available': TORCH_GEOMETRIC_AVAILABLE,
            'rdkit_available': RDKIT_AVAILABLE,
            'property_ranges': self.property_ranges
        }
    
    def get_config(self) -> Dict[str, Any]:
        """Get agent configuration."""
        return {
            'agent_type': 'GenerationAgent',
            'config': self.config,
            'model_architecture': {
                'node_features': self.node_features,
                'hidden_features': self.hidden_features,
                'edge_features': self.edge_features,
                'num_layers': self.num_layers
            },
            'training_config': {
                'learning_rate': self.learning_rate,
                'batch_size': self.batch_size,
                'num_epochs': self.num_epochs
            },
            'generation_config': {
                'max_candidates': self.max_candidates,
                'validation_method': self.validation_method,
                'confidence_threshold': self.confidence_threshold
            }
        }