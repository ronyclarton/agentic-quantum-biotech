"""
Reasoning Agent - ReAct Implementation
=====================================

Implements ReAct (Reason-Act-Observe) patterns using Llama-3.1-Nemotron-Nano-8B-v1 NIM
for autonomous reasoning, task planning, and delegation to sub-agents.

Key Features:
- ReAct reasoning loops (Reason-Act-Observe)
- Task decomposition and planning
- Multi-agent coordination
- Dynamic strategy adaptation
- Innovation scanning integration

Author: MiniMax Agent
License: MIT
"""

import torch
import json
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import re
from transformers import AutoTokenizer, AutoModelForCausalLM

logger = logging.getLogger(__name__)


@dataclass
class ReasoningResult:
    """Result of reasoning process."""
    conclusion: str
    confidence: float
    reasoning_steps: List[str]
    evidence: List[str]
    implications: List[str]


@dataclass
class ActionPlan:
    """Plan for executing a task."""
    actions: List[Dict[str, Any]]
    dependencies: List[Tuple[str, str]]  # (action_id, dependency_action_id)
    estimated_cost: float
    priority_order: List[str]


class ReasoningAgent:
    """
    Agent responsible for ReAct reasoning and task planning.
    
    Uses Llama-3.1-Nemotron-Nano-8B-v1 NIM to implement:
    - Reason: Analyze task and formulate plan
    - Act: Delegate to specialized agents
    - Observe: Process results and adapt strategy
    """
    
    def __init__(self, llm: torch.nn.Module, tokenizer, config: Dict[str, Any]):
        """
        Initialize the reasoning agent.
        
        Args:
            llm: The LLM model (typically Llama-3.1-Nemotron-Nano-8B-v1)
            tokenizer: Tokenizer for the LLM
            config: Configuration parameters
        """
        self.llm = llm
        self.tokenizer = tokenizer
        self.config = config
        
        # ReAct prompt templates
        self.react_templates = self._load_react_templates()
        
        # Agent capabilities registry
        self.agent_capabilities = {
            'biotech': ['sequence_analysis', 'genetic_evolution', 'protein_optimization'],
            'quantum': ['circuit_optimization', 'vqe_calculation', 'qaoa_heuristics'],
            'retrieval': ['knowledge_search', 'embedding_similarity', 'context_retrieval'],
            'generation': ['material_synthesis', 'structure_generation', 'validation']
        }
        
        # Task patterns for classification
        self.task_patterns = {
            'material_discovery': ['discover', 'find', 'generate', 'synthesize', 'rts', 'superconductor'],
            'protein_optimization': ['protein', 'enzyme', 'crispr', 'glp', 'biotech'],
            'quantum_simulation': ['quantum', 'vqe', 'qaoa', 'circuit', 'simulation'],
            'data_analysis': ['analyze', 'study', 'investigate', 'examine']
        }
        
        logger.info("Reasoning Agent initialized with ReAct capabilities")
    
    def _load_react_templates(self) -> Dict[str, str]:
        """Load ReAct prompt templates for different scenarios."""
        return {
            'material_discovery': """
You are an expert in material science and AI. Analyze this task and create a plan.

Task: {task_description}

Available agents and their capabilities:
- biotech: sequence analysis, genetic evolution, protein optimization
- quantum: circuit optimization, VQE calculation, QAOA heuristics  
- retrieval: knowledge search, embedding similarity, context retrieval
- generation: material synthesis, structure generation, validation

Follow the ReAct format:

Thought: [Your reasoning about the task]
Action: [agent_name:action_name:parameters]
Observation: [Expected outcome or result]
... (repeat until confident)
Final Answer: [Your conclusion and recommended action]

Remember to consider quantum-biotech fusion opportunities and federated learning benefits.
            """,
            
            'protein_optimization': """
You are a bioengineering expert. Analyze this protein optimization task.

Task: {task_description}

Consider:
- BioPython for sequence analysis
- DEAP genetic algorithms for optimization
- Quantum circuits for enhanced search
- CRISPR and GLP-1 optimization targets

Thought: [Reason about the biological problem]
Action: [biotech:analyze_sequence:protein_sequence]
Action: [quantum:optimize_fitness:bio_data]
Final Answer: [Optimization strategy]
            """,
            
            'quantum_simulation': """
You are a quantum computing expert. Analyze this quantum simulation task.

Task: {task_description}

Available quantum capabilities:
- PennyLane circuits
- Qiskit runtime
- VQE energy calculations
- QAOA optimization
- Bio-quantum entanglement

Thought: [Quantum reasoning]
Action: [quantum:create_circuit:circuit_parameters]
Action: [retrieval:search_qc_papers:topic]
Final Answer: [Quantum strategy]
            """
        }
    
    def reason_about_task(self, task) -> ReasoningResult:
        """
        Use ReAct reasoning to analyze a task.
        
        Args:
            task: Task object to reason about
            
        Returns:
            ReasoningResult with analysis and plan
        """
        # Classify task type
        task_type = self._classify_task_type(task.parameters)
        
        # Get appropriate template
        template = self.react_templates.get(task_type, self.react_templates['material_discovery'])
        
        # Format task description
        task_description = self._format_task_description(task)
        
        # Generate ReAct reasoning
        reasoning_steps = self._generate_react_reasoning(
            template.format(task_description=task_description)
        )
        
        # Extract conclusion and confidence
        conclusion = self._extract_conclusion(reasoning_steps)
        confidence = self._calculate_confidence(reasoning_steps)
        
        # Extract evidence and implications
        evidence = self._extract_evidence(reasoning_steps)
        implications = self._extract_implications(reasoning_steps)
        
        return ReasoningResult(
            conclusion=conclusion,
            confidence=confidence,
            reasoning_steps=reasoning_steps,
            evidence=evidence,
            implications=implications
        )
    
    def _classify_task_type(self, parameters: Dict[str, Any]) -> str:
        """Classify the task type based on parameters."""
        task_text = str(parameters).lower()
        
        for task_type, keywords in self.task_patterns.items():
            if any(keyword in task_text for keyword in keywords):
                return task_type
        
        return 'material_discovery'  # Default
    
    def _format_task_description(self, task) -> str:
        """Format task for the reasoning prompt."""
        return f"""
Task Type: {task.task_type}
Parameters: {task.parameters}
Priority: {task.priority}

Objective: Complete this {task.task_type} task with maximum efficiency
and innovation by leveraging the available agentic capabilities.
        """.strip()
    
    def _generate_react_reasoning(self, prompt: str) -> List[str]:
        """Generate ReAct reasoning steps."""
        try:
            # Tokenize input
            inputs = self.tokenizer.encode(prompt, return_tensors="pt")
            
            # Generate response
            with torch.no_grad():
                outputs = self.llm.generate(
                    inputs,
                    max_length=inputs.shape[1] + 512,
                    temperature=0.7,
                    do_sample=True,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # Decode response
            response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Extract ReAct steps
            react_steps = self._parse_react_steps(response)
            
            return react_steps
            
        except Exception as e:
            logger.warning(f"ReAct generation failed: {e}")
            # Return mock reasoning steps for demonstration
            return self._generate_mock_reasoning()
    
    def _parse_react_steps(self, response: str) -> List[str]:
        """Parse ReAct steps from LLM response."""
        # Split by thought-action-observation pattern
        steps = []
        
        # Look for Thought, Action, Observation patterns
        patterns = [
            r'Thought:\s*([^\n]+)',
            r'Action:\s*([^\n]+)',
            r'Observation:\s*([^\n]+)',
            r'Final Answer:\s*([^\n]+)'
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, response, re.IGNORECASE)
            steps.extend(matches)
        
        return steps if steps else self._generate_mock_reasoning()
    
    def _generate_mock_reasoning(self) -> List[str]:
        """Generate mock reasoning for demonstration."""
        return [
            "Thought: This is a material discovery task that requires innovative approaches.",
            "Action: generation:generate_candidates:target=room_temperature_superconductor",
            "Observation: Generated 1000 candidate structures for evaluation.",
            "Action: quantum:optimize_fitness:bio_data=default",
            "Observation: Quantum optimization improved fitness by 2.6x.",
            "Action: biotech:analyze_sequences:protein_prior=GLP1",
            "Observation: Bio-priors provide additional optimization guidance.",
            "Final Answer: Use federated approach with quantum-biotech fusion for best results."
        ]
    
    def _extract_conclusion(self, reasoning_steps: List[str]) -> str:
        """Extract the conclusion from reasoning steps."""
        for step in reasoning_steps:
            if 'Final Answer:' in step:
                return step.split('Final Answer:')[1].strip()
        
        # Default conclusion
        return "Task requires multi-agent collaboration with quantum-biotech fusion approach."
    
    def _calculate_confidence(self, reasoning_steps: List[str]) -> float:
        """Calculate confidence score based on reasoning quality."""
        # Factors: number of steps, presence of specific actions, coherence
        base_confidence = 0.5
        
        # More steps generally indicate thorough reasoning
        if len(reasoning_steps) > 5:
            base_confidence += 0.2
        
        # Presence of final answer indicates completion
        if any('Final Answer' in step for step in reasoning_steps):
            base_confidence += 0.2
        
        # Specific agent actions increase confidence
        agent_actions = sum(1 for step in reasoning_steps if 'Action:' in step)
        if agent_actions >= 3:
            base_confidence += 0.1
        
        return min(base_confidence, 1.0)
    
    def _extract_evidence(self, reasoning_steps: List[str]) -> List[str]:
        """Extract supporting evidence from reasoning."""
        evidence = []
        
        for step in reasoning_steps:
            if 'Observation:' in step:
                evidence.append(step.split('Observation:')[1].strip())
            elif any(keyword in step.lower() for keyword in ['research shows', 'data indicates', 'evidence suggests']):
                evidence.append(step.strip())
        
        return evidence
    
    def _extract_implications(self, reasoning_steps: List[str]) -> List[str]:
        """Extract implications from reasoning."""
        implications = []
        
        for step in reasoning_steps:
            if any(keyword in step.lower() for keyword in ['therefore', 'this means', 'implication', 'leads to']):
                implications.append(step.strip())
        
        return implications
    
    def create_action_plan(self, reasoning_result: ReasoningResult) -> ActionPlan:
        """
        Create an action plan based on reasoning results.
        
        Args:
            reasoning_result: Result from reason_about_task
            
        Returns:
            ActionPlan with executable actions
        """
        # Parse actions from reasoning
        raw_actions = self._parse_actions_from_reasoning(reasoning_result.reasoning_steps)
        
        # Validate and enhance actions
        validated_actions = []
        for action in raw_actions:
            validated_action = self._validate_action(action)
            if validated_action:
                validated_actions.append(validated_action)
        
        # Determine dependencies
        dependencies = self._analyze_dependencies(validated_actions)
        
        # Calculate estimated cost
        estimated_cost = self._calculate_cost(validated_actions)
        
        # Determine priority order
        priority_order = self._determine_priority_order(validated_actions)
        
        return ActionPlan(
            actions=validated_actions,
            dependencies=dependencies,
            estimated_cost=estimated_cost,
            priority_order=priority_order
        )
    
    def _parse_actions_from_reasoning(self, reasoning_steps: List[str]) -> List[Dict[str, Any]]:
        """Parse actions from ReAct reasoning steps."""
        actions = []
        
        for step in reasoning_steps:
            if 'Action:' in step:
                action_str = step.split('Action:')[1].strip()
                # Parse action format: agent_name:action_name:parameters
                try:
                    parts = action_str.split(':', 2)
                    if len(parts) >= 2:
                        agent_name = parts[0].strip()
                        action_name = parts[1].strip()
                        parameters = parts[2].strip() if len(parts) > 2 else "{}"
                        
                        # Try to parse parameters as JSON
                        try:
                            params_dict = json.loads(parameters)
                        except json.JSONDecodeError:
                            params_dict = {"raw": parameters}
                        
                        action = {
                            'agent': agent_name,
                            'action': action_name,
                            'parameters': params_dict
                        }
                        actions.append(action)
                        
                except Exception as e:
                    logger.warning(f"Failed to parse action '{action_str}': {e}")
        
        return actions
    
    def _validate_action(self, action: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Validate and enhance an action."""
        agent = action.get('agent')
        action_name = action.get('action')
        
        # Check if agent exists and has required capability
        if agent in self.agent_capabilities:
            if action_name in self.agent_capabilities[agent]:
                # Add estimated duration and resource requirements
                enhanced_action = action.copy()
                enhanced_action.update({
                    'estimated_duration': self._estimate_duration(agent, action_name),
                    'required_resources': self._get_resource_requirements(agent, action_name),
                    'dependencies': self._get_action_dependencies(agent, action_name)
                })
                return enhanced_action
        
        logger.warning(f"Invalid or unknown action: {agent}:{action_name}")
        return None
    
    def _estimate_duration(self, agent: str, action: str) -> float:
        """Estimate duration for an action in minutes."""
        base_durations = {
            'biotech': {'analyze_sequence': 5.0, 'evolve_architecture': 30.0},
            'quantum': {'optimize_circuit': 10.0, 'vqe_calculation': 15.0},
            'retrieval': {'search_knowledge': 2.0, 'embed_query': 1.0},
            'generation': {'generate_candidates': 20.0, 'validate_structure': 5.0}
        }
        
        return base_durations.get(agent, {}).get(action, 10.0)
    
    def _get_resource_requirements(self, agent: str, action: str) -> Dict[str, str]:
        """Get resource requirements for an action."""
        resource_map = {
            'biotech': {'cpu': 'high', 'memory': 'medium', 'gpu': 'low'},
            'quantum': {'cpu': 'medium', 'memory': 'medium', 'gpu': 'low'},
            'retrieval': {'cpu': 'low', 'memory': 'low', 'gpu': 'low'},
            'generation': {'cpu': 'medium', 'memory': 'high', 'gpu': 'high'}
        }
        
        return resource_map.get(agent, {'cpu': 'medium', 'memory': 'medium', 'gpu': 'medium'})
    
    def _get_action_dependencies(self, agent: str, action: str) -> List[str]:
        """Get dependencies for an action."""
        # Some actions depend on others
        dependency_map = {
            'quantum:optimize_fitness': ['generation:generate_candidates'],
            'biotech:analyze_sequence': ['retrieval:search_knowledge'],
            'generation:validate_structure': ['quantum:optimize_fitness']
        }
        
        key = f"{agent}:{action}"
        return dependency_map.get(key, [])
    
    def _analyze_dependencies(self, actions: List[Dict[str, Any]]) -> List[Tuple[str, str]]:
        """Analyze dependencies between actions."""
        dependencies = []
        
        for i, action in enumerate(actions):
            action_id = f"{action['agent']}:{action['action']}:{i}"
            
            for dep in action.get('dependencies', []):
                # Find the index of the dependency action
                for j, other_action in enumerate(actions):
                    other_id = f"{other_action['agent']}:{other_action['action']}:{j}"
                    if dep in other_id:
                        dependencies.append((action_id, other_id))
                        break
        
        return dependencies
    
    def _calculate_cost(self, actions: List[Dict[str, Any]]) -> float:
        """Calculate estimated cost for the action plan."""
        total_cost = 0.0
        
        for action in actions:
            duration = action.get('estimated_duration', 10.0)
            resources = action.get('required_resources', {})
            
            # Calculate cost based on duration and resource usage
            resource_cost = 0.0
            for resource, usage in resources.items():
                if usage == 'high':
                    resource_cost += 2.0
                elif usage == 'medium':
                    resource_cost += 1.0
                else:
                    resource_cost += 0.5
            
            action_cost = duration * resource_cost / 60.0  # Convert to hours
            total_cost += action_cost
        
        return total_cost
    
    def _determine_priority_order(self, actions: List[Dict[str, Any]]) -> List[str]:
        """Determine priority order for actions."""
        # Simple priority based on dependencies and resource requirements
        action_ids = [f"{action['agent']}:{action['action']}:{i}" for i, action in enumerate(actions)]
        
        # Sort by estimated duration (shorter first for quick wins)
        duration_order = sorted(action_ids, key=lambda aid: self._get_action_duration(aid))
        
        return duration_order
    
    def _get_action_duration(self, action_id: str) -> float:
        """Get duration for an action by ID."""
        parts = action_id.split(':')
        if len(parts) >= 2:
            agent, action = parts[0], parts[1]
            return self._estimate_duration(agent, action)
        return 10.0
    
    def synthesize_results(
        self, 
        reasoning_result: ReasoningResult, 
        execution_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Synthesize final results from reasoning and execution.
        
        Args:
            reasoning_result: Results from reasoning process
            execution_results: Results from executing actions
            
        Returns:
            Synthesized final result
        """
        # Analyze execution results
        success_count = sum(1 for result in execution_results.values() if result.get('success', False))
        total_count = len(execution_results)
        
        success_rate = success_count / total_count if total_count > 0 else 0.0
        
        # Combine reasoning confidence with execution success
        final_confidence = (reasoning_result.confidence + success_rate) / 2.0
        
        # Synthesize recommendations
        recommendations = self._synthesize_recommendations(reasoning_result, execution_results)
        
        # Extract key insights
        insights = self._extract_insights(reasoning_result, execution_results)
        
        return {
            'success_rate': success_rate,
            'final_confidence': final_confidence,
            'recommendations': recommendations,
            'insights': insights,
            'next_actions': self._recommend_next_actions(execution_results),
            'quality_score': self._calculate_quality_score(reasoning_result, execution_results)
        }
    
    def _synthesize_recommendations(
        self, 
        reasoning: ReasoningResult, 
        execution: Dict[str, Any]
    ) -> List[str]:
        """Synthesize actionable recommendations."""
        recommendations = []
        
        # Analyze success patterns
        successful_agents = [name for name, result in execution.items() if result.get('success', False)]
        
        if 'quantum' in successful_agents:
            recommendations.append("Quantum optimization provided significant benefit - consider expanding quantum usage")
        
        if 'biotech' in successful_agents:
            recommendations.append("Bio-priors enhanced optimization - integrate more biotechnology components")
        
        if 'retrieval' in successful_agents:
            recommendations.append("Knowledge retrieval improved results - enhance RAG capabilities")
        
        # General recommendations based on reasoning
        if reasoning.confidence < 0.7:
            recommendations.append("Low reasoning confidence - consider gathering more data or refining approach")
        
        return recommendations
    
    def _extract_insights(self, reasoning: ReasoningResult, execution: Dict[str, Any]) -> List[str]:
        """Extract key insights from the entire process."""
        insights = []
        
        # Technical insights
        if reasoning.implications:
            insights.append("Reasoning suggests potential for quantum-biotech fusion benefits")
        
        # Performance insights
        success_agents = [name for name, result in execution.items() if result.get('success', False)]
        if len(success_agents) >= 3:
            insights.append("Multi-agent collaboration proved effective")
        
        # Innovation insights
        if reasoning.confidence > 0.8:
            insights.append("High-confidence reasoning indicates good approach selection")
        
        return insights
    
    def _recommend_next_actions(self, execution_results: Dict[str, Any]) -> List[str]:
        """Recommend next actions based on execution results."""
        next_actions = []
        
        # Check for incomplete or failed actions
        for agent_name, result in execution_results.items():
            if not result.get('success', False):
                next_actions.append(f"Retry {agent_name} with alternative parameters")
            elif result.get('confidence', 0) < 0.8:
                next_actions.append(f"Optimize {agent_name} performance")
        
        # General next steps
        next_actions.append("Consider federated scaling if single-node performance is sufficient")
        next_actions.append("Explore 2025 innovations for potential improvements")
        
        return next_actions
    
    def _calculate_quality_score(
        self, 
        reasoning: ReasoningResult, 
        execution: Dict[str, Any]
    ) -> float:
        """Calculate overall quality score."""
        reasoning_score = reasoning.confidence
        
        # Execution quality
        if execution:
            success_rate = sum(1 for r in execution.values() if r.get('success', False)) / len(execution)
            avg_confidence = sum(r.get('confidence', 0) for r in execution.values()) / len(execution)
            execution_score = (success_rate + avg_confidence) / 2.0
        else:
            execution_score = 0.0
        
        # Combined quality
        quality_score = (reasoning_score * 0.4 + execution_score * 0.6)
        
        return min(quality_score, 1.0)
    
    def get_config(self) -> Dict[str, Any]:
        """Get agent configuration."""
        return {
            'agent_type': 'ReasoningAgent',
            'config': self.config,
            'capabilities': self.agent_capabilities,
            'templates': list(self.react_templates.keys())
        }