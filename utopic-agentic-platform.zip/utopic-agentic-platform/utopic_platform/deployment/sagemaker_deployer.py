"""
AWS SageMaker Deployer
======================

Handles deployment of NIM models to AWS SageMaker endpoints.
Supports Llama-3.1-Nemotron-Nano-8B-v1 and NeMo Embedding NIM.

Key Features:
- NIM container deployment to SageMaker
- Endpoint configuration and auto-scaling
- Cost optimization and monitoring
- Integration with AWS ecosystem

Author: MiniMax Agent
License: MIT
"""

import boto3
import json
import logging
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from pathlib import Path

# SageMaker imports
try:
    import sagemaker
    from sagemaker.huggingface import HuggingFaceModel
    from sagemaker.serverless import ServerlessInferenceConfig
    from sagemaker.transformer import Transformer
    SAGEMAKER_AVAILABLE = True
except ImportError:
    SAGEMAKER_AVAILABLE = False
    logging.warning("SageMaker not available. Install with: pip install sagemaker")

logger = logging.getLogger(__name__)


@dataclass
class DeploymentConfig:
    """Configuration for SageMaker deployment."""
    model_name: str
    model_url: str
    instance_type: str
    instance_count: int = 1
    auto_scaling: bool = True
    min_capacity: int = 0
    max_capacity: int = 5
    target_value: float = 70.0  # Target utilization percentage
    timeout: int = 1800  # 30 minutes


@dataclass
class DeploymentStatus:
    """Status of SageMaker deployment."""
    endpoint_name: str
    status: str  # 'Creating', 'InService', 'Failed', etc.
    creation_time: str
    instance_type: str
    instance_count: int
    auto_scaling_enabled: bool
    endpoint_url: Optional[str] = None
    failure_reason: Optional[str] = None


class SageMakerDeployer:
    """
    Deploys and manages NIM models on AWS SageMaker.
    
    Capabilities:
    - Deploy Llama-3.1-Nemotron-Nano-8B-v1 NIM
    - Deploy NeMo Retriever Embedding NIM
    - Configure auto-scaling and cost optimization
    - Monitor endpoint health and performance
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize SageMaker deployer.
        
        Args:
            config: AWS configuration parameters
        """
        self.config = config
        
        # AWS configuration
        self.region = config.get('region', 'us-west-2')
        self.role_arn = config.get('role_arn', 'arn:aws:iam::account:role/SageMakerRole')
        self.instance_type = config.get('instance_type', 'ml.g5.2xlarge')
        
        # Initialize AWS clients
        self._setup_aws_clients()
        
        # Deployment configurations
        self.deployment_configs = {
            'nemotron_reasoning': DeploymentConfig(
                model_name='nemotron-nano-8b',
                model_url='nvcr.io/nim/nvidia/llama-3.1-nemotron-nano-8b-v1',
                instance_type=self.instance_type,
                instance_count=1
            ),
            'nemo_embedding': DeploymentConfig(
                model_name='nemo-embed-qa-4',
                model_url='nvcr.io/nim/nvidia/nv-embed-qa-4',
                instance_type='ml.g5.xlarge',  # Smaller instance for embeddings
                instance_count=1
            )
        }
        
        # Track deployed endpoints
        self.deployed_endpoints: Dict[str, DeploymentStatus] = {}
        
        logger.info("SageMaker Deployer initialized")
    
    def _setup_aws_clients(self):
        """Initialize AWS service clients."""
        try:
            self.sagemaker_client = boto3.client('sagemaker', region_name=self.region)
            self.application_autoscaling_client = boto3.client('application-autoscaling', region_name=self.region)
            self.cloudwatch_client = boto3.client('cloudwatch', region_name=self.region)
            
            logger.info("AWS clients initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize AWS clients: {e}")
            raise
    
    def deploy_nemotron_model(
        self, 
        model_name: str = 'nemotron-reasoning-endpoint',
        instance_type: Optional[str] = None,
        instance_count: Optional[int] = None,
        auto_scaling: bool = True
    ) -> DeploymentStatus:
        """
        Deploy Llama-3.1-Nemotron-Nano-8B-v1 NIM to SageMaker.
        
        Args:
            model_name: Name for the deployed model
            instance_type: SageMaker instance type
            instance_count: Number of instances
            auto_scaling: Enable auto-scaling
            
        Returns:
            DeploymentStatus with deployment information
        """
        logger.info(f"Deploying Nemotron model: {model_name}")
        
        try:
            config = self.deployment_configs['nemotron_reasoning']
            
            # Override configuration if provided
            if instance_type:
                config.instance_type = instance_type
            if instance_count:
                config.instance_count = instance_count
            config.auto_scaling = auto_scaling
            
            # Create SageMaker model
            model = HuggingFaceModel(
                model_data=config.model_url,
                role=self.role_arn,
                transformers_version="4.36.0",
                pytorch_version="2.1.0",
                py_version="py310"
            )
            
            # Deploy with serverless or regular configuration
            if auto_scaling:
                # Use serverless inference for cost optimization
                serverless_config = ServerlessInferenceConfig(
                    memory_size_in_mb=10240,  # 10GB
                    max_concurrency=10
                )
                
                predictor = model.deploy(
                    serverless_inference_config=serverless_config,
                    endpoint_name=model_name
                )
            else:
                # Regular deployment
                predictor = model.deploy(
                    initial_instance_count=config.instance_count,
                    instance_type=config.instance_type,
                    endpoint_name=model_name
                )
            
            # Wait for endpoint to be in service
            self._wait_for_endpoint(model_name)
            
            # Configure auto-scaling if requested
            if auto_scaling and not isinstance(predictor, sagemaker.serverless._ServerlessPredictor):
                self._configure_auto_scaling(model_name, config)
            
            # Get endpoint information
            endpoint_info = self.sagemaker_client.describe_endpoint(EndpointName=model_name)
            
            deployment_status = DeploymentStatus(
                endpoint_name=model_name,
                status=endpoint_info['EndpointStatus'],
                creation_time=endpoint_info['CreationTime'].isoformat(),
                instance_type=config.instance_type,
                instance_count=config.instance_count,
                auto_scaling_enabled=auto_scaling,
                endpoint_url=predictor.endpoint_url if hasattr(predictor, 'endpoint_url') else None
            )
            
            self.deployed_endpoints[model_name] = deployment_status
            
            logger.info(f"Nemotron model deployed successfully: {model_name}")
            
            return deployment_status
            
        except Exception as e:
            logger.error(f"Failed to deploy Nemotron model: {e}")
            
            # Return failed deployment status
            return DeploymentStatus(
                endpoint_name=model_name,
                status='Failed',
                creation_time=time.strftime('%Y-%m-%dT%H:%M:%S'),
                instance_type=instance_type or self.instance_type,
                instance_count=instance_count or 1,
                auto_scaling_enabled=auto_scaling,
                failure_reason=str(e)
            )
    
    def deploy_nemo_embedding_model(
        self, 
        model_name: str = 'nemo-embedding-endpoint',
        instance_type: Optional[str] = None,
        instance_count: Optional[int] = None
    ) -> DeploymentStatus:
        """
        Deploy NeMo Retriever Embedding NIM to SageMaker.
        
        Args:
            model_name: Name for the deployed model
            instance_type: SageMaker instance type
            instance_count: Number of instances
            
        Returns:
            DeploymentStatus with deployment information
        """
        logger.info(f"Deploying NeMo embedding model: {model_name}")
        
        try:
            config = self.deployment_configs['nemo_embedding']
            
            # Override configuration if provided
            if instance_type:
                config.instance_type = instance_type
            if instance_count:
                config.instance_count = instance_count
            
            # Create model for NeMo embeddings (simplified)
            model = HuggingFaceModel(
                model_data=config.model_url,
                role=self.role_arn,
                transformers_version="4.36.0",
                pytorch_version="2.1.0",
                py_version="py310"
            )
            
            # Deploy
            predictor = model.deploy(
                initial_instance_count=config.instance_count,
                instance_type=config.instance_type,
                endpoint_name=model_name
            )
            
            # Wait for endpoint
            self._wait_for_endpoint(model_name)
            
            # Get endpoint information
            endpoint_info = self.sagemaker_client.describe_endpoint(EndpointName=model_name)
            
            deployment_status = DeploymentStatus(
                endpoint_name=model_name,
                status=endpoint_info['EndpointStatus'],
                creation_time=endpoint_info['CreationTime'].isoformat(),
                instance_type=config.instance_type,
                instance_count=config.instance_count,
                auto_scaling_enabled=False,  # Embeddings typically don't need auto-scaling
                endpoint_url=predictor.endpoint_url if hasattr(predictor, 'endpoint_url') else None
            )
            
            self.deployed_endpoints[model_name] = deployment_status
            
            logger.info(f"NeMo embedding model deployed successfully: {model_name}")
            
            return deployment_status
            
        except Exception as e:
            logger.error(f"Failed to deploy NeMo embedding model: {e}")
            
            return DeploymentStatus(
                endpoint_name=model_name,
                status='Failed',
                creation_time=time.strftime('%Y-%m-%dT%H:%M:%S'),
                instance_type=instance_type or 'ml.g5.xlarge',
                instance_count=instance_count or 1,
                auto_scaling_enabled=False,
                failure_reason=str(e)
            )
    
    def _wait_for_endpoint(self, endpoint_name: str, timeout: int = 1800):
        """Wait for SageMaker endpoint to be in service."""
        logger.info(f"Waiting for endpoint {endpoint_name} to be in service...")
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                endpoint_info = self.sagemaker_client.describe_endpoint(EndpointName=endpoint_name)
                status = endpoint_info['EndpointStatus']
                
                logger.info(f"Endpoint {endpoint_name} status: {status}")
                
                if status == 'InService':
                    logger.info(f"Endpoint {endpoint_name} is in service")
                    return
                elif status == 'Failed':
                    failure_reason = endpoint_info.get('FailureReason', 'Unknown')
                    logger.error(f"Endpoint {endpoint_name} failed: {failure_reason}")
                    raise Exception(f"Endpoint deployment failed: {failure_reason}")
                
                # Wait before checking again
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Error checking endpoint status: {e}")
                break
        
        raise TimeoutError(f"Endpoint {endpoint_name} did not become in service within {timeout} seconds")
    
    def _configure_auto_scaling(self, endpoint_name: str, config: DeploymentConfig):
        """Configure auto-scaling for SageMaker endpoint."""
        try:
            # Register scalable target
            self.application_autoscaling_client.register_scalable_target(
                ServiceNamespace='sagemaker',
                ResourceId=f'endpoint/{endpoint_name}',
                ScalableDimension='sagemaker:variant:DesiredInstanceCount',
                MinCapacity=config.min_capacity,
                MaxCapacity=config.max_capacity
            )
            
            # Create scaling policy
            self.application_autoscaling_client.put_scaling_policy(
                PolicyName=f'{endpoint_name}-auto-scaling',
                ServiceNamespace='sagemaker',
                ResourceId=f'endpoint/{endpoint_name}',
                ScalableDimension='sagemaker:variant:DesiredInstanceCount',
                PolicyType='TargetTrackingScaling',
                TargetTrackingScalingPolicyConfiguration={
                    'TargetValue': config.target_value,
                    'PredefinedMetricSpecification': {
                        'PredefinedMetricType': 'SageMakerVariantInvocationsPerInstance'
                    },
                    'ScaleOutCooldown': 300,
                    'ScaleInCooldown': 300
                }
            )
            
            logger.info(f"Auto-scaling configured for endpoint {endpoint_name}")
            
        except Exception as e:
            logger.warning(f"Failed to configure auto-scaling: {e}")
    
    def get_endpoint_status(self, endpoint_name: str) -> Optional[DeploymentStatus]:
        """
        Get the current status of a deployed endpoint.
        
        Args:
            endpoint_name: Name of the endpoint
            
        Returns:
            DeploymentStatus or None if not found
        """
        try:
            endpoint_info = self.sagemaker_client.describe_endpoint(EndpointName=endpoint_name)
            
            # Check if auto-scaling is enabled
            try:
                scaling_policies = self.application_autoscaling_client.describe_scaling_policies(
                    ServiceNamespace='sagemaker',
                    ResourceId=f'endpoint/{endpoint_name}'
                )
                auto_scaling_enabled = len(scaling_policies['ScalingPolicies']) > 0
            except:
                auto_scaling_enabled = False
            
            return DeploymentStatus(
                endpoint_name=endpoint_name,
                status=endpoint_info['EndpointStatus'],
                creation_time=endpoint_info['CreationTime'].isoformat(),
                instance_type=endpoint_info.get('InstanceType', 'unknown'),
                instance_count=endpoint_info.get('InstanceCount', 1),
                auto_scaling_enabled=auto_scaling_enabled,
                endpoint_url=endpoint_info.get('EndpointArn')
            )
            
        except Exception as e:
            logger.error(f"Failed to get endpoint status for {endpoint_name}: {e}")
            return None
    
    def list_endpoints(self) -> List[DeploymentStatus]:
        """
        List all deployed endpoints.
        
        Returns:
            List of DeploymentStatus objects
        """
        try:
            endpoints = self.sagemaker_client.list_endpoints()
            endpoint_statuses = []
            
            for endpoint_summary in endpoints['Endpoints']:
                endpoint_name = endpoint_summary['EndpointName']
                status = self.get_endpoint_status(endpoint_name)
                
                if status:
                    endpoint_statuses.append(status)
            
            return endpoint_statuses
            
        except Exception as e:
            logger.error(f"Failed to list endpoints: {e}")
            return []
    
    def delete_endpoint(self, endpoint_name: str) -> bool:
        """
        Delete a SageMaker endpoint.
        
        Args:
            endpoint_name: Name of the endpoint to delete
            
        Returns:
            Success status
        """
        try:
            logger.info(f"Deleting endpoint: {endpoint_name}")
            
            # Delete auto-scaling policies first
            try:
                scaling_policies = self.application_autoscaling_client.describe_scaling_policies(
                    ServiceNamespace='sagemaker',
                    ResourceId=f'endpoint/{endpoint_name}'
                )
                
                for policy in scaling_policies['ScalingPolicies']:
                    self.application_autoscaling_client.delete_scaling_policy(
                        PolicyName=policy['PolicyName'],
                        ServiceNamespace='sagemaker',
                        ResourceId=f'endpoint/{endpoint_name}'
                    )
                
                # Deregister scalable target
                self.application_autoscaling_client.deregister_scalable_target(
                    ServiceNamespace='sagemaker',
                    ResourceId=f'endpoint/{endpoint_name}',
                    ScalableDimension='sagemaker:variant:DesiredInstanceCount'
                )
                
            except Exception as e:
                logger.warning(f"Failed to clean up auto-scaling: {e}")
            
            # Delete the endpoint
            self.sagemaker_client.delete_endpoint(EndpointName=endpoint_name)
            
            # Remove from tracking
            if endpoint_name in self.deployed_endpoints:
                del self.deployed_endpoints[endpoint_name]
            
            logger.info(f"Endpoint {endpoint_name} deleted successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete endpoint {endpoint_name}: {e}")
            return False
    
    def get_endpoint_metrics(self, endpoint_name: str, hours: int = 24) -> Dict[str, Any]:
        """
        Get CloudWatch metrics for an endpoint.
        
        Args:
            endpoint_name: Name of the endpoint
            hours: Number of hours of metrics to retrieve
            
        Returns:
            Dictionary with metrics data
        """
        try:
            end_time = time.time()
            start_time = end_time - (hours * 3600)
            
            # Get invocation metrics
            invocations = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/SageMaker',
                MetricName='Invocations',
                Dimensions=[
                    {
                        'Name': 'EndpointName',
                        'Value': endpoint_name
                    }
                ],
                StartTime=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time)),
                EndTime=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time)),
                Period=3600,
                Statistics=['Sum', 'Average'],
                Unit='Count'
            )
            
            # Get latency metrics
            latency = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/SageMaker',
                MetricName='Invocation4XXErrors',
                Dimensions=[
                    {
                        'Name': 'EndpointName',
                        'Value': endpoint_name
                    }
                ],
                StartTime=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time)),
                EndTime=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time)),
                Period=3600,
                Statistics=['Sum', 'Average'],
                Unit='Count'
            )
            
            return {
                'endpoint_name': endpoint_name,
                'invocations': invocations['Datapoints'],
                'errors': latency['Datapoints'],
                'time_range_hours': hours
            }
            
        except Exception as e:
            logger.error(f"Failed to get metrics for endpoint {endpoint_name}: {e}")
            return {}
    
    def deploy_full_platform(
        self, 
        nemotron_endpoint_name: str = 'utopic-nemotron-endpoint',
        nemo_endpoint_name: str = 'utopic-nemo-embedding'
    ) -> Dict[str, DeploymentStatus]:
        """
        Deploy the complete Utopic AI platform (both NIM models).
        
        Args:
            nemotron_endpoint_name: Name for Nemotron endpoint
            nemo_endpoint_name: Name for NeMo embedding endpoint
            
        Returns:
            Dictionary with deployment statuses
        """
        logger.info("Deploying complete Utopic AI platform...")
        
        deployment_results = {}
        
        try:
            # Deploy Nemotron reasoning model
            logger.info("Deploying Nemotron reasoning model...")
            nemotron_status = self.deploy_nemotron_model(nemotron_endpoint_name)
            deployment_results['nemotron'] = nemotron_status
            
            if nemotron_status.status == 'Failed':
                logger.error("Nemotron deployment failed")
                return deployment_results
            
            # Deploy NeMo embedding model
            logger.info("Deploying NeMo embedding model...")
            nemo_status = self.deploy_nemo_embedding_model(nemo_endpoint_name)
            deployment_results['nemo_embedding'] = nemo_status
            
            if nemo_status.status == 'Failed':
                logger.error("NeMo embedding deployment failed")
                return deployment_results
            
            logger.info("Complete Utopic AI platform deployed successfully")
            
            return deployment_results
            
        except Exception as e:
            logger.error(f"Failed to deploy complete platform: {e}")
            return deployment_results
    
    def get_deployment_cost_estimate(self, deployment_results: Dict[str, DeploymentStatus]) -> Dict[str, Any]:
        """
        Estimate deployment costs based on current configuration.
        
        Args:
            deployment_results: Results from deployment
            
        Returns:
            Dictionary with cost estimates
        """
        # AWS pricing (approximate as of 2025)
        instance_pricing = {
            'ml.g5.xlarge': {'cost_per_hour': 1.515, 'memory_gb': 32, 'vcpu': 4},
            'ml.g5.2xlarge': {'cost_per_hour': 3.045, 'memory_gb': 64, 'vcpu': 8},
            'ml.g5.4xlarge': {'cost_per_hour': 6.09, 'memory_gb': 128, 'vcpu': 16},
            'ml.g5.12xlarge': {'cost_per_hour': 18.27, 'memory_gb': 384, 'vcpu': 48}
        }
        
        cost_breakdown = {}
        total_hourly_cost = 0.0
        total_monthly_cost = 0.0
        
        for model_type, status in deployment_results.items():
            if status.status == 'InService':
                instance_info = instance_pricing.get(status.instance_type, {'cost_per_hour': 3.0})
                
                hourly_cost = instance_info['cost_per_hour'] * status.instance_count
                monthly_cost = hourly_cost * 24 * 30  # Assuming 30 days
                
                cost_breakdown[model_type] = {
                    'instance_type': status.instance_type,
                    'instance_count': status.instance_count,
                    'hourly_cost': hourly_cost,
                    'monthly_cost': monthly_cost,
                    'auto_scaling': status.auto_scaling_enabled
                }
                
                total_hourly_cost += hourly_cost
                total_monthly_cost += monthly_cost
        
        return {
            'cost_breakdown': cost_breakdown,
            'total_hourly_cost': total_hourly_cost,
            'total_monthly_cost': total_monthly_cost,
            'estimated_usage_hours_per_month': 720,  # 30 days * 24 hours
            'note': 'Costs are estimates and may vary based on actual usage and scaling'
        }
    
    def cleanup_all_endpoints(self) -> bool:
        """
        Clean up all deployed endpoints.
        
        Returns:
            Success status
        """
        try:
            endpoints = self.list_endpoints()
            success = True
            
            for endpoint_status in endpoints:
                if not self.delete_endpoint(endpoint_status.endpoint_name):
                    success = False
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to cleanup endpoints: {e}")
            return False
    
    def get_config(self) -> Dict[str, Any]:
        """Get deployer configuration."""
        return {
            'deployer_type': 'SageMakerDeployer',
            'region': self.region,
            'role_arn': self.role_arn,
            'default_instance_type': self.instance_type,
            'deployed_endpoints': list(self.deployed_endpoints.keys()),
            'sagemaker_available': SAGEMAKER_AVAILABLE
        }