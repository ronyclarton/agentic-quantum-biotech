"""
Cloud Rotation Manager
======================

Manages deployment across multiple cloud platforms for reliability
and cost optimization. Handles quota management and automatic
fallback strategies.

Key Features:
- Multi-cloud deployment coordination
- Quota monitoring and rotation
- Automatic fallback strategies
- Cost optimization across providers
- Resource usage tracking

Author: MiniMax Agent
License: MIT
"""

import time
import json
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import random

logger = logging.getLogger(__name__)


class CloudStatus(Enum):
    """Status of cloud platform."""
    AVAILABLE = "available"
    QUOTA_EXCEEDED = "quota_exceeded"
    UNAVAILABLE = "unavailable"
    MAINTENANCE = "maintenance"
    ERROR = "error"


class ProviderType(Enum):
    """Types of cloud providers."""
    AWS = "aws"
    GOOGLE_CLOUD = "google_cloud"
    MICROSOFT_AZURE = "azure"
    COLAB = "colab"
    KAGGLE = "kaggle"
    LOCAL = "local"


@dataclass
class CloudProvider:
    """Cloud provider configuration."""
    name: str
    provider_type: ProviderType
    priority: int
    max_instances: int
    current_usage: int = 0
    max_gpu_instances: int = 0
    current_gpu_usage: int = 0
    cost_per_hour: float = 0.0
    region: str = "us-west-2"
    credentials_configured: bool = False
    last_health_check: float = 0.0
    health_status: CloudStatus = CloudStatus.AVAILABLE


@dataclass
class ResourceRequest:
    """Request for cloud resources."""
    request_id: str
    provider_preference: Optional[str] = None
    instance_type: str = "general"
    gpu_required: bool = False
    estimated_duration_hours: float = 1.0
    priority: int = 1
    timestamp: float = 0.0


@dataclass
class ResourceAllocation:
    """Allocation result for resource request."""
    request_id: str
    provider_name: str
    instance_id: str
    allocation_time: float
    estimated_cost: float
    status: str


class CloudRotationManager:
    """
    Manages resource allocation across multiple cloud providers.
    
    Capabilities:
    - Smart provider selection based on capacity and cost
    - Automatic fallback when quotas are exceeded
    - Resource usage tracking and optimization
    - Health monitoring and failover
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize cloud rotation manager.
        
        Args:
            config: Configuration with cloud providers
        """
        self.config = config
        
        # Initialize cloud providers
        self.providers: Dict[str, CloudProvider] = self._initialize_providers()
        
        # Resource tracking
        self.active_allocations: Dict[str, ResourceAllocation] = {}
        self.resource_history: List[Dict[str, Any]] = []
        
        # Quota management
        self.usage_tracking = {
            'total_requests': 0,
            'successful_allocations': 0,
            'failed_allocations': 0,
            'provider_failures': {name: 0 for name in self.providers.keys()},
            'cost_savings': 0.0
        }
        
        # Health check settings
        self.health_check_interval = 300  # 5 minutes
        self.max_retry_attempts = 3
        
        logger.info(f"Cloud Rotation Manager initialized with {len(self.providers)} providers")
    
    def _initialize_providers(self) -> Dict[str, CloudProvider]:
        """Initialize cloud providers from configuration."""
        providers = {}
        
        # Default provider configurations
        default_configs = {
            'aws_sagemaker': CloudProvider(
                name="aws_sagemaker",
                provider_type=ProviderType.AWS,
                priority=1,
                max_instances=10,
                max_gpu_instances=5,
                cost_per_hour=3.045,
                region="us-west-2"
            ),
            'google_colab': CloudProvider(
                name="google_colab",
                provider_type=ProviderType.COLAB,
                priority=2,
                max_instances=2,
                max_gpu_instances=2,
                cost_per_hour=0.0,  # Free tier
                region="global"
            ),
            'kaggle': CloudProvider(
                name="kaggle",
                provider_type=ProviderType.KAGGLE,
                priority=3,
                max_instances=1,
                max_gpu_instances=1,
                cost_per_hour=0.0,  # Free tier
                region="global"
            ),
            'azure_ml': CloudProvider(
                name="azure_ml",
                provider_type=ProviderType.MICROSOFT_AZURE,
                priority=4,
                max_instances=5,
                max_gpu_instances=2,
                cost_per_hour=2.50,
                region="westus2"
            )
        }
        
        # Update with configuration
        for provider_name, provider_config in self.config.items():
            if provider_name in default_configs:
                provider = default_configs[provider_name]
                # Update with config values
                for key, value in provider_config.items():
                    if hasattr(provider, key):
                        setattr(provider, key, value)
                providers[provider_name] = provider
            else:
                # Create new provider
                provider_type = ProviderType(provider_config.get('provider_type', 'aws'))
                providers[provider_name] = CloudProvider(
                    name=provider_name,
                    provider_type=provider_type,
                    priority=provider_config.get('priority', 10),
                    max_instances=provider_config.get('max_instances', 1),
                    max_gpu_instances=provider_config.get('max_gpu_instances', 0),
                    cost_per_hour=provider_config.get('cost_per_hour', 1.0),
                    region=provider_config.get('region', 'us-west-2')
                )
        
        return providers
    
    def allocate_resources(self, request: ResourceRequest) -> Optional[ResourceAllocation]:
        """
        Allocate resources from available providers.
        
        Args:
            request: Resource request details
            
        Returns:
            ResourceAllocation if successful, None otherwise
        """
        self.usage_tracking['total_requests'] += 1
        
        logger.info(f"Allocating resources for request: {request.request_id}")
        
        # Try to find suitable provider
        provider = self._select_provider(request)
        
        if not provider:
            logger.error("No suitable provider available")
            self.usage_tracking['failed_allocations'] += 1
            return None
        
        # Attempt allocation
        allocation = self._allocate_from_provider(provider, request)
        
        if allocation:
            self.usage_tracking['successful_allocations'] += 1
            self.active_allocations[allocation.instance_id] = allocation
            
            # Update provider usage
            provider.current_usage += 1
            if request.gpu_required:
                provider.current_gpu_usage += 1
            
            # Track cost savings if using free tier
            if provider.cost_per_hour == 0.0:
                self.usage_tracking['cost_savings'] += request.estimated_duration_hours * 1.0  # Assume $1/hr baseline
        else:
            self.usage_tracking['failed_allocations'] += 1
            self.usage_tracking['provider_failures'][provider.name] += 1
        
        return allocation
    
    def _select_provider(self, request: ResourceRequest) -> Optional[CloudProvider]:
        """Select the best available provider for the request."""
        
        # Filter available providers
        available_providers = []
        
        for provider in self.providers.values():
            # Check status
            if provider.health_status != CloudStatus.AVAILABLE:
                continue
            
            # Check credentials
            if not provider.credentials_configured:
                continue
            
            # Check capacity
            if request.gpu_required:
                if provider.current_gpu_usage >= provider.max_gpu_instances:
                    continue
            else:
                if provider.current_usage >= provider.max_instances:
                    continue
            
            # Check if meets requirements
            if request.provider_preference and provider.name != request.provider_preference:
                continue
            
            available_providers.append(provider)
        
        if not available_providers:
            return None
        
        # Sort by priority (lower is higher priority)
        available_providers.sort(key=lambda p: p.priority)
        
        # Add some randomness for load balancing
        top_providers = available_providers[:3]  # Consider top 3 providers
        return random.choice(top_providers) if len(top_providers) > 1 else top_providers[0]
    
    def _allocate_from_provider(
        self, 
        provider: CloudProvider, 
        request: ResourceRequest
    ) -> Optional[ResourceAllocation]:
        """Attempt to allocate resources from a specific provider."""
        
        logger.info(f"Attempting allocation from {provider.name}")
        
        try:
            # Mock allocation (in practice, this would use actual cloud APIs)
            allocation_success = self._mock_allocate(provider, request)
            
            if allocation_success:
                allocation = ResourceAllocation(
                    request_id=request.request_id,
                    provider_name=provider.name,
                    instance_id=f"{provider.name}-{int(time.time())}-{random.randint(1000, 9999)}",
                    allocation_time=time.time(),
                    estimated_cost=provider.cost_per_hour * request.estimated_duration_hours,
                    status="allocated"
                )
                
                logger.info(f"Successfully allocated resources from {provider.name}")
                return allocation
            
        except Exception as e:
            logger.error(f"Allocation failed from {provider.name}: {e}")
            provider.health_status = CloudStatus.ERROR
            self.usage_tracking['provider_failures'][provider.name] += 1
        
        return None
    
    def _mock_allocate(self, provider: CloudProvider, request: ResourceRequest) -> bool:
        """Mock resource allocation for demonstration."""
        
        # Simulate provider-specific allocation behavior
        allocation_probability = {
            ProviderType.AWS: 0.95,
            ProviderType.COLAB: 0.70,  # Free tier has lower reliability
            ProviderType.KAGGLE: 0.60,
            ProviderType.MICROSOFT_AZURE: 0.85
        }
        
        base_probability = allocation_probability.get(provider.provider_type, 0.8)
        
        # Adjust based on current usage
        if request.gpu_required:
            usage_factor = max(0.1, 1.0 - (provider.current_gpu_usage / max(1, provider.max_gpu_instances)))
        else:
            usage_factor = max(0.1, 1.0 - (provider.current_usage / max(1, provider.max_instances)))
        
        # Add some randomness
        success_probability = base_probability * usage_factor * random.uniform(0.8, 1.0)
        
        return random.random() < success_probability
    
    def release_resources(self, instance_id: str) -> bool:
        """
        Release allocated resources.
        
        Args:
            instance_id: ID of the instance to release
            
        Returns:
            Success status
        """
        if instance_id not in self.active_allocations:
            logger.warning(f"Instance {instance_id} not found in active allocations")
            return False
        
        allocation = self.active_allocations[instance_id]
        provider_name = allocation.provider_name
        
        if provider_name not in self.providers:
            logger.error(f"Provider {provider_name} not found")
            return False
        
        provider = self.providers[provider_name]
        
        try:
            # Mock release (in practice, would use actual cloud APIs)
            release_success = self._mock_release(provider, allocation)
            
            if release_success:
                # Update provider usage
                provider.current_usage = max(0, provider.current_usage - 1)
                
                # Remove from active allocations
                del self.active_allocations[instance_id]
                
                # Track completion
                completion_time = time.time()
                self.resource_history.append({
                    'instance_id': instance_id,
                    'provider': provider_name,
                    'request_id': allocation.request_id,
                    'allocation_time': allocation.allocation_time,
                    'release_time': completion_time,
                    'duration_hours': (completion_time - allocation.allocation_time) / 3600,
                    'actual_cost': provider.cost_per_hour * (completion_time - allocation.allocation_time) / 3600,
                    'status': 'released'
                })
                
                logger.info(f"Successfully released resources for instance {instance_id}")
                return True
            
        except Exception as e:
            logger.error(f"Failed to release resources for {instance_id}: {e}")
        
        return False
    
    def _mock_release(self, provider: CloudProvider, allocation: ResourceAllocation) -> bool:
        """Mock resource release."""
        # Simulate release success/failure
        return random.random() < 0.95  # 95% success rate
    
    def health_check_all_providers(self) -> Dict[str, CloudStatus]:
        """
        Perform health check on all providers.
        
        Returns:
            Dictionary mapping provider names to health status
        """
        current_time = time.time()
        
        # Check if health check is needed
        if current_time - min(p.last_health_check for p in self.providers.values()) < self.health_check_interval:
            return {name: provider.health_status for name, provider in self.providers.items()}
        
        health_results = {}
        
        for provider_name, provider in self.providers.items():
            try:
                # Mock health check (in practice, would ping actual APIs)
                health_status = self._mock_health_check(provider)
                
                provider.health_status = health_status
                provider.last_health_check = current_time
                health_results[provider_name] = health_status
                
                if health_status == CloudStatus.ERROR:
                    logger.warning(f"Health check failed for {provider_name}")
                
            except Exception as e:
                logger.error(f"Health check error for {provider_name}: {e}")
                provider.health_status = CloudStatus.ERROR
                health_results[provider_name] = CloudStatus.ERROR
        
        return health_results
    
    def _mock_health_check(self, provider: CloudProvider) -> CloudStatus:
        """Mock health check for providers."""
        
        # Simulate different health scenarios
        if provider.provider_type == ProviderType.COLAB:
            # Colab sometimes has availability issues
            return random.choices(
                [CloudStatus.AVAILABLE, CloudStatus.UNAVAILABLE, CloudStatus.MAINTENANCE],
                weights=[0.7, 0.2, 0.1]
            )[0]
        elif provider.current_usage >= provider.max_instances:
            return CloudStatus.QUOTA_EXCEEDED
        elif random.random() < 0.05:  # 5% chance of random failure
            return CloudStatus.ERROR
        else:
            return CloudStatus.AVAILABLE
    
    def get_recommended_provider(self, request: ResourceRequest) -> Optional[str]:
        """
        Get recommended provider for a request.
        
        Args:
            request: Resource request
            
        Returns:
            Provider name recommendation
        """
        provider = self._select_provider(request)
        return provider.name if provider else None
    
    def get_provider_status(self) -> Dict[str, Dict[str, Any]]:
        """
        Get status of all providers.
        
        Returns:
            Dictionary with provider status information
        """
        return {
            name: {
                'status': provider.health_status.value,
                'current_usage': provider.current_usage,
                'max_instances': provider.max_instances,
                'current_gpu_usage': provider.current_gpu_usage,
                'max_gpu_instances': provider.max_gpu_instances,
                'priority': provider.priority,
                'cost_per_hour': provider.cost_per_hour,
                'last_health_check': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(provider.last_health_check)),
                'credentials_configured': provider.credentials_configured
            }
            for name, provider in self.providers.items()
        }
    
    def get_usage_statistics(self) -> Dict[str, Any]:
        """
        Get usage statistics and analytics.
        
        Returns:
            Dictionary with usage statistics
        """
        # Calculate success rate
        total_requests = self.usage_tracking['total_requests']
        success_rate = (
            self.usage_tracking['successful_allocations'] / total_requests 
            if total_requests > 0 else 0
        )
        
        # Provider utilization
        provider_utilization = {}
        for name, provider in self.providers.items():
            utilization = (
                provider.current_usage / provider.max_instances 
                if provider.max_instances > 0 else 0
            )
            provider_utilization[name] = {
                'current_usage': provider.current_usage,
                'max_instances': provider.max_instances,
                'utilization_percentage': utilization * 100
            }
        
        # Recent allocations
        recent_allocations = [
            alloc for alloc in self.active_allocations.values()
            if time.time() - alloc.allocation_time < 3600  # Last hour
        ]
        
        return {
            'total_requests': total_requests,
            'successful_allocations': self.usage_tracking['successful_allocations'],
            'failed_allocations': self.usage_tracking['failed_allocations'],
            'success_rate': success_rate,
            'active_allocations': len(self.active_allocations),
            'recent_allocations': len(recent_allocations),
            'total_cost_savings': self.usage_tracking['cost_savings'],
            'provider_utilization': provider_utilization,
            'provider_failures': self.usage_tracking['provider_failures']
        }
    
    def optimize_costs(self) -> Dict[str, Any]:
        """
        Analyze and suggest cost optimizations.
        
        Returns:
            Dictionary with optimization recommendations
        """
        recommendations = []
        
        # Check for unused capacity
        for name, provider in self.providers.items():
            if provider.current_usage == 0 and provider.max_instances > 0:
                recommendations.append({
                    'type': 'unused_capacity',
                    'provider': name,
                    'message': f"Provider {name} has {provider.max_instances} instances but none are used",
                    'suggestion': 'Consider reducing max_instances or promoting provider priority'
                })
        
        # Check for expensive providers being underutilized
        expensive_providers = [
            (name, provider) for name, provider in self.providers.items()
            if provider.cost_per_hour > 2.0 and provider.current_usage < provider.max_instances * 0.5
        ]
        
        for name, provider in expensive_providers:
            recommendations.append({
                'type': 'expensive_underutilization',
                'provider': name,
                'message': f"Provider {name} (${provider.cost_per_hour}/hr) is underutilized",
                'suggestion': 'Consider using free tier providers (Colab, Kaggle) for non-urgent tasks'
            })
        
        # Check for repeated failures
        for name, failures in self.usage_tracking['provider_failures'].items():
            if failures > 5:
                recommendations.append({
                    'type': 'reliability_issues',
                    'provider': name,
                    'message': f"Provider {name} has {failures} failures",
                    'suggestion': 'Consider reducing priority or configuring better health checks'
                })
        
        return {
            'recommendations': recommendations,
            'potential_savings': self._calculate_potential_savings(),
            'optimization_score': self._calculate_optimization_score()
        }
    
    def _calculate_potential_savings(self) -> float:
        """Calculate potential cost savings."""
        total_savings = 0.0
        
        for name, provider in self.providers.items():
            if provider.cost_per_hour == 0.0:  # Free providers
                unused_capacity = provider.max_instances - provider.current_usage
                total_savings += unused_capacity * 1.0  # Assume $1/hr baseline
        
        return total_savings
    
    def _calculate_optimization_score(self) -> float:
        """Calculate optimization score (0-1, higher is better)."""
        # Base score on success rate
        total_requests = self.usage_tracking['total_requests']
        if total_requests == 0:
            return 1.0
        
        success_rate = self.usage_tracking['successful_allocations'] / total_requests
        
        # Penalty for provider failures
        total_failures = sum(self.usage_tracking['provider_failures'].values())
        failure_penalty = min(0.3, total_failures / total_requests * 0.5)
        
        # Penalty for underutilized expensive providers
        expensive_underuse_penalty = 0.0
        for provider in self.providers.values():
            if provider.cost_per_hour > 2.0:
                utilization = provider.current_usage / max(1, provider.max_instances)
                if utilization < 0.5:
                    expensive_underuse_penalty += (0.5 - utilization) * 0.1
        
        optimization_score = max(0.0, success_rate - failure_penalty - expensive_underuse_penalty)
        
        return optimization_score
    
    def configure_credentials(self, provider_name: str, credentials: Dict[str, str]) -> bool:
        """
        Configure credentials for a provider.
        
        Args:
            provider_name: Name of the provider
            credentials: Credential configuration
            
        Returns:
            Success status
        """
        if provider_name not in self.providers:
            logger.error(f"Provider {provider_name} not found")
            return False
        
        provider = self.providers[provider_name]
        
        try:
            # Mock credential validation (in practice, would validate with actual APIs)
            validation_success = self._mock_validate_credentials(provider, credentials)
            
            if validation_success:
                provider.credentials_configured = True
                logger.info(f"Credentials configured successfully for {provider_name}")
                return True
            else:
                logger.error(f"Credential validation failed for {provider_name}")
                return False
            
        except Exception as e:
            logger.error(f"Failed to configure credentials for {provider_name}: {e}")
            return False
    
    def _mock_validate_credentials(self, provider: CloudProvider, credentials: Dict[str, str]) -> bool:
        """Mock credential validation."""
        # Simulate credential validation
        required_fields = ['access_key', 'secret_key'] if provider.provider_type in [ProviderType.AWS] else ['api_key']
        
        return all(field in credentials for field in required_fields)
    
    def get_config(self) -> Dict[str, Any]:
        """Get manager configuration."""
        return {
            'manager_type': 'CloudRotationManager',
            'num_providers': len(self.providers),
            'active_allocations': len(self.active_allocations),
            'health_check_interval': self.health_check_interval,
            'usage_statistics': self.get_usage_statistics(),
            'provider_status': self.get_provider_status()
        }