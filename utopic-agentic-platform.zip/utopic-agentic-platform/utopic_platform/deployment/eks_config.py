"""
AWS EKS Deployer
================

Handles deployment to Amazon EKS for scalable Kubernetes-based deployment.
Supports NIM container deployment and cluster management.

Key Features:
- EKS cluster creation and management
- NIM container deployment via Helm
- Kubernetes service configuration
- Auto-scaling and resource management

Author: MiniMax Agent
License: MIT
"""

import boto3
import json
import logging
import time
import subprocess
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class EKSClusterConfig:
    """Configuration for EKS cluster."""
    name: str
    version: str = "1.29"
    region: str = "us-west-2"
    node_groups: List[Dict[str, Any]] = None
    fargate_profiles: List[Dict[str, Any]] = None
    vpc_config: Dict[str, Any] = None


@dataclass
class KubernetesServiceConfig:
    """Configuration for Kubernetes service."""
    name: str
    namespace: str = "default"
    replicas: int = 2
    resources: Dict[str, Any] = None
    service_type: str = "LoadBalancer"


class EKSDeployer:
    """
    Deploys and manages applications on Amazon EKS.
    
    Capabilities:
    - EKS cluster creation and configuration
    - Kubernetes deployment of NIM containers
    - Helm chart management
    - Service discovery and load balancing
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize EKS deployer.
        
        Args:
            config: EKS configuration parameters
        """
        self.config = config
        
        # AWS configuration
        self.region = config.get('region', 'us-west-2')
        self.cluster_name = config.get('cluster_name', 'utopic-ai-cluster')
        self.role_arn = config.get('role_arn', 'arn:aws:iam::account:role/EKSRole')
        
        # Initialize AWS clients
        self._setup_aws_clients()
        
        # Kubernetes configuration
        self.kubeconfig_path = f"/tmp/{self.cluster_name}-kubeconfig"
        
        logger.info("EKS Deployer initialized")
    
    def _setup_aws_clients(self):
        """Initialize AWS service clients."""
        try:
            self.eks_client = boto3.client('eks', region_name=self.region)
            self.ec2_client = boto3.client('ec2', region_name=self.region)
            self.iam_client = boto3.client('iam', region_name=self.region)
            
            logger.info("AWS clients initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize AWS clients: {e}")
            raise
    
    def create_cluster(self, config: Optional[EKSClusterConfig] = None) -> Dict[str, Any]:
        """
        Create an EKS cluster.
        
        Args:
            config: Cluster configuration
            
        Returns:
            Dictionary with cluster information
        """
        if config is None:
            config = EKSClusterConfig(
                name=self.cluster_name,
                region=self.region,
                node_groups=[
                    {
                        'name': 'general',
                        'instance_types': ['m5.xlarge'],
                        'capacity_type': 'ON_DEMAND',
                        'min_size': 2,
                        'max_size': 10,
                        'desired_size': 3
                    },
                    {
                        'name': 'gpu',
                        'instance_types': ['g5.xlarge'],
                        'capacity_type': 'ON_DEMAND',
                        'min_size': 0,
                        'max_size': 5,
                        'desired_size': 1
                    }
                ]
            )
        
        logger.info(f"Creating EKS cluster: {config.name}")
        
        try:
            # Prepare VPC configuration
            vpc_config = {
                'subnets': self._get_subnets(),
                'endpointPrivateAccess': True,
                'endpointPublicAccess': True,
                'publicAccessCidrs': ['0.0.0.0/0']
            }
            
            if config.vpc_config:
                vpc_config.update(config.vpc_config)
            
            # Create cluster
            response = self.eks_client.create_cluster(
                name=config.name,
                version=config.version,
                roleArn=self.role_arn,
                resourcesVpcConfig=vpc_config,
                logging={
                    'clusterLogging': {
                        'enabledTypes': [
                            {'type': 'api'},
                            {'type': 'audit'},
                            {'type': 'authenticator'}
                        ]
                    }
                }
            )
            
            cluster_arn = response['cluster']['arn']
            
            # Wait for cluster to be active
            self._wait_for_cluster(config.name)
            
            # Create node groups
            node_group_arns = []
            for node_group_config in config.node_groups:
                node_group_arn = self._create_node_group(config.name, node_group_config)
                node_group_arns.append(node_group_arn)
            
            # Update kubeconfig
            self._update_kubeconfig(config.name)
            
            cluster_info = {
                'cluster_name': config.name,
                'cluster_arn': cluster_arn,
                'status': 'active',
                'version': config.version,
                'node_groups': node_group_arns,
                'endpoint': response['cluster']['endpoint'],
                'kubeconfig': self.kubeconfig_path
            }
            
            logger.info(f"EKS cluster {config.name} created successfully")
            
            return cluster_info
            
        except Exception as e:
            logger.error(f"Failed to create EKS cluster: {e}")
            raise
    
    def _get_subnets(self) -> List[Dict[str, str]]:
        """Get subnet configuration for EKS cluster."""
        try:
            # Get VPC and subnets
            vpcs = self.ec2_client.describe_vpcs(Filters=[{'Name': 'is-default', 'Values': ['true']}])
            vpc_id = vpcs['Vpcs'][0]['VpcId']
            
            subnets = self.ec2_client.describe_subnets(
                Filters=[
                    {'Name': 'vpc-id', 'Values': [vpc_id]},
                    {'Name': 'state', 'Values': ['available']}
                ]
            )
            
            subnet_ids = [subnet['SubnetId'] for subnet in subnets['Subnets']]
            
            return [{'subnetId': subnet_id} for subnet_id in subnet_ids[:6]]  # Use first 6 subnets
            
        except Exception as e:
            logger.error(f"Failed to get subnets: {e}")
            # Return default subnets (this should be configured properly in production)
            return [
                {'subnetId': 'subnet-12345678'},
                {'subnetId': 'subnet-87654321'}
            ]
    
    def _create_node_group(self, cluster_name: str, node_group_config: Dict[str, Any]) -> str:
        """Create EKS node group."""
        try:
            nodegroup_name = node_group_config['name']
            
            response = self.eks_client.create_nodegroup(
                clusterName=cluster_name,
                nodegroupName=nodegroup_name,
                nodeRole=self.role_arn,
                instanceTypes=node_group_config['instance_types'],
                capacityType=node_group_config.get('capacity_type', 'ON_DEMAND'),
                scalingConfig={
                    'minSize': node_group_config['min_size'],
                    'maxSize': node_group_config['max_size'],
                    'desiredSize': node_group_config['desired_size']
                },
                amiType='AL2_x86_64',
                diskSize=50,
                subnets=self._get_subnets(),
                instanceTypes=node_group_config['instance_types'],
                updateConfig={'maxUnavailablePercentage': 25}
            )
            
            node_group_arn = response['nodegroup']['nodegroupArn']
            
            # Wait for node group to be active
            self._wait_for_node_group(cluster_name, nodegroup_name)
            
            logger.info(f"Node group {nodegroup_name} created successfully")
            
            return node_group_arn
            
        except Exception as e:
            logger.error(f"Failed to create node group {node_group_config['name']}: {e}")
            raise
    
    def _wait_for_cluster(self, cluster_name: str, timeout: int = 1800):
        """Wait for EKS cluster to be active."""
        logger.info(f"Waiting for EKS cluster {cluster_name} to be active...")
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                cluster_info = self.eks_client.describe_cluster(name=cluster_name)
                status = cluster_info['cluster']['status']
                
                logger.info(f"Cluster {cluster_name} status: {status}")
                
                if status == 'ACTIVE':
                    logger.info(f"Cluster {cluster_name} is active")
                    return
                elif status == 'FAILED':
                    failure_reason = cluster_info['cluster'].get('message', 'Unknown')
                    logger.error(f"Cluster {cluster_name} failed: {failure_reason}")
                    raise Exception(f"Cluster creation failed: {failure_reason}")
                
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Error checking cluster status: {e}")
                break
        
        raise TimeoutError(f"Cluster {cluster_name} did not become active within {timeout} seconds")
    
    def _wait_for_node_group(self, cluster_name: str, node_group_name: str, timeout: int = 1200):
        """Wait for node group to be active."""
        logger.info(f"Waiting for node group {node_group_name} to be active...")
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                node_group_info = self.eks_client.describe_nodegroup(
                    clusterName=cluster_name,
                    nodegroupName=node_group_name
                )
                status = node_group_info['nodegroup']['status']
                
                logger.info(f"Node group {node_group_name} status: {status}")
                
                if status == 'ACTIVE':
                    logger.info(f"Node group {node_group_name} is active")
                    return
                elif status in ['CREATE_FAILED', 'DELETE_FAILED']:
                    failure_reason = node_group_info['nodegroup'].get('message', 'Unknown')
                    logger.error(f"Node group {node_group_name} failed: {failure_reason}")
                    return  # Don't raise exception, just log
                
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Error checking node group status: {e}")
                break
    
    def _update_kubeconfig(self, cluster_name: str):
        """Update kubeconfig for the cluster."""
        try:
            cmd = [
                'aws', 'eks', 'update-kubeconfig',
                '--region', self.region,
                '--name', cluster_name,
                '--kubeconfig', self.kubeconfig_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            logger.info("Kubeconfig updated successfully")
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to update kubeconfig: {e}")
            logger.error(f"Error output: {e.stderr}")
            raise
        except FileNotFoundError:
            logger.error("AWS CLI or kubectl not found. Please install AWS CLI and kubectl.")
            raise
    
    def deploy_nim_container(
        self, 
        nim_type: str,
        container_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Deploy NIM container to EKS using Helm.
        
        Args:
            nim_type: Type of NIM ('nemotron' or 'nemo_embedding')
            container_config: Container configuration
            
        Returns:
            Dictionary with deployment information
        """
        logger.info(f"Deploying NIM container: {nim_type}")
        
        try:
            # Prepare Helm values
            helm_values = self._prepare_helm_values(nim_type, container_config)
            
            # Deploy using Helm
            deployment_info = self._deploy_with_helm(nim_type, helm_values)
            
            logger.info(f"NIM container {nim_type} deployed successfully")
            
            return deployment_info
            
        except Exception as e:
            logger.error(f"Failed to deploy NIM container {nim_type}: {e}")
            raise
    
    def _prepare_helm_values(self, nim_type: str, container_config: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare Helm values for NIM deployment."""
        
        if nim_type == 'nemotron':
            return {
                'image': {
                    'repository': 'nvcr.io/nim/nvidia/llama-3.1-nemotron-nano-8b-v1',
                    'pullPolicy': 'IfNotPresent',
                    'tag': 'latest'
                },
                'service': {
                    'type': 'LoadBalancer',
                    'port': 80,
                    'targetPort': 8000
                },
                'resources': {
                    'requests': {
                        'memory': '8Gi',
                        'cpu': '4'
                    },
                    'limits': {
                        'memory': '16Gi',
                        'cpu': '8'
                    }
                },
                'autoscaling': {
                    'enabled': True,
                    'minReplicas': 1,
                    'maxReplicas': 10,
                    'targetCPUUtilizationPercentage': 70
                },
                'nodeSelector': {
                    'node-group': 'gpu'
                },
                'tolerations': [
                    {
                        'key': 'nvidia.com/gpu',
                        'operator': 'Exists',
                        'effect': 'NoSchedule'
                    }
                ]
            }
            
        elif nim_type == 'nemo_embedding':
            return {
                'image': {
                    'repository': 'nvcr.io/nim/nvidia/nv-embed-qa-4',
                    'pullPolicy': 'IfNotPresent',
                    'tag': 'latest'
                },
                'service': {
                    'type': 'ClusterIP',
                    'port': 80,
                    'targetPort': 8080
                },
                'resources': {
                    'requests': {
                        'memory': '4Gi',
                        'cpu': '2'
                    },
                    'limits': {
                        'memory': '8Gi',
                        'cpu': '4'
                    }
                },
                'autoscaling': {
                    'enabled': True,
                    'minReplicas': 1,
                    'maxReplicas': 5,
                    'targetCPUUtilizationPercentage': 70
                },
                'nodeSelector': {
                    'node-group': 'general'
                }
            }
        
        else:
            raise ValueError(f"Unknown NIM type: {nim_type}")
    
    def _deploy_with_helm(self, nim_type: str, helm_values: Dict[str, Any]) -> Dict[str, Any]:
        """Deploy using Helm chart."""
        try:
            # Create Helm chart values file
            values_file = f"/tmp/{nim_type}-values.yaml"
            with open(values_file, 'w') as f:
                import yaml
                yaml.dump(helm_values, f)
            
            # Add NIM Helm repository if not exists
            subprocess.run([
                'helm', 'repo', 'add', 'nvidia-nim', 'https://helm.ngc.nvidia.com/nim'
            ], check=True, capture_output=True)
            
            subprocess.run(['helm', 'repo', 'update'], check=True, capture_output=True)
            
            # Deploy NIM
            release_name = f"nim-{nim_type}"
            
            cmd = [
                'helm', 'upgrade', '--install',
                release_name,
                'nvidia-nim/nvidia-nim-serving',
                '--namespace', 'default',
                '--values', values_file,
                '--set', f'image.repository={helm_values["image"]["repository"]}',
                '--set', f'image.tag={helm_values["image"]["tag"]}'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            # Get service information
            service_info = self._get_kubernetes_service_info(release_name)
            
            deployment_info = {
                'release_name': release_name,
                'nim_type': nim_type,
                'status': 'deployed',
                'service_info': service_info,
                'values_file': values_file,
                'command_output': result.stdout
            }
            
            # Clean up values file
            Path(values_file).unlink(missing_ok=True)
            
            return deployment_info
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Helm deployment failed: {e}")
            logger.error(f"Helm output: {e.stdout}")
            logger.error(f"Helm error: {e.stderr}")
            raise
        except Exception as e:
            logger.error(f"Deployment failed: {e}")
            raise
    
    def _get_kubernetes_service_info(self, release_name: str) -> Dict[str, Any]:
        """Get Kubernetes service information."""
        try:
            # Get service details
            cmd = ['kubectl', 'get', 'service', release_name, '-o', 'json']
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            service_data = json.loads(result.stdout)
            
            # Get service status
            status_cmd = ['kubectl', 'get', 'deployment', release_name, '-o', 'json']
            status_result = subprocess.run(status_cmd, capture_output=True, text=True)
            
            if status_result.returncode == 0:
                deployment_data = json.loads(status_result.stdout)
                status = deployment_data['status']['conditions'][-1]['type']
            else:
                status = 'Unknown'
            
            return {
                'name': service_data['metadata']['name'],
                'namespace': service_data['metadata']['namespace'],
                'type': service_data['spec']['type'],
                'cluster_ip': service_data['spec'].get('clusterIP', 'None'),
                'external_ip': service_data['spec'].get('loadBalancer', {}).get('ingress', [{}])[0].get('ip', 'Pending'),
                'port': service_data['spec']['ports'][0]['port'],
                'target_port': service_data['spec']['ports'][0]['targetPort'],
                'status': status
            }
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get service info: {e}")
            return {}
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse service info: {e}")
            return {}
    
    def get_cluster_info(self) -> Dict[str, Any]:
        """
        Get information about the EKS cluster.
        
        Returns:
            Dictionary with cluster information
        """
        try:
            # Get cluster details
            cluster_info = self.eks_client.describe_cluster(name=self.cluster_name)
            cluster = cluster_info['cluster']
            
            # Get node groups
            node_groups = self.eks_client.list_nodegroups(clusterName=self.cluster_name)
            
            node_group_info = []
            for node_group_name in node_groups['nodegroups']:
                node_group = self.eks_client.describe_nodegroup(
                    clusterName=self.cluster_name,
                    nodegroupName=node_group_name
                )
                node_group_info.append({
                    'name': node_group_name,
                    'status': node_group['nodegroup']['status'],
                    'instance_types': node_group['nodegroup']['instanceTypes'],
                    'scaling_config': node_group['nodegroup']['scalingConfig']
                })
            
            return {
                'cluster_name': self.cluster_name,
                'status': cluster['status'],
                'version': cluster['version'],
                'endpoint': cluster['endpoint'],
                'arn': cluster['arn'],
                'created_at': cluster['createdAt'].isoformat(),
                'node_groups': node_group_info,
                'kubeconfig_path': self.kubeconfig_path,
                'vpc_config': cluster.get('vpcConfig', {})
            }
            
        except Exception as e:
            logger.error(f"Failed to get cluster info: {e}")
            return {}
    
    def delete_cluster(self) -> bool:
        """
        Delete the EKS cluster.
        
        Returns:
            Success status
        """
        try:
            logger.info(f"Deleting EKS cluster: {self.cluster_name}")
            
            # Delete node groups first
            node_groups = self.eks_client.list_nodegroups(clusterName=self.cluster_name)
            
            for node_group_name in node_groups['nodegroups']:
                logger.info(f"Deleting node group: {node_group_name}")
                
                self.eks_client.delete_nodegroup(
                    clusterName=self.cluster_name,
                    nodegroupName=node_group_name
                )
                
                # Wait for deletion
                self._wait_for_nodegroup_deletion(node_group_name)
            
            # Delete cluster
            self.eks_client.delete_cluster(name=self.cluster_name)
            
            # Wait for cluster deletion
            self._wait_for_cluster_deletion()
            
            # Clean up kubeconfig file
            Path(self.kubeconfig_path).unlink(missing_ok=True)
            
            logger.info(f"EKS cluster {self.cluster_name} deleted successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete EKS cluster: {e}")
            return False
    
    def _wait_for_nodegroup_deletion(self, node_group_name: str, timeout: int = 600):
        """Wait for node group deletion."""
        logger.info(f"Waiting for node group {node_group_name} deletion...")
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                self.eks_client.describe_nodegroup(
                    clusterName=self.cluster_name,
                    nodegroupName=node_group_name
                )
                time.sleep(10)
                
            except self.eks_client.exceptions.ResourceNotFoundException:
                logger.info(f"Node group {node_group_name} deleted")
                return
            except Exception as e:
                logger.error(f"Error checking node group deletion: {e}")
                break
        
        logger.warning(f"Node group {node_group_name} deletion timeout")
    
    def _wait_for_cluster_deletion(self, timeout: int = 600):
        """Wait for cluster deletion."""
        logger.info(f"Waiting for cluster {self.cluster_name} deletion...")
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                self.eks_client.describe_cluster(name=self.cluster_name)
                time.sleep(10)
                
            except self.eks_client.exceptions.ResourceNotFoundException:
                logger.info(f"Cluster {self.cluster_name} deleted")
                return
            except Exception as e:
                logger.error(f"Error checking cluster deletion: {e}")
                break
        
        logger.warning(f"Cluster {self.cluster_name} deletion timeout")
    
    def run_kubectl_command(self, command: List[str]) -> Dict[str, Any]:
        """
        Run a kubectl command.
        
        Args:
            command: kubectl command parts
            
        Returns:
            Dictionary with command result
        """
        try:
            cmd = ['kubectl', '--kubeconfig', self.kubeconfig_path] + command
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            return {
                'command': ' '.join(cmd),
                'return_code': result.returncode,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'success': result.returncode == 0
            }
            
        except Exception as e:
            logger.error(f"Failed to run kubectl command: {e}")
            return {
                'command': ' '.join(['kubectl'] + command),
                'return_code': -1,
                'stdout': '',
                'stderr': str(e),
                'success': False
            }
    
    def get_config(self) -> Dict[str, Any]:
        """Get deployer configuration."""
        return {
            'deployer_type': 'EKSDeployer',
            'region': self.region,
            'cluster_name': self.cluster_name,
            'role_arn': self.role_arn,
            'kubeconfig_path': self.kubeconfig_path
        }