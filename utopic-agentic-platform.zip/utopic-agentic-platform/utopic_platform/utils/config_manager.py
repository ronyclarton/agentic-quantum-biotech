"""
Configuration Manager
====================

Manages configuration loading, validation, and persistence for the
Utopic AI Platform. Supports multiple config formats and environments.

Author: MiniMax Agent
License: MIT
"""

import os
import json
import yaml
import logging
from typing import Dict, Any, Optional, List
from pathlib import Path
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class PlatformConfig:
    """Main platform configuration."""
    platform_name: str = "utopic-ai-platform"
    version: str = "1.0.0"
    environment: str = "development"  # development, testing, production
    debug: bool = True
    log_level: str = "INFO"
    
    # Agent configurations
    agents: Dict[str, Any] = None
    
    # Deployment configurations
    deployment: Dict[str, Any] = None
    
    # Cloud provider configurations
    clouds: List[Dict[str, Any]] = None
    
    # Database configurations
    database: Dict[str, Any] = None
    
    # Security configurations
    security: Dict[str, Any] = None


class ConfigManager:
    """
    Manages platform configuration from multiple sources.
    
    Configuration precedence (highest to lowest):
    1. Environment variables (UTOPIC_*)
    2. Command line arguments
    3. User config file (~/.utopic/config.yaml)
    4. Project config file (project_root/config/config.yaml)
    5. Default configuration
    """
    
    def __init__(self, config_path: Optional[str] = None, **kwargs):
        """
        Initialize configuration manager.
        
        Args:
            config_path: Path to configuration file
            **kwargs: Configuration overrides
        """
        self.config_path = config_path
        self.overrides = kwargs
        
        # Load configuration
        self.config = self._load_configuration()
        
        # Apply environment-specific settings
        self._apply_environment_settings()
        
        logger.info(f"Configuration loaded for {self.config.environment} environment")
    
    def _load_configuration(self) -> PlatformConfig:
        """Load configuration from multiple sources."""
        config_data = {}
        
        # 1. Load from default configuration
        default_config = self._get_default_config()
        config_data.update(default_config)
        
        # 2. Load from config file
        if self.config_path and Path(self.config_path).exists():
            file_config = self._load_config_file(self.config_path)
            if file_config:
                config_data.update(file_config)
        else:
            # Try to find config files in standard locations
            file_config = self._find_and_load_config_file()
            if file_config:
                config_data.update(file_config)
        
        # 3. Load from environment variables
        env_config = self._load_from_environment()
        config_data.update(env_config)
        
        # 4. Apply command line overrides
        config_data.update(self.overrides)
        
        # Convert to PlatformConfig dataclass
        return self._create_platform_config(config_data)
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration values."""
        return {
            'platform_name': 'utopic-ai-platform',
            'version': '1.0.0',
            'environment': 'development',
            'debug': True,
            'log_level': 'INFO',
            'agents': {
                'reasoning': {
                    'model_name': 'nvidia/Llama-3.1-Nemotron-Nano-8B-v1',
                    'temperature': 0.7,
                    'max_tokens': 512
                },
                'biotech': {
                    'genetic_algorithms': ['NSGA-II', 'differential_evolution', 'cma_es'],
                    'population_size': 50,
                    'generations': 20
                },
                'quantum': {
                    'device_type': 'default.qubit',
                    'wires': 6,
                    'shots': 1024
                },
                'retrieval': {
                    'embedding_model': 'nvidia/nv-embed-qa-4',
                    'vector_db': 'faiss',
                    'similarity_threshold': 0.8
                },
                'generation': {
                    'model_type': 'generative_graph_network',
                    'max_candidates': 1000,
                    'validation_method': 'dft'
                }
            },
            'deployment': {
                'sagemaker': {
                    'region': 'us-west-2',
                    'instance_type': 'ml.g5.2xlarge',
                    'max_replicas': 5
                },
                'eks': {
                    'cluster_name': 'utopic-ai-cluster',
                    'node_groups': [
                        {'name': 'general', 'instance_types': ['m5.xlarge'], 'min_size': 2, 'max_size': 10},
                        {'name': 'gpu', 'instance_types': ['g5.xlarge'], 'min_size': 0, 'max_size': 5}
                    ]
                }
            },
            'clouds': [
                {'name': 'sagemaker', 'priority': 1, 'max_gpus': 8, 'cost_per_hour': 3.045},
                {'name': 'colab', 'priority': 2, 'max_gpus': 2, 'cost_per_hour': 0.0},
                {'name': 'kaggle', 'priority': 3, 'max_gpus': 1, 'cost_per_hour': 0.0}
            ],
            'database': {
                'type': 'sqlite',
                'path': './data/utopic_platform.db'
            },
            'security': {
                'api_key_encryption': True,
                'jwt_secret': 'default-secret-change-in-production',
                'ssl_verify': True
            }
        }
    
    def _find_and_load_config_file(self) -> Optional[Dict[str, Any]]:
        """Find and load configuration file from standard locations."""
        search_paths = [
            Path.home() / '.utopic' / 'config.yaml',
            Path.home() / '.utopic' / 'config.yml',
            Path.cwd() / 'config' / 'config.yaml',
            Path.cwd() / 'utopic_config.yaml',
            Path.cwd() / 'config.yaml'
        ]
        
        for config_file in search_paths:
            if config_file.exists():
                logger.info(f"Loading configuration from: {config_file}")
                return self._load_config_file(str(config_file))
        
        logger.info("No configuration file found, using defaults")
        return None
    
    def _load_config_file(self, config_path: str) -> Optional[Dict[str, Any]]:
        """Load configuration from file."""
        config_path = Path(config_path)
        
        try:
            with open(config_path, 'r') as f:
                if config_path.suffix.lower() in ['.yaml', '.yml']:
                    return yaml.safe_load(f) or {}
                elif config_path.suffix.lower() == '.json':
                    return json.load(f)
                else:
                    logger.warning(f"Unsupported config file format: {config_path.suffix}")
                    return {}
                    
        except Exception as e:
            logger.error(f"Failed to load config file {config_path}: {e}")
            return None
    
    def _load_from_environment(self) -> Dict[str, Any]:
        """Load configuration from environment variables."""
        env_config = {}
        
        # Map environment variables to config paths
        env_mappings = {
            'UTOPIC_ENVIRONMENT': 'environment',
            'UTOPIC_DEBUG': 'debug',
            'UTOPIC_LOG_LEVEL': 'log_level',
            'UTOPIC_SAGEMAKER_REGION': 'deployment.sagemaker.region',
            'UTOPIC_SAGEMAKER_INSTANCE_TYPE': 'deployment.sagemaker.instance_type',
            'UTOPIC_EKS_CLUSTER_NAME': 'deployment.eks.cluster_name'
        }
        
        for env_var, config_path in env_mappings.items():
            value = os.getenv(env_var)
            if value is not None:
                # Convert string values to appropriate types
                if value.lower() in ('true', 'false'):
                    value = value.lower() == 'true'
                elif value.isdigit():
                    value = int(value)
                elif self._is_float(value):
                    value = float(value)
                
                self._set_nested_value(env_config, config_path, value)
        
        return env_config
    
    def _set_nested_value(self, config: Dict[str, Any], path: str, value: Any):
        """Set a nested configuration value using dot notation."""
        keys = path.split('.')
        current = config
        
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        current[keys[-1]] = value
    
    def _is_float(self, value: str) -> bool:
        """Check if string is a float."""
        try:
            float(value)
            return True
        except ValueError:
            return False
    
    def _create_platform_config(self, config_data: Dict[str, Any]) -> PlatformConfig:
        """Create PlatformConfig dataclass from dictionary."""
        # Extract known fields
        known_fields = {
            'platform_name': config_data.get('platform_name'),
            'version': config_data.get('version'),
            'environment': config_data.get('environment'),
            'debug': config_data.get('debug'),
            'log_level': config_data.get('log_level'),
            'agents': config_data.get('agents'),
            'deployment': config_data.get('deployment'),
            'clouds': config_data.get('clouds'),
            'database': config_data.get('database'),
            'security': config_data.get('security')
        }
        
        return PlatformConfig(**{k: v for k, v in known_fields.items() if v is not None})
    
    def _apply_environment_settings(self):
        """Apply environment-specific configuration settings."""
        env = self.config.environment
        
        if env == 'production':
            self.config.debug = False
            self.config.log_level = 'WARNING'
            # Production-specific defaults
            if not self.config.security.get('jwt_secret'):
                self.config.security['jwt_secret'] = os.getenv('JWT_SECRET', 'change-this-in-production')
                
        elif env == 'testing':
            self.config.debug = True
            self.config.log_level = 'DEBUG'
            # Use in-memory database for testing
            self.config.database['type'] = 'sqlite'
            self.config.database['path'] = ':memory:'
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value using dot notation.
        
        Args:
            key: Configuration key (e.g., 'agents.reasoning.temperature')
            default: Default value if key not found
            
        Returns:
            Configuration value
        """
        keys = key.split('.')
        current = asdict(self.config)
        
        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return default
        
        return current
    
    def set(self, key: str, value: Any):
        """
        Set configuration value using dot notation.
        
        Args:
            key: Configuration key
            value: Value to set
        """
        keys = key.split('.')
        current = asdict(self.config)
        
        # Navigate to the parent of the final key
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        
        # Set the final value
        current[keys[-1]] = value
        
        # Update the config object
        setattr(self.config, keys[0], current[keys[0]])
    
    def save(self, file_path: str) -> bool:
        """
        Save current configuration to file.
        
        Args:
            file_path: Path to save configuration
            
        Returns:
            Success status
        """
        try:
            config_data = asdict(self.config)
            file_path = Path(file_path)
            
            # Create directory if it doesn't exist
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w') as f:
                if file_path.suffix.lower() in ['.yaml', '.yml']:
                    yaml.dump(config_data, f, default_flow_style=False, indent=2)
                elif file_path.suffix.lower() == '.json':
                    json.dump(config_data, f, indent=2)
                else:
                    raise ValueError(f"Unsupported file format: {file_path.suffix}")
            
            logger.info(f"Configuration saved to: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
            return False
    
    def validate(self) -> List[str]:
        """
        Validate configuration values.
        
        Returns:
            List of validation errors
        """
        errors = []
        
        # Validate required fields
        required_fields = ['platform_name', 'version', 'environment']
        for field in required_fields:
            if not getattr(self.config, field):
                errors.append(f"Required field '{field}' is missing or empty")
        
        # Validate environment
        valid_environments = ['development', 'testing', 'production']
        if self.config.environment not in valid_environments:
            errors.append(f"Invalid environment '{self.config.environment}'. Must be one of: {valid_environments}")
        
        # Validate log level
        valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.config.log_level not in valid_log_levels:
            errors.append(f"Invalid log level '{self.config.log_level}'. Must be one of: {valid_log_levels}")
        
        # Validate deployment configuration
        if self.config.deployment:
            # Check SageMaker config
            sagemaker_config = self.config.deployment.get('sagemaker', {})
            if sagemaker_config:
                if not sagemaker_config.get('region'):
                    errors.append("SageMaker region is required")
                if not sagemaker_config.get('instance_type'):
                    errors.append("SageMaker instance_type is required")
            
            # Check EKS config
            eks_config = self.config.deployment.get('eks', {})
            if eks_config:
                if not eks_config.get('cluster_name'):
                    errors.append("EKS cluster_name is required")
        
        # Validate cloud providers
        if self.config.clouds:
            for cloud_config in self.config.clouds:
                if not cloud_config.get('name'):
                    errors.append("Cloud provider name is required")
                if not cloud_config.get('priority'):
                    errors.append("Cloud provider priority is required")
        
        return errors
    
    def get_agent_config(self, agent_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            Agent configuration
        """
        agent_configs = self.config.agents or {}
        return agent_configs.get(agent_name, {})
    
    def get_deployment_config(self, deployment_type: str) -> Dict[str, Any]:
        """
        Get configuration for a specific deployment type.
        
        Args:
            deployment_type: Type of deployment ('sagemaker', 'eks', etc.)
            
        Returns:
            Deployment configuration
        """
        deployment_configs = self.config.deployment or {}
        return deployment_configs.get(deployment_type, {})
    
    def get_cloud_configs(self) -> List[Dict[str, Any]]:
        """
        Get all cloud provider configurations.
        
        Returns:
            List of cloud configurations
        """
        return self.config.clouds or []
    
    def get_database_config(self) -> Dict[str, Any]:
        """
        Get database configuration.
        
        Returns:
            Database configuration
        """
        return self.config.database or {}
    
    def get_security_config(self) -> Dict[str, Any]:
        """
        Get security configuration.
        
        Returns:
            Security configuration
        """
        return self.config.security or {}
    
    @classmethod
    def load_config(cls, config_path: Optional[str] = None, **kwargs) -> 'ConfigManager':
        """
        Load configuration from file and create ConfigManager instance.
        
        Args:
            config_path: Path to configuration file
            **kwargs: Configuration overrides
            
        Returns:
            ConfigManager instance
        """
        return cls(config_path=config_path, **kwargs)
    
    def __repr__(self) -> str:
        """String representation of configuration."""
        return (f"ConfigManager("
                f"platform='{self.config.platform_name}', "
                f"version='{self.config.version}', "
                f"environment='{self.config.environment}', "
                f"agents={len(self.config.agents or {})}, "
                f"deployment_types={len(self.config.deployment or {})})")
    
    def __str__(self) -> str:
        """String representation of configuration."""
        return f"Utopic AI Platform Config ({self.config.environment})"