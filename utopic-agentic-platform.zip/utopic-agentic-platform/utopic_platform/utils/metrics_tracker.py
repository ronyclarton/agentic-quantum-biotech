"""
Metrics Tracker
==============

Tracks performance metrics, training statistics, and monitoring
for the Utopic AI Platform. Integrates with Weights & Biases and MLflow.

Author: MiniMax Agent
License: MIT
"""

import time
import json
import logging
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

# Try to import tracking libraries
try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False
    logging.warning("Weights & Biases not available. Install with: pip install wandb")

try:
    import mlflow
    import mlflow.pytorch
    MLFLOW_AVAILABLE = True
except ImportError:
    MLFLOW_AVAILABLE = False
    logging.warning("MLflow not available. Install with: pip install mlflow")

logger = logging.getLogger(__name__)


@dataclass
class TrainingMetrics:
    """Training metrics data structure."""
    epoch: int
    step: int
    loss: float
    accuracy: float
    learning_rate: float
    time_elapsed: float
    gpu_utilization: Optional[float] = None
    memory_usage: Optional[float] = None


@dataclass
class MaterialDiscoveryMetrics:
    """Material discovery metrics."""
    discovery_id: str
    target_material: str
    candidates_generated: int
    validation_success_rate: float
    best_candidate_confidence: float
    quantum_optimization_benefit: float
    generation_time: float
    computational_cost: float


@dataclass
class FederatedTrainingMetrics:
    """Federated learning metrics."""
    round_number: int
    participating_nodes: int
    global_loss: float
    aggregation_method: str
    convergence_status: str
    communication_overhead: float
    training_time: float


class MetricsTracker:
    """
    Tracks and monitors platform performance metrics.
    
    Capabilities:
    - Training metrics tracking
    - Material discovery analytics
    - Federated learning monitoring
    - Integration with W&B and MLflow
    - Real-time dashboard updates
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize metrics tracker.
        
        Args:
            config: Configuration for metrics tracking
        """
        self.config = config or {}
        
        # Initialize tracking backends
        self._initialize_tracking_backends()
        
        # Metrics storage
        self.training_metrics: List[TrainingMetrics] = []
        self.discovery_metrics: List[MaterialDiscoveryMetrics] = []
        self.federated_metrics: List[FederatedTrainingMetrics] = []
        
        # Real-time metrics
        self.current_session = {
            'start_time': time.time(),
            'requests_processed': 0,
            'errors_encountered': 0,
            'active_agents': 0,
            'resource_utilization': {}
        }
        
        # Performance counters
        self.counters = {
            'total_training_epochs': 0,
            'total_material_discoveries': 0,
            'total_federated_rounds': 0,
            'successful_deployments': 0,
            'failed_deployments': 0,
            'quantum_optimizations': 0,
            'biotech_analyses': 0
        }
        
        # Configuration
        self.tracking_interval = self.config.get('tracking_interval', 10)  # seconds
        self.auto_sync = self.config.get('auto_sync', True)
        self.log_level = self.config.get('log_level', 'INFO')
        
        logger.info("Metrics Tracker initialized")
    
    def _initialize_tracking_backends(self):
        """Initialize tracking backend services."""
        
        # Initialize Weights & Biases
        if WANDB_AVAILABLE and self.config.get('wandb', {}).get('enabled', True):
            try:
                wandb_config = self.config.get('wandb', {})
                wandb.init(
                    project=wandb_config.get('project', 'utopic-ai-platform'),
                    entity=wandb_config.get('entity'),
                    config=wandb_config.get('config', {}),
                    tags=wandb_config.get('tags', []),
                    notes=wandb_config.get('notes', ''),
                    reinit=True
                )
                self.wandb_enabled = True
                logger.info("Weights & Biases initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize W&B: {e}")
                self.wandb_enabled = False
        else:
            self.wandb_enabled = False
        
        # Initialize MLflow
        if MLFLOW_AVAILABLE and self.config.get('mlflow', {}).get('enabled', True):
            try:
                mlflow_config = self.config.get('mlflow', {})
                mlflow.set_tracking_uri(mlflow_config.get('tracking_uri', 'sqlite:///metrics.db'))
                
                # Create experiment if it doesn't exist
                experiment_name = mlflow_config.get('experiment_name', 'utopic-ai-platform')
                try:
                    mlflow.create_experiment(experiment_name)
                except mlflow.exceptions.MlflowException:
                    pass  # Experiment already exists
                
                mlflow.set_experiment(experiment_name)
                self.mlflow_enabled = True
                logger.info("MLflow initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize MLflow: {e}")
                self.mlflow_enabled = False
        else:
            self.mlflow_enabled = False
    
    def log_training_metrics(self, metrics: TrainingMetrics):
        """
        Log training metrics.
        
        Args:
            metrics: Training metrics to log
        """
        try:
            # Store locally
            self.training_metrics.append(metrics)
            
            # Update counters
            self.counters['total_training_epochs'] = max(
                self.counters['total_training_epochs'], metrics.epoch + 1
            )
            
            # Log to W&B
            if self.wandb_enabled:
                wandb.log({
                    'training/loss': metrics.loss,
                    'training/accuracy': metrics.accuracy,
                    'training/learning_rate': metrics.learning_rate,
                    'training/epoch': metrics.epoch,
                    'training/step': metrics.step,
                    'system/gpu_utilization': metrics.gpu_utilization,
                    'system/memory_usage': metrics.memory_usage
                }, step=metrics.step)
            
            # Log to MLflow
            if self.mlflow_enabled:
                with mlflow.start_run():
                    mlflow.log_metrics({
                        'loss': metrics.loss,
                        'accuracy': metrics.accuracy,
                        'learning_rate': metrics.learning_rate,
                        'epoch': metrics.epoch,
                        'step': metrics.step
                    })
                    mlflow.log_param('epoch', metrics.epoch)
                    mlflow.log_param('learning_rate', metrics.learning_rate)
            
            # Update session metrics
            self.current_session['requests_processed'] += 1
            
            logger.debug(f"Training metrics logged - Epoch: {metrics.epoch}, Loss: {metrics.loss:.4f}")
            
        except Exception as e:
            logger.error(f"Failed to log training metrics: {e}")
    
    def log_material_discovery(self, result: MaterialDiscoveryMetrics):
        """
        Log material discovery metrics.
        
        Args:
            result: Material discovery result metrics
        """
        try:
            # Store locally
            self.discovery_metrics.append(result)
            
            # Update counters
            self.counters['total_material_discoveries'] += 1
            self.counters['quantum_optimizations'] += 1 if result.quantum_optimization_benefit > 0 else 0
            
            # Calculate derived metrics
            efficiency_score = result.validation_success_rate * result.best_candidate_confidence
            cost_efficiency = result.validation_success_rate / max(result.computational_cost, 0.001)
            
            # Log to W&B
            if self.wandb_enabled:
                wandb.log({
                    'material_discovery/candidates_generated': result.candidates_generated,
                    'material_discovery/validation_success_rate': result.validation_success_rate,
                    'material_discovery/best_confidence': result.best_candidate_confidence,
                    'material_discovery/quantum_benefit': result.quantum_optimization_benefit,
                    'material_discovery/generation_time': result.generation_time,
                    'material_discovery/computational_cost': result.computational_cost,
                    'material_discovery/efficiency_score': efficiency_score,
                    'material_discovery/cost_efficiency': cost_efficiency
                })
            
            # Log to MLflow
            if self.mlflow_enabled:
                with mlflow.start_run():
                    mlflow.log_metrics({
                        'candidates_generated': result.candidates_generated,
                        'validation_success_rate': result.validation_success_rate,
                        'best_confidence': result.best_candidate_confidence,
                        'quantum_benefit': result.quantum_optimization_benefit,
                        'generation_time': result.generation_time,
                        'computational_cost': result.computational_cost,
                        'efficiency_score': efficiency_score,
                        'cost_efficiency': cost_efficiency
                    })
                    mlflow.log_param('target_material', result.target_material)
                    mlflow.log_param('discovery_id', result.discovery_id)
            
            logger.info(f"Material discovery logged - {result.target_material}: {result.candidates_generated} candidates")
            
        except Exception as e:
            logger.error(f"Failed to log material discovery metrics: {e}")
    
    def log_federated_training(self, metrics: FederatedTrainingMetrics):
        """
        Log federated training metrics.
        
        Args:
            metrics: Federated training metrics
        """
        try:
            # Store locally
            self.federated_metrics.append(metrics)
            
            # Update counters
            self.counters['total_federated_rounds'] = max(
                self.counters['total_federated_rounds'], metrics.round_number + 1
            )
            
            # Calculate derived metrics
            node_efficiency = 1.0 - (metrics.communication_overhead / max(metrics.training_time, 0.001))
            convergence_score = 1.0 if metrics.convergence_status == 'completed' else 0.5
            
            # Log to W&B
            if self.wandb_enabled:
                wandb.log({
                    'federated/round_number': metrics.round_number,
                    'federated/participating_nodes': metrics.participating_nodes,
                    'federated/global_loss': metrics.global_loss,
                    'federated/communication_overhead': metrics.communication_overhead,
                    'federated/training_time': metrics.training_time,
                    'federated/node_efficiency': node_efficiency,
                    'federated/convergence_score': convergence_score
                })
            
            # Log to MLflow
            if self.mlflow_enabled:
                with mlflow.start_run():
                    mlflow.log_metrics({
                        'round_number': metrics.round_number,
                        'participating_nodes': metrics.participating_nodes,
                        'global_loss': metrics.global_loss,
                        'communication_overhead': metrics.communication_overhead,
                        'training_time': metrics.training_time,
                        'node_efficiency': node_efficiency,
                        'convergence_score': convergence_score
                    })
                    mlflow.log_param('aggregation_method', metrics.aggregation_method)
                    mlflow.log_param('convergence_status', metrics.convergence_status)
            
            logger.info(f"Federated training logged - Round {metrics.round_number}: {metrics.participating_nodes} nodes")
            
        except Exception as e:
            logger.error(f"Failed to log federated training metrics: {e}")
    
    def log_custom_metric(self, metric_name: str, value: Union[float, int], step: Optional[int] = None):
        """
        Log a custom metric.
        
        Args:
            metric_name: Name of the metric
            value: Metric value
            step: Optional step number
        """
        try:
            # Update session counter
            if 'requests' in metric_name.lower():
                self.current_session['requests_processed'] += 1
            
            # Log to W&B
            if self.wandb_enabled:
                log_data = {metric_name: value}
                if step is not None:
                    log_data['step'] = step
                wandb.log(log_data, step=step)
            
            # Log to MLflow
            if self.mlflow_enabled:
                mlflow.log_metric(metric_name, value, step=step)
            
            logger.debug(f"Custom metric logged - {metric_name}: {value}")
            
        except Exception as e:
            logger.error(f"Failed to log custom metric {metric_name}: {e}")
    
    def log_agent_performance(self, agent_name: str, metrics: Dict[str, float]):
        """
        Log agent performance metrics.
        
        Args:
            agent_name: Name of the agent
            metrics: Performance metrics dictionary
        """
        try:
            # Prefix metric names with agent name
            prefixed_metrics = {f"agent_{agent_name}_{k}": v for k, v in metrics.items()}
            
            # Log to W&B
            if self.wandb_enabled:
                wandb.log(prefixed_metrics)
            
            # Log to MLflow
            if self.mlflow_enabled:
                with mlflow.start_run():
                    mlflow.log_metrics(prefixed_metrics)
                    mlflow.log_param('agent_name', agent_name)
            
            # Update session
            self.current_session['active_agents'] += 1
            
            logger.debug(f"Agent performance logged - {agent_name}: {metrics}")
            
        except Exception as e:
            logger.error(f"Failed to log agent performance for {agent_name}: {e}")
    
    def log_deployment_event(self, deployment_type: str, status: str, duration: Optional[float] = None):
        """
        Log deployment event.
        
        Args:
            deployment_type: Type of deployment (sagemaker, eks, etc.)
            status: Deployment status (success, failure, in_progress)
            duration: Deployment duration in seconds
        """
        try:
            # Update counters
            if status == 'success':
                self.counters['successful_deployments'] += 1
            elif status == 'failure':
                self.counters['failed_deployments'] += 1
            
            # Log to W&B
            if self.wandb_enabled:
                log_data = {
                    f'deployment_{deployment_type}_status': 1 if status == 'success' else 0,
                    f'deployment_{deployment_type}_count': 1
                }
                if duration is not None:
                    log_data[f'deployment_{deployment_type}_duration'] = duration
                wandb.log(log_data)
            
            # Log to MLflow
            if self.mlflow_enabled:
                with mlflow.start_run():
                    mlflow.log_metric(f'deployment_{deployment_type}_{status}', 1)
                    mlflow.log_param('deployment_type', deployment_type)
                    mlflow.log_param('deployment_status', status)
                    if duration is not None:
                        mlflow.log_metric(f'deployment_{deployment_type}_duration', duration)
            
            logger.info(f"Deployment event logged - {deployment_type}: {status}")
            
        except Exception as e:
            logger.error(f"Failed to log deployment event: {e}")
    
    def log_error(self, error_type: str, error_message: str, context: Optional[Dict[str, Any]] = None):
        """
        Log error metrics.
        
        Args:
            error_type: Type of error
            error_message: Error message
            context: Additional context information
        """
        try:
            # Update session
            self.current_session['errors_encountered'] += 1
            
            # Log to W&B
            if self.wandb_enabled:
                wandb.log({
                    'errors/count': 1,
                    'errors/last_error_type': error_type,
                    'errors/last_error_message': error_message
                })
            
            # Log to MLflow
            if self.mlflow_enabled:
                with mlflow.start_run():
                    mlflow.log_metric('error_count', 1)
                    mlflow.log_param('last_error_type', error_type)
                    mlflow.log_param('last_error_message', error_message)
                    if context:
                        for key, value in context.items():
                            mlflow.log_param(f'error_context_{key}', str(value))
            
            logger.warning(f"Error logged - {error_type}: {error_message}")
            
        except Exception as e:
            logger.error(f"Failed to log error: {e}")
    
    def get_training_summary(self) -> Dict[str, Any]:
        """
        Get training metrics summary.
        
        Returns:
            Dictionary with training summary statistics
        """
        if not self.training_metrics:
            return {'message': 'No training metrics available'}
        
        recent_metrics = self.training_metrics[-100:]  # Last 100 epochs
        
        return {
            'total_epochs': len(self.training_metrics),
            'recent_avg_loss': np.mean([m.loss for m in recent_metrics]),
            'recent_avg_accuracy': np.mean([m.accuracy for m in recent_metrics]),
            'best_loss': min(m.loss for m in self.training_metrics),
            'best_accuracy': max(m.accuracy for m in self.training_metrics),
            'total_training_time': sum(m.time_elapsed for m in self.training_metrics),
            'avg_epoch_time': np.mean([m.time_elapsed for m in self.training_metrics]),
            'latest_metrics': asdict(self.training_metrics[-1]) if self.training_metrics else None
        }
    
    def get_discovery_summary(self) -> Dict[str, Any]:
        """
        Get material discovery metrics summary.
        
        Returns:
            Dictionary with discovery summary statistics
        """
        if not self.discovery_metrics:
            return {'message': 'No discovery metrics available'}
        
        return {
            'total_discoveries': len(self.discovery_metrics),
            'avg_candidates_per_discovery': np.mean([m.candidates_generated for m in self.discovery_metrics]),
            'avg_validation_success_rate': np.mean([m.validation_success_rate for m in self.discovery_metrics]),
            'avg_confidence': np.mean([m.best_candidate_confidence for m in self.discovery_metrics]),
            'avg_quantum_benefit': np.mean([m.quantum_optimization_benefit for m in self.discovery_metrics]),
            'total_generation_time': sum(m.generation_time for m in self.discovery_metrics),
            'total_computational_cost': sum(m.computational_cost for m in self.discovery_metrics),
            'best_discovery': max(self.discovery_metrics, key=lambda m: m.best_candidate_confidence),
            'most_efficient': min(self.discovery_metrics, key=lambda m: m.computational_cost)
        }
    
    def get_federated_summary(self) -> Dict[str, Any]:
        """
        Get federated training metrics summary.
        
        Returns:
            Dictionary with federated training summary
        """
        if not self.federated_metrics:
            return {'message': 'No federated training metrics available'}
        
        return {
            'total_rounds': len(self.federated_metrics),
            'avg_nodes_per_round': np.mean([m.participating_nodes for m in self.federated_metrics]),
            'avg_global_loss': np.mean([m.global_loss for m in self.federated_metrics]),
            'avg_training_time': np.mean([m.training_time for m in self.federated_metrics]),
            'avg_communication_overhead': np.mean([m.communication_overhead for m in self.federated_metrics]),
            'convergence_rate': sum(1 for m in self.federated_metrics if m.convergence_status == 'completed') / len(self.federated_metrics),
            'most_efficient_round': min(self.federated_metrics, key=lambda m: m.communication_overhead),
            'latest_round': self.federated_metrics[-1] if self.federated_metrics else None
        }
    
    def get_platform_summary(self) -> Dict[str, Any]:
        """
        Get overall platform performance summary.
        
        Returns:
            Dictionary with platform summary
        """
        session_duration = time.time() - self.current_session['start_time']
        
        return {
            'session_info': {
                'duration_hours': session_duration / 3600,
                'requests_processed': self.current_session['requests_processed'],
                'errors_encountered': self.current_session['errors_encountered'],
                'error_rate': self.current_session['errors_encountered'] / max(self.current_session['requests_processed'], 1)
            },
            'performance_counters': self.counters,
            'training_summary': self.get_training_summary(),
            'discovery_summary': self.get_discovery_summary(),
            'federated_summary': self.get_federated_summary(),
            'tracking_backends': {
                'wandb_enabled': self.wandb_enabled,
                'mlflow_enabled': self.mlflow_enabled
            }
        }
    
    def export_metrics(self, file_path: str, format: str = 'json') -> bool:
        """
        Export metrics to file.
        
        Args:
            file_path: Path to export file
            format: Export format ('json', 'csv')
            
        Returns:
            Success status
        """
        try:
            export_data = {
                'training_metrics': [asdict(m) for m in self.training_metrics],
                'discovery_metrics': [asdict(m) for m in self.discovery_metrics],
                'federated_metrics': [asdict(m) for m in self.federated_metrics],
                'counters': self.counters,
                'export_timestamp': time.time()
            }
            
            file_path = Path(file_path)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w') as f:
                if format.lower() == 'json':
                    json.dump(export_data, f, indent=2)
                elif format.lower() == 'csv':
                    # Convert to CSV format (simplified)
                    import csv
                    writer = csv.writer(f)
                    writer.writerow(['type', 'timestamp', 'data'])
                    
                    # Write training metrics
                    for m in self.training_metrics:
                        writer.writerow(['training', m.epoch, asdict(m)])
                    
                    # Write discovery metrics
                    for m in self.discovery_metrics:
                        writer.writerow(['discovery', m.discovery_id, asdict(m)])
                    
                    # Write federated metrics
                    for m in self.federated_metrics:
                        writer.writerow(['federated', m.round_number, asdict(m)])
                else:
                    raise ValueError(f"Unsupported export format: {format}")
            
            logger.info(f"Metrics exported to: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to export metrics: {e}")
            return False
    
    def clear_metrics(self):
        """Clear all stored metrics."""
        self.training_metrics.clear()
        self.discovery_metrics.clear()
        self.federated_metrics.clear()
        self.counters = {key: 0 for key in self.counters.keys()}
        self.current_session['requests_processed'] = 0
        self.current_session['errors_encountered'] = 0
        
        logger.info("All metrics cleared")
    
    def finish_tracking(self):
        """Finish tracking session and cleanup."""
        try:
            # Finish W&B run
            if self.wandb_enabled:
                wandb.finish()
            
            # Save final metrics
            if self.auto_sync:
                self.export_metrics(f"metrics_final_{int(time.time())}.json")
            
            logger.info("Tracking session finished")
            
        except Exception as e:
            logger.error(f"Error finishing tracking: {e}")
    
    def get_summary(self) -> Dict[str, Any]:
        """Get comprehensive metrics summary."""
        return self.get_platform_summary()